/* Person page — sub-components
   MiniGraph, RangeScrubber, ImovinaCompare, SensitiveDOB, CanonicalIDs,
   RoleHistory, typed timeline-event row, tab panels.               */

const { useState: usePS, useEffect: uePS, useMemo: umPS, useRef: urPS } = React;

// ── Sensitivity helper ────────────────────────────────────────
// Returns display form for a DOB based on:
//   - is the person a public figure (office of public trust)?
//   - is the full DOB published in an official source?
// Private: day + month only, year hidden behind hover request.
// Public+sourced: full date.
const formatDOB = ({ iso, publicFigure, yearInOfficialSource }) => {
  const d = new Date(iso + 'T00:00:00');
  const dd = String(d.getUTCDate()).padStart(2, '0');
  const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
  const yyyy = d.getUTCFullYear();
  const ageMasked = publicFigure && yearInOfficialSource;
  return { dd, mm, yyyy, showYear: ageMasked };
};

const SensitiveDOB = ({ iso, publicFigure, yearInOfficialSource, source, retrieved }) => {
  const { dd, mm, yyyy, showYear } = formatDOB({ iso, publicFigure, yearInOfficialSource });
  const [reveal, setReveal] = usePS(false);
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
      <span className="tn-mono tn-tnum">{dd}.{mm}.</span>
      {showYear ? (
        <SourceBadge source={source} retrieved={retrieved} tone="muted">
          <span className="tn-mono tn-tnum">{yyyy}.</span>
        </SourceBadge>
      ) : (
        <button onClick={() => setReveal(r => !r)} style={{
          border: '1px dashed var(--tn-rule)', background: 'var(--tn-paper-2)',
          color: 'var(--tn-ink-4)', fontSize: 11, fontFamily: 'var(--tn-font-mono)',
          padding: '1px 6px', borderRadius: 2, cursor: 'pointer', letterSpacing: 0.2,
        }}>
          {reveal ? `${yyyy} · nije javno` : 'godina nije javna'}
        </button>
      )}
    </span>
  );
};

// ── Canonical IDs table (with per-row sensitivity tooltip) ────
const CanonicalIDs = ({ rows }) => (
  <div style={{ display: 'grid', rowGap: 1, background: 'var(--tn-rule-2)', border: '1px solid var(--tn-rule-2)' }}>
    {rows.map((r) => (
      <div key={r.key} style={{
        display: 'grid', gridTemplateColumns: '64px 1fr',
        background: 'var(--tn-white)', padding: '7px 10px', gap: 10, alignItems: 'center',
      }}>
        <span className="tn-caps" style={{ fontSize: 10, color: 'var(--tn-ink-4)' }}>{r.key}</span>
        <span style={{
          display: 'flex', alignItems: 'center', gap: 8,
          fontFamily: r.mono ? 'var(--tn-font-mono)' : 'inherit',
          fontSize: 12, color: 'var(--tn-ink-2)', letterSpacing: r.mono ? 0.2 : 0,
        }}>
          {r.sensitive ? (
            <span title="Podatak osjetljiv — prikazan zbog javne funkcije" style={{
              color: 'var(--tn-ink-3)',
            }}>{r.value}</span>
          ) : r.value}
          {r.source && (
            <SourceBadge source={r.source} retrieved={r.retrieved} tone="muted">
              <span style={{ fontSize: 10 }}>{r.source.split(' ')[0]}</span>
            </SourceBadge>
          )}
        </span>
      </div>
    ))}
  </div>
);

// ── RangeScrubber — horizontal year-range filter ──────────────
// Shows event density as a stepped histogram along a timeline axis,
// with two draggable-feeling handles. In this static mock the
// handles click-snap to decade boundaries.
const RangeScrubber = ({ start, end, minYear, maxYear, density, onChange, labels }) => {
  const total = maxYear - minYear;
  const left = ((start - minYear) / total) * 100;
  const right = ((end - minYear) / total) * 100;
  return (
    <div style={{
      background: 'var(--tn-white)', border: '1px solid var(--tn-rule)',
      padding: '14px 18px 10px', marginBottom: 16,
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
        <div className="tn-caps" style={{ fontSize: 10 }}>Vremenski raspon</div>
        <div style={{ fontSize: 12, color: 'var(--tn-ink-3)' }}>
          <span className="tn-mono">{start}</span>
          <span style={{ margin: '0 6px', color: 'var(--tn-ink-5)' }}>→</span>
          <span className="tn-mono">{end}</span>
          <button onClick={() => onChange(minYear, maxYear)} style={{
            marginLeft: 12, border: 'none', background: 'transparent',
            color: 'var(--tn-navy-700)', fontSize: 11, cursor: 'pointer',
            fontFamily: 'inherit', textDecoration: 'underline',
          }}>cijeli raspon</button>
        </div>
      </div>

      {/* Histogram */}
      <div style={{ position: 'relative', height: 46, marginBottom: 4 }}>
        <div style={{
          position: 'absolute', inset: 0, display: 'grid',
          gridTemplateColumns: `repeat(${density.length}, 1fr)`,
          alignItems: 'end', gap: 2,
        }}>
          {density.map((v, i) => {
            const year = minYear + i;
            const inRange = year >= start && year <= end;
            const h = Math.max(2, (v / Math.max(...density)) * 38);
            return (
              <div key={i} style={{
                height: h,
                background: inRange ? 'var(--tn-navy-700)' : 'var(--tn-rule)',
              }}/>
            );
          })}
        </div>
        {/* Selection shade */}
        <div style={{
          position: 'absolute', top: 0, bottom: 0,
          left: `${left}%`, right: `${100 - right}%`,
          background: 'rgba(11,37,69,0.05)',
          borderLeft: '1px solid var(--tn-navy-800)',
          borderRight: '1px solid var(--tn-navy-800)',
          pointerEvents: 'none',
        }}/>
      </div>

      {/* Axis */}
      <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--tn-font-mono)', fontSize: 10, color: 'var(--tn-ink-5)' }}>
        {[minYear, minYear + Math.round(total / 4), minYear + Math.round(total / 2), minYear + Math.round(3 * total / 4), maxYear].map(y => (
          <span key={y}>{y}</span>
        ))}
      </div>

      {/* Quick presets */}
      <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
        {labels.map(([l, a, b]) => {
          const active = start === a && end === b;
          return (
            <button key={l} onClick={() => onChange(a, b)} style={{
              padding: '3px 10px', borderRadius: 999, fontSize: 11,
              border: `1px solid ${active ? 'var(--tn-navy-700)' : 'var(--tn-rule)'}`,
              background: active ? 'var(--tn-navy-50)' : 'transparent',
              color: active ? 'var(--tn-navy-800)' : 'var(--tn-ink-3)',
              cursor: 'pointer', fontFamily: 'inherit', fontWeight: 500,
            }}>{l}</button>
          );
        })}
      </div>
    </div>
  );
};

// ── Typed timeline event — newest first strip ─────────────────
const EVENT_KINDS = {
  appointment: { label: 'Imenovanje',     icon: 'shield',   tone: 'var(--tn-navy-700)' },
  directorship:{ label: 'Uprava / NO',    icon: 'building', tone: 'var(--tn-navy-700)' },
  acquired:    { label: 'Stjecanje',      icon: 'parcel',   tone: 'var(--tn-verify)' },
  sold:        { label: 'Otuđenje',       icon: 'parcel',   tone: 'var(--tn-ink-3)' },
  donation:    { label: 'Donacija',       icon: 'event',    tone: 'var(--tn-navy-700)' },
  courtNotice: { label: 'Sudska obavijest', icon: 'doc',    tone: 'var(--tn-amber)' },
  decl:        { label: 'Imovinska kartica', icon: 'list',  tone: 'var(--tn-navy-700)' },
};

const TimelineEvent = ({ ev, last }) => {
  const K = EVENT_KINDS[ev.kind] || EVENT_KINDS.decl;
  const amber = ev.kind === 'courtNotice';
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '92px 32px 1fr', gap: 14, paddingBottom: last ? 0 : 18, position: 'relative' }}>
      {/* Date */}
      <div style={{ textAlign: 'right', paddingTop: 2 }}>
        <div className="tn-mono tn-tnum" style={{ fontSize: 12, color: 'var(--tn-ink-2)' }}>{ev.date}</div>
        {ev.timeAgo && <div style={{ fontSize: 10, color: 'var(--tn-ink-5)', marginTop: 2 }}>{ev.timeAgo}</div>}
      </div>

      {/* Icon + rail */}
      <div style={{ position: 'relative', display: 'flex', justifyContent: 'center', paddingTop: 2 }}>
        <div style={{
          width: 26, height: 26, borderRadius: 2,
          background: amber ? 'var(--tn-amber-weak)' : 'var(--tn-white)',
          border: `1px solid ${amber ? 'var(--tn-amber)' : 'var(--tn-rule)'}`,
          color: K.tone,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          zIndex: 1,
        }}>
          <Icon name={K.icon} size={14} stroke={1.6}/>
        </div>
        {!last && <div style={{ position: 'absolute', top: 28, bottom: -18, left: '50%', width: 1, background: 'var(--tn-rule)' }}/>}
      </div>

      {/* Card */}
      <div style={{
        background: 'var(--tn-white)',
        border: `1px solid ${amber ? 'var(--tn-amber)' : 'var(--tn-rule)'}`,
        padding: '12px 14px', borderRadius: 2,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, flexWrap: 'wrap' }}>
          <span className="tn-caps" style={{ color: K.tone, fontSize: 10 }}>{K.label}</span>
          {ev.amount && (
            <span className="tn-mono tn-tnum" style={{
              fontSize: 12, color: 'var(--tn-ink-2)', fontWeight: 600,
              background: 'var(--tn-paper-2)', padding: '1px 6px', borderRadius: 2,
            }}>
              {ev.amount}
            </span>
          )}
        </div>
        <div style={{ fontSize: 14, color: 'var(--tn-ink-2)', fontWeight: 500, lineHeight: 1.4 }}>{ev.title}</div>
        {ev.entities && ev.entities.length > 0 && (
          <div style={{ marginTop: 8, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {ev.entities.map((e, i) => (
              <a key={i} href="#" style={{
                display: 'inline-flex', alignItems: 'center', gap: 5,
                fontSize: 12, color: 'var(--tn-navy-800)', textDecoration: 'none',
                padding: '2px 8px', background: 'var(--tn-navy-50)', borderRadius: 2,
              }}>
                <Icon name={e.type === 'org' ? 'building' : e.type === 'person' ? 'person' : e.type === 'asset' ? 'parcel' : 'event'} size={10} stroke={1.6}/>
                {e.name}
              </a>
            ))}
          </div>
        )}
        <div style={{ marginTop: 8, display: 'flex', alignItems: 'center', gap: 8 }}>
          <SourceBadge source={ev.source} retrieved={ev.retrieved} url="#" tone={amber ? 'amber' : 'muted'}>
            <span style={{ fontSize: 11 }}>{ev.source.split(' · ')[0]}</span>
          </SourceBadge>
        </div>
      </div>
    </div>
  );
};

// ── MiniGraph — static force-laid network snippet ─────────────
// Pre-placed node positions to avoid jitter on each render.
// Radial-ish layout: central person + up to 10 neighbours
// arranged with varied distance + angle for organic feel.
const MiniGraph = ({ centre, nodes, edges, onOpen, onSelect, selected }) => {
  const W = 320, H = 320;

  // Node colors by type
  const colorFor = (n) => {
    if (n.id === centre) return 'var(--tn-navy-800)';
    if (n.flag) return 'var(--tn-amber)';
    return {
      person: 'var(--tn-navy-600)',
      org: 'var(--tn-navy-500)',
      asset: '#8899b4',
      event: '#a3a89c',
    }[n.type] || 'var(--tn-ink-4)';
  };
  const sizeFor = (n) => n.id === centre ? 12 : 7;

  const nodeById = umPS(() => Object.fromEntries(nodes.map(n => [n.id, n])), [nodes]);

  return (
    <div>
      <svg width={W} height={H} style={{ display: 'block', background: 'var(--tn-paper-2)', border: '1px solid var(--tn-rule)', borderRadius: 2 }}>
        {/* Edges */}
        {edges.map((e, i) => {
          const a = nodeById[e.from];
          const b = nodeById[e.to];
          if (!a || !b) return null;
          const dim = selected && selected !== e.from && selected !== e.to;
          return (
            <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y}
              stroke={e.strong ? 'var(--tn-navy-700)' : 'var(--tn-ink-5)'}
              strokeOpacity={dim ? 0.15 : e.strong ? 0.55 : 0.35}
              strokeWidth={e.strong ? 1.2 : 0.8}
              strokeDasharray={e.soft ? '2 3' : ''}/>
          );
        })}

        {/* Nodes */}
        {nodes.map((n) => {
          const isSel = selected === n.id || n.id === centre;
          return (
            <g key={n.id} style={{ cursor: 'pointer' }} onMouseEnter={() => onSelect && onSelect(n.id)} onMouseLeave={() => onSelect && onSelect(null)}>
              <circle cx={n.x} cy={n.y} r={sizeFor(n) + 2}
                fill="var(--tn-paper-2)"
                stroke="none"/>
              <circle cx={n.x} cy={n.y} r={sizeFor(n)}
                fill={colorFor(n)}
                stroke={isSel ? 'var(--tn-navy-800)' : '#fff'} strokeWidth={isSel ? 2 : 1.5}/>
              {n.flag && n.id !== centre && (
                <circle cx={n.x + sizeFor(n) - 1} cy={n.y - sizeFor(n) + 1} r={3}
                  fill="var(--tn-amber)" stroke="#fff" strokeWidth={1}/>
              )}
              <text x={n.x} y={n.y + sizeFor(n) + 11}
                textAnchor="middle"
                fontSize={n.id === centre ? 11 : 10}
                fontFamily="var(--tn-font-sans)"
                fontWeight={n.id === centre ? 600 : 500}
                fill={n.id === centre ? 'var(--tn-navy-900)' : 'var(--tn-ink-2)'}
              >{n.label}</text>
              {n.sub && n.id !== centre && (
                <text x={n.x} y={n.y + sizeFor(n) + 23}
                  textAnchor="middle" fontSize={9}
                  fontFamily="var(--tn-font-mono)" fill="var(--tn-ink-5)">
                  {n.sub}
                </text>
              )}
            </g>
          );
        })}
      </svg>

      {/* Legend */}
      <div style={{ display: 'flex', gap: 12, marginTop: 10, flexWrap: 'wrap', fontSize: 10, color: 'var(--tn-ink-4)', fontFamily: 'var(--tn-font-mono)' }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--tn-navy-800)' }}/>ova osoba
        </span>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--tn-navy-500)' }}/>subjekt
        </span>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#8899b4' }}/>nekretnina
        </span>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--tn-amber)' }}/>oznaka
        </span>
      </div>

      <div style={{ marginTop: 12, display: 'flex', gap: 8 }}>
        <Button variant="primary" size="sm" iconRight="arrow" onClick={onOpen} style={{ flex: 1 }}>Otvori u mreži</Button>
        <Button variant="secondary" size="sm" icon="download">SVG</Button>
      </div>
      <div style={{ marginTop: 8, fontSize: 10, color: 'var(--tn-ink-5)', fontFamily: 'var(--tn-font-mono)', lineHeight: 1.5 }}>
        {nodes.length - 1} susjeda · veze iz Sudskog registra, imov. kartica, Katastra · vizualna udaljenost nije semantička
      </div>
    </div>
  );
};

// ── Imovinska kartica compare — year-by-year table ────────────
const ImovinaCompare = () => {
  const years = [2021, 2022, 2023, 2024];
  const rows = [
    { cat: 'Nekretnine',    lbl: 'Stan 112 m² · Zagreb',     vals: [380000, 395000, 410000, 420000] },
    { cat: 'Nekretnine',    lbl: 'Kuća 180 m² · Zagorje',    vals: [  null, 265000, 272000, 280000] },
    { cat: 'Gotovina',      lbl: 'Tekući računi',            vals: [ 28400,  31200,  38900,  48200] },
    { cat: 'Štednja',       lbl: 'Oročeni depozit · PBZ',    vals: [240000, 260000, 290000, 320000] },
    { cat: 'Vrijednosni p.',lbl: 'HT d.d. · 214 dionica',    vals: [  6120,   6480,   6740,   6812] },
    { cat: 'Vozila',        lbl: 'BMW Serija 5 · 2019',      vals: [ 48000,  44000,  41000,  38000] },
    { cat: 'Potraživanja',  lbl: 'Najamnina (godišnja)',     vals: [ 12000,  13200,  13800,  14400] },
    { cat: 'Obveze',        lbl: 'Stambeni kredit',          vals: [-72000, -61000, -48000, -36000] },
  ];

  const formatEUR = (v) => v === null ? '—' : (v < 0 ? '−' : '') + Math.abs(v).toLocaleString('hr-HR');
  const delta = (a, b) => {
    if (a === null || b === null) return null;
    const d = b - a;
    if (d === 0) return null;
    return d;
  };

  const totals = years.map((_, yi) => rows.reduce((s, r) => s + (r.vals[yi] || 0), 0));
  const yoy = years.map((_, yi) => yi === 0 ? null : totals[yi] - totals[yi - 1]);

  return (
    <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: 0 }}>
      {/* Header strip */}
      <div style={{
        display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
        padding: '16px 20px', borderBottom: '1px solid var(--tn-rule)', gap: 12,
      }}>
        <div>
          <h3 style={{ fontSize: 14, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.08, color: 'var(--tn-ink-2)' }}>
            Usporedba imovinskih kartica
          </h3>
          <div style={{ fontSize: 12, color: 'var(--tn-ink-4)', marginTop: 2 }}>
            Sve vrijednosti kako su prijavljene, u EUR. Negativni iznosi su obveze. Deltes u boji prikazuju promjenu u odnosu na prethodnu godinu.
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Button variant="secondary" size="sm" icon="download">CSV</Button>
          <Button variant="ghost" size="sm" iconRight="external">Izvor: Povjerenstvo</Button>
        </div>
      </div>

      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, minWidth: 720 }}>
          <thead>
            <tr style={{ textAlign: 'left', background: 'var(--tn-paper-2)' }}>
              <th style={{ padding: '10px 16px', fontSize: 10, fontWeight: 500, letterSpacing: 0.08, textTransform: 'uppercase', color: 'var(--tn-ink-4)', borderBottom: '1px solid var(--tn-rule)', width: 150 }}>Kategorija</th>
              <th style={{ padding: '10px 12px', fontSize: 10, fontWeight: 500, letterSpacing: 0.08, textTransform: 'uppercase', color: 'var(--tn-ink-4)', borderBottom: '1px solid var(--tn-rule)' }}>Opis</th>
              {years.map((y) => (
                <th key={y} style={{ padding: '10px 12px', fontSize: 11, fontFamily: 'var(--tn-font-mono)', fontWeight: 600, letterSpacing: 0.1, color: 'var(--tn-ink-2)', textAlign: 'right', borderBottom: '1px solid var(--tn-rule)' }}>{y}.</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} style={{ borderBottom: '1px solid var(--tn-rule-2)' }}>
                <td style={{ padding: '10px 16px', color: 'var(--tn-ink-4)', fontSize: 12 }}>{r.cat}</td>
                <td style={{ padding: '10px 12px', color: 'var(--tn-ink-2)' }}>{r.lbl}</td>
                {r.vals.map((v, yi) => {
                  const d = yi === 0 ? null : delta(r.vals[yi - 1], v);
                  const isObligation = r.cat === 'Obveze';
                  const improvement = isObligation ? (d !== null && d > 0) : (d !== null && d > 0);
                  const deltaColor = d === null ? 'var(--tn-ink-5)' :
                    (isObligation
                      ? (d > 0 ? 'var(--tn-verify)' : 'var(--tn-amber-ink)')
                      : (d > 0 ? 'var(--tn-verify)' : 'var(--tn-amber-ink)'));
                  const newRow = yi > 0 && r.vals[yi - 1] === null && v !== null;
                  return (
                    <td key={yi} style={{
                      padding: '10px 12px', textAlign: 'right',
                      fontFamily: 'var(--tn-font-mono)', fontVariantNumeric: 'tabular-nums',
                      color: v === null ? 'var(--tn-ink-5)' : 'var(--tn-ink-2)',
                      background: newRow ? 'rgba(47,107,63,0.06)' : 'transparent',
                    }}>
                      <div>{formatEUR(v)}</div>
                      {d !== null && (
                        <div style={{
                          fontSize: 10, color: deltaColor, letterSpacing: 0.2, marginTop: 2,
                        }}>
                          {d > 0 ? '+' : ''}{d.toLocaleString('hr-HR')}
                        </div>
                      )}
                      {newRow && (
                        <div style={{ fontSize: 9, color: 'var(--tn-verify)', letterSpacing: 0.3, marginTop: 1, textTransform: 'uppercase' }}>
                          novo
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr style={{ background: 'var(--tn-paper-2)' }}>
              <td colSpan={2} style={{ padding: '12px 16px', fontSize: 11, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.08, color: 'var(--tn-ink-2)' }}>
                Neto ukupno (prijavljeno)
              </td>
              {totals.map((t, yi) => (
                <td key={yi} style={{ padding: '12px 12px', textAlign: 'right', fontFamily: 'var(--tn-font-mono)', fontVariantNumeric: 'tabular-nums', fontWeight: 600, color: 'var(--tn-navy-800)' }}>
                  <div>{t.toLocaleString('hr-HR')}</div>
                  {yoy[yi] !== null && (
                    <div style={{ fontSize: 10, color: yoy[yi] > 0 ? 'var(--tn-verify)' : 'var(--tn-amber-ink)', marginTop: 2 }}>
                      {yoy[yi] > 0 ? '+' : ''}{yoy[yi].toLocaleString('hr-HR')}
                    </div>
                  )}
                </td>
              ))}
            </tr>
          </tfoot>
        </table>
      </div>

      <div style={{ padding: '14px 20px', borderTop: '1px solid var(--tn-rule)', background: 'var(--tn-paper)', fontSize: 11, color: 'var(--tn-ink-4)', fontFamily: 'var(--tn-font-mono)', lineHeight: 1.6 }}>
        Podatci: Povjerenstvo za odlučivanje o sukobu interesa (sukobinteresa.hr) · originalni PDF-ovi u kartici <a href="#" style={{ color: 'var(--tn-navy-700)' }}>Izvori</a> · normalizacija i indeksiranje: Transparentno.hr
      </div>
    </div>
  );
};

// ── Plain tab-panel tables ────────────────────────────────────
const TabTable = ({ columns, rows, footer }) => (
  <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', overflow: 'hidden' }}>
    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
      <thead>
        <tr style={{ background: 'var(--tn-paper-2)' }}>
          {columns.map((c, i) => (
            <th key={i} style={{
              textAlign: c.align || 'left', padding: '10px 14px',
              fontSize: 10, fontWeight: 500, letterSpacing: 0.08, textTransform: 'uppercase',
              color: 'var(--tn-ink-4)', borderBottom: '1px solid var(--tn-rule)',
              width: c.width,
            }}>{c.label}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((r, i) => (
          <tr key={i} style={{ borderBottom: '1px solid var(--tn-rule-2)' }}>
            {r.map((cell, j) => (
              <td key={j} style={{
                textAlign: columns[j].align || 'left',
                padding: '11px 14px',
                color: 'var(--tn-ink-2)',
                fontFamily: columns[j].mono ? 'var(--tn-font-mono)' : 'inherit',
                fontVariantNumeric: columns[j].mono ? 'tabular-nums' : 'normal',
              }}>{cell}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
    {footer && <div style={{ padding: '10px 14px', fontSize: 11, color: 'var(--tn-ink-4)', background: 'var(--tn-paper)', borderTop: '1px solid var(--tn-rule-2)' }}>{footer}</div>}
  </div>
);

Object.assign(window, {
  SensitiveDOB, CanonicalIDs, RangeScrubber,
  TimelineEvent, MiniGraph, ImovinaCompare, TabTable, EVENT_KINDS,
});
