/* Design System artboard — tokens, type, components */

const DesignSystemScreen = () => {
  const swatch = (name, val, textLight = false) => (
    <div style={{ background: val, padding: '14px 14px 12px', borderRadius: 2, border: '1px solid var(--tn-rule-2)' }}>
      <div style={{ color: textLight ? '#fff' : 'var(--tn-ink-2)', fontSize: 12, fontWeight: 600, fontFamily: 'var(--tn-font-mono)' }}>{name}</div>
      <div style={{ color: textLight ? 'rgba(255,255,255,.7)' : 'var(--tn-ink-4)', fontSize: 11, fontFamily: 'var(--tn-font-mono)', marginTop: 2 }}>{val}</div>
    </div>
  );

  return (
    <div className="tn-root" style={{ padding: '40px 48px', minHeight: '100%', background: 'var(--tn-paper)' }}>
      {/* Masthead */}
      <div style={{ paddingBottom: 28, borderBottom: '2px solid var(--tn-navy-800)', marginBottom: 32 }}>
        <div className="tn-caps" style={{ color: 'var(--tn-navy-800)' }}>Dizajnerski sustav — v0.1</div>
        <h1 className="tn-serif" style={{ fontSize: 44, fontWeight: 500, marginTop: 6, color: 'var(--tn-navy-900)', letterSpacing: -1 }}>
          Transparentno.hr
        </h1>
        <p style={{ fontSize: 15, color: 'var(--tn-ink-3)', marginTop: 8, maxWidth: 640, lineHeight: 1.6 }}>
          Institucionalni, činjenični vizualni jezik za federiranu pretragu javnih registara.
          Nema narativa, nema pretpostavki — samo podaci s jasnom provenijencijom.
        </p>
      </div>

      {/* ── Palette ───────────────────────────────────────── */}
      <section style={{ marginBottom: 40 }}>
        <SectionH subtitle="Navy — authoritet. Amber — rezervirano isključivo za iznimna stanja. Bez dekorativne boje.">Paleta</SectionH>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 10, marginBottom: 16 }}>
          {swatch('navy-900', '#071a38', true)}
          {swatch('navy-800', '#0b2545', true)}
          {swatch('navy-700', '#13315c', true)}
          {swatch('navy-500', '#2f5687', true)}
          {swatch('navy-100', '#dfe5ef')}
          {swatch('navy-50',  '#eef1f7')}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 10, marginBottom: 16 }}>
          {swatch('ink',     '#141414', true)}
          {swatch('ink-3',   '#4a4a45', true)}
          {swatch('ink-4',   '#6b6b63', true)}
          {swatch('rule',    '#d9d8cf')}
          {swatch('paper-2', '#f3f1e8')}
          {swatch('paper',   '#fafaf5')}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 10 }}>
          {swatch('amber',      '#d97706', true)}
          {swatch('amber-weak', '#fef3c7')}
          {swatch('verify',     '#2f6b3f', true)}
          {swatch('verify-weak','#e5eee3')}
          <div style={{ gridColumn: 'span 2', display: 'flex', alignItems: 'center', padding: '14px 16px', background: 'var(--tn-amber-weak)', border: '1px solid var(--tn-amber)', borderRadius: 2, fontSize: 12, color: 'var(--tn-amber-ink)' }}>
            <Icon name="warn" size={14} stroke={2} style={{ marginRight: 8 }}/>
            Amber se koristi <strong style={{ margin: '0 4px' }}>samo</strong> za iznimna stanja.
          </div>
        </div>
      </section>

      {/* ── Typography ────────────────────────────────────── */}
      <section style={{ marginBottom: 40 }}>
        <SectionH subtitle="IBM Plex Serif za imena entiteta. IBM Plex Sans za UI. IBM Plex Mono za identifikatore i vremenske oznake.">Tipografija</SectionH>
        <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: 24 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', rowGap: 18, columnGap: 24, alignItems: 'baseline' }}>
            <span className="tn-caps">Display · 40</span>
            <span className="tn-serif" style={{ fontSize: 40, fontWeight: 500, color: 'var(--tn-navy-900)', letterSpacing: -0.8 }}>Andrej Plenković</span>
            <span className="tn-caps">H1 · 28</span>
            <span style={{ fontSize: 28, fontWeight: 600, color: 'var(--tn-ink-2)', letterSpacing: -0.4 }}>Sudski registar · HR-5483201</span>
            <span className="tn-caps">H2 · 20</span>
            <span style={{ fontSize: 20, fontWeight: 600, color: 'var(--tn-ink-2)' }}>Povezane pravne osobe</span>
            <span className="tn-caps">Body · 14</span>
            <span style={{ fontSize: 14, color: 'var(--tn-ink)', lineHeight: 1.55 }}>
              Svaki činjenični element na stranici sadrži lanac provenijencije prema službenom izvoru.
            </span>
            <span className="tn-caps">Mono · 13</span>
            <span className="tn-mono tn-tnum" style={{ fontSize: 13, color: 'var(--tn-ink-2)' }}>OIB 73278161panel · 2026-04-14T08:41:22Z</span>
            <span className="tn-caps">Caps · 11</span>
            <span className="tn-caps">Osoba · Pravna osoba · Nekretnina</span>
          </div>
        </div>
      </section>

      {/* ── Spacing scale ─────────────────────────────────── */}
      <section style={{ marginBottom: 40 }}>
        <SectionH subtitle="Osnovna jedinica 4px. Koristi —s-1 do —s-9.">Prostor</SectionH>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 12 }}>
          {[4,8,12,16,24,32,48,64,96].map((n, i) => (
            <div key={n} style={{ textAlign: 'center' }}>
              <div style={{ width: n, height: n, background: 'var(--tn-navy-700)', marginBottom: 6 }}/>
              <div className="tn-mono" style={{ fontSize: 11, color: 'var(--tn-ink-4)' }}>s-{i+1}</div>
              <div className="tn-mono" style={{ fontSize: 10, color: 'var(--tn-ink-5)' }}>{n}px</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Components ────────────────────────────────────── */}
      <section style={{ marginBottom: 40 }}>
        <SectionH subtitle="Inventar · 9 primitivnih komponenti čini 95% sučelja.">Komponente</SectionH>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          {/* Buttons */}
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: 20 }}>
            <div className="tn-caps" style={{ marginBottom: 12 }}>Button</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
              <Button>Otvori profil</Button>
              <Button variant="secondary" icon="download">Preuzmi CSV</Button>
              <Button variant="ghost" iconRight="external">Službeni izvor</Button>
              <Button variant="danger" icon="warn">Prijavi netočnost</Button>
              <Button size="sm" variant="secondary">Filtriraj</Button>
            </div>
          </div>

          {/* SourceBadge */}
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: 20 }}>
            <div className="tn-caps" style={{ marginBottom: 12 }}>SourceBadge · atomska jedinica provenijencije</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              <SourceBadge source="Sudski registar" retrieved="2026-04-22T11:03Z" url="#">MBS 080012345</SourceBadge>
              <SourceBadge source="FINA" retrieved="2026-04-15" url="#">Prihod 4,28 mil. EUR</SourceBadge>
              <SourceBadge source="EOJN" retrieved="2026-04-20" url="#" tone="verify">Ugovor 2025-EOJN-8842</SourceBadge>
              <SourceBadge source="Porezna uprava — popis dužnika" retrieved="2026-04-15" url="#" tone="amber">Dug 184.302 EUR</SourceBadge>
            </div>
            <div style={{ marginTop: 10, fontSize: 12, color: 'var(--tn-ink-4)', fontStyle: 'italic' }}>
              Pređite mišem preko bilo koje oznake za izvor i vrijeme dohvata.
            </div>
          </div>

          {/* Chips */}
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: 20 }}>
            <div className="tn-caps" style={{ marginBottom: 12 }}>Chip · Filter</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              <Chip active>Osoba</Chip>
              <Chip>Pravna osoba</Chip>
              <Chip>Nekretnina</Chip>
              <Chip>Događaj</Chip>
              <Chip tone="outline" icon="x">Zagreb</Chip>
              <Chip tone="navy">Od 2020</Chip>
            </div>
          </div>

          {/* WarnBadge */}
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: 20 }}>
            <div className="tn-caps" style={{ marginBottom: 12 }}>WarnBadge · Iznimna stanja</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              <WarnBadge>Na popisu poreznih dužnika</WarnBadge>
              <WarnBadge>Istraga · USKOK</WarnBadge>
              <WarnBadge>Stečaj</WarnBadge>
            </div>
            <div style={{ marginTop: 10, fontSize: 12, color: 'var(--tn-ink-4)', fontStyle: 'italic' }}>
              Amber je rezerviran isključivo za činjenice iznimnih stanja iz službenih registara.
            </div>
          </div>

          {/* MetricStat */}
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: 20 }}>
            <div className="tn-caps" style={{ marginBottom: 12 }}>MetricStat</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <MetricStat label="Prihod 2024" value="4,28" unit="mil. EUR" delta="↑ 12,4% u odnosu na 2023"/>
              <MetricStat label="Zaposleni" value="47" delta="ožujak 2025"/>
            </div>
          </div>

          {/* TimelineItem */}
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: 20 }}>
            <div className="tn-caps" style={{ marginBottom: 12 }}>TimelineItem</div>
            <TimelineItem date="14. trav 2026" dateRaw="2026-04-14" kind="UGOVOR" title="Nabava uredske opreme · 84.200 EUR" source="EOJN" retrieved="2026-04-15" url="#">
              Naručitelj: Grad Zagreb · Postupak: otvoreni
            </TimelineItem>
            <TimelineItem date="02. velj 2026" dateRaw="2026-02-02" kind="RJEŠENJE" title="Vpis promjene djelatnosti" source="Sudski registar" retrieved="2026-02-03" url="#" last/>
          </div>
        </div>
      </section>

      {/* ── IA principles ─────────────────────────────────── */}
      <section style={{ marginBottom: 16 }}>
        <SectionH>Načela sučelja</SectionH>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {[
            ['Provenijencija prva', 'Svaka činjenica ima lanac prema službenom izvoru i vremenu dohvata. Bez izvora — bez činjenice.'],
            ['Bez narativa', 'Ne generiramo prozni tekst o pojedincima. Ne impliciramo veze. Sučelje prikazuje podatke, ne zaključke.'],
            ['Bilingvalno', 'HR je primarni registar. EN je ravnopravan drugi. Oba su istodobno ispravna — nema „lite" verzije.'],
          ].map(([h, p]) => (
            <div key={h} style={{ paddingTop: 12, borderTop: '2px solid var(--tn-navy-800)' }}>
              <h3 style={{ fontSize: 14, color: 'var(--tn-navy-800)', marginBottom: 6 }}>{h}</h3>
              <p style={{ fontSize: 13, color: 'var(--tn-ink-3)', lineHeight: 1.55 }}>{p}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

window.DesignSystemScreen = DesignSystemScreen;
