/* Graph view — full-screen network explorer.
   Left rail (56px · icons) · top toolbar · canvas · right panel (360px).
   Custom SVG renderer styled like Cytoscape/Oligrapher with static layouts
   (force/hierarchical/concentric are pre-computed coord sets).            */

// ── Data model ─────────────────────────────────────────────────────
const NODE_TYPES = {
  person:   { label: 'Osoba',           glyph: 'person',   fill: 'var(--tn-navy-800)', text: '#fff', stroke: 'var(--tn-navy-800)' },
  org:      { label: 'Pravna osoba',     glyph: 'building', fill: '#fff',               text: 'var(--tn-navy-800)', stroke: 'var(--tn-navy-600)' },
  state:    { label: 'Državno tijelo',   glyph: 'building', fill: '#fff',               text: 'var(--tn-navy-900)', stroke: 'var(--tn-navy-900)' },
  asset:    { label: 'Nekretnina',       glyph: 'parcel',   fill: '#fff',               text: 'var(--tn-ink-2)',    stroke: 'var(--tn-ink-3)' },
  event:    { label: 'Ugovor / događaj', glyph: 'event',    fill: '#fff',               text: '#7a6f4a',            stroke: '#b49b55' },
  court:    { label: 'Sudski spis',      glyph: 'doc',      fill: '#fff',               text: '#5c4a3d',            stroke: '#8a6a54' },
  location: { label: 'Lokacija',         glyph: 'map',      fill: 'var(--tn-paper-2)',   text: 'var(--tn-ink-3)',    stroke: 'var(--tn-ink-4)' },
};

const REL_TYPES = {
  owner:    { label: 'Vlasnik',         color: '#0b2545' },
  officer:  { label: 'Funkcija',         color: '#3a5f8a' },
  related:  { label: 'Povezana os.',    color: '#7a6f4a' },
  contract: { label: 'Ugovor',           color: '#b8731f' },
  court:    { label: 'Sudski postupak', color: '#8a3a2a' },
  located:  { label: 'Nalazi se u',     color: '#9a9a8f' },
};

// Coordinate sets for 3 layouts on the same graph
const LAYOUTS = {
  force: {
    n_ap:    [ 640, 380 ], n_vlada: [ 340, 260 ], n_hdz:   [ 380, 540 ],
    n_pp:    [ 900, 280 ], n_gp:    [ 880, 500 ], n_ug1:   [ 1060, 200 ],
    n_ug2:   [ 200, 620 ], n_k1:    [ 720, 620 ], n_k2:    [ 520, 660 ],
    n_mvp:   [ 160, 340 ], n_sg:    [  80, 520 ], n_nb:    [ 440, 120 ],
    n_ht:    [ 1080, 420 ], n_mf:   [ 240, 120 ], n_eojn:  [ 1140, 100 ],
    n_pula:  [ 440, 740 ], n_ts:    [ 780, 760 ],
  },
  hierarchical: {
    n_nb:    [  240, 120 ], n_mf:    [  520, 120 ], n_eojn: [ 880, 120 ],
    n_vlada: [  240, 260 ], n_hdz:   [  520, 260 ], n_pp:   [ 880, 260 ],
    n_ap:    [  640, 400 ],
    n_mvp:   [  160, 540 ], n_sg:    [  400, 540 ], n_gp:   [ 640, 540 ], n_ug1:  [  880, 540 ], n_ug2: [ 1120, 540 ],
    n_k1:    [  240, 700 ], n_k2:    [  440, 700 ], n_ht:   [ 640, 700 ], n_ts:   [  840, 700 ], n_pula:[ 1040, 700 ],
  },
  concentric: {
    n_ap:    [ 620, 400 ],
    // inner ring — direct ties (d=1)
    n_vlada: [ 620, 220 ], n_hdz: [ 440, 310 ], n_pp:  [ 440, 490 ],
    n_gp:    [ 620, 580 ], n_k1:  [ 800, 490 ], n_k2:  [ 800, 310 ], n_ht: [ 900, 400 ],
    // outer ring — d=2
    n_nb:    [ 620,  60 ], n_mf:   [ 290, 130 ], n_mvp: [ 130, 260 ],
    n_sg:    [ 110, 400 ], n_ug2:  [ 130, 540 ], n_pula:[ 290, 670 ],
    n_ts:    [ 620, 740 ], n_ug1:  [ 950, 670 ], n_eojn:[ 1110, 540 ],
  },
};

const graphNodes = [
  // ── Person: the arrival entity ─────────────────────────
  { id: 'n_ap',    type: 'person', label: 'Andrej Plenković',           sub: 'premijer · javna osoba',
    score: 95, flag: null,          notability: 'public' },
  { id: 'n_gp',    type: 'person', label: 'Gabrijela Plenković',        sub: 'bračni drug',
    score: 32, flag: null },
  { id: 'n_nb',    type: 'person', label: 'Nina Obuljen Koržinek',      sub: 'ministrica kulture',
    score: 42, flag: null,          notability: 'public' },
  { id: 'n_sg',    type: 'person', label: 'Stjepan Glasnović',          sub: 'veleposlanik RH',
    score: 22, flag: null },
  // ── Organisations ──────────────────────────────────────
  { id: 'n_vlada', type: 'state',  label: 'Vlada Republike Hrvatske',   sub: 'ustavno tijelo',
    score: 78, flag: null },
  { id: 'n_mvp',   type: 'state',  label: 'Ministarstvo vanjskih i europskih poslova', sub: 'ministarstvo',
    score: 58, flag: null },
  { id: 'n_mf',    type: 'state',  label: 'Ministarstvo financija',      sub: 'ministarstvo',
    score: 55, flag: null },
  { id: 'n_eojn',  type: 'state',  label: 'EOJN · Portal javne nabave', sub: 'državni portal',
    score: 48, flag: null },
  { id: 'n_hdz',   type: 'org',    label: 'HDZ',                         sub: 'politička stranka',
    score: 66, flag: null },
  { id: 'n_pp',    type: 'org',    label: 'Plenković & Partneri j.t.d.', sub: 'javno trg. društvo',
    score: 38, flag: 'amber',       flagNote: 'Povezana osoba na popisu porez. dužnika' },
  { id: 'n_ht',    type: 'org',    label: 'HT d.d.',                     sub: '214 dionica',
    score: 26, flag: null },
  // ── Events / contracts / court ─────────────────────────
  { id: 'n_ug1',   type: 'event',  label: 'Ugovor 2025-EOJN-8842',       sub: 'IT nabava · 1,4 mil. EUR',
    score: 18, flag: null,          amount: 1_420_000 },
  { id: 'n_ug2',   type: 'event',  label: 'Donacija HDZ-u · 2023',       sub: 'financiranje kampanje',
    score: 14, flag: null,          amount: 52_000 },
  { id: 'n_ts',    type: 'court',  label: 'P-2024-442 / TS Zagreb',      sub: 'parnica · u tijeku',
    score: 12, flag: null },
  // ── Assets / locations ─────────────────────────────────
  { id: 'n_k1',    type: 'asset',  label: 'Stan · Donji Grad 4782/2',    sub: '112 m² · vl. 1/1',
    score: 16, flag: null },
  { id: 'n_k2',    type: 'asset',  label: 'Kuća · Zagorje',               sub: '220 m² · vl. 1/1',
    score: 16, flag: null },
  { id: 'n_pula',  type: 'location', label: 'k.č. 1804 k.o. Pula',        sub: 'lokacija · katastar',
    score: 10, flag: null },
];

const graphEdges = [
  // [from, to, relType, label, date, amount]
  ['n_ap',    'n_vlada', 'officer',  'premijer · od 2016', '2016-10-19', null],
  ['n_ap',    'n_hdz',   'officer',  'predsjednik · od 2016', '2016-07-17', null],
  ['n_ap',    'n_pp',    'owner',    'partner · 33% udjela', '2008-05-12', null],
  ['n_ap',    'n_gp',    'related',  'bračni drug',           '2005-06-04', null],
  ['n_vlada', 'n_mvp',   'officer',  'resor',                 '—',           null],
  ['n_vlada', 'n_mf',    'officer',  'resor',                 '—',           null],
  ['n_vlada', 'n_nb',    'officer',  'ministrica kulture',    '2020-07-23', null],
  ['n_mvp',   'n_sg',    'officer',  'veleposlanik',          '2021-03-01', null],
  ['n_pp',    'n_ug1',   'contract', 'izvršitelj',            '2025-02-18', 1_420_000],
  ['n_eojn',  'n_ug1',   'contract', 'objavio',               '2025-02-18', 1_420_000],
  ['n_hdz',   'n_ug2',   'contract', 'primatelj',             '2023-11-03', 52_000],
  ['n_ap',    'n_k1',    'owner',    'vlasnik 1/1',           '2018-09-12', null],
  ['n_ap',    'n_k2',    'owner',    'vlasnik 1/1',           '2012-04-02', null],
  ['n_ap',    'n_ht',    'owner',    'dioničar · 214 dionica', '2019-01-14', null],
  ['n_gp',    'n_k1',    'related',  'navedena u kartici',    '2018-09-12', null],
  ['n_k1',    'n_pula',  'located',  'k.č. 1804',             '—',           null],
  ['n_pp',    'n_ts',    'court',    'tuženi',                '2024-06-22', null],
  ['n_mf',    'n_eojn',  'officer',  'nadležno tijelo',        '—',           null],
];

// ── Main screen ────────────────────────────────────────────────────
const GraphScreen = () => {
  const [selected, setSelected]     = React.useState('n_ap');
  const [hover, setHover]           = React.useState(null);
  const [depth, setDepth]           = React.useState(2);
  const [layout, setLayout]         = React.useState('force');
  const [panelOpen, setPanelOpen]   = React.useState(true);
  const [relToggles, setRelToggles] = React.useState({
    owner: true, officer: true, related: true, contract: true, court: true, located: false,
  });
  const [minAmount, setMinAmount]   = React.useState(0);
  const [timeRange, setTimeRange]   = React.useState([2005, 2026]);
  const [pinned, setPinned]         = React.useState(new Set(['n_ap']));
  const [contextMenu, setContextMenu] = React.useState(null);
  const [pathTarget, setPathTarget] = React.useState(null);
  const [searchQuery, setSearchQuery] = React.useState('');

  // Filtered edges
  const visibleEdges = graphEdges.filter(([,, rel, , date, amount]) => {
    if (!relToggles[rel]) return false;
    if (amount && amount < minAmount * 1000) return false;
    if (date && date !== '—') {
      const y = parseInt(date.slice(0, 4));
      if (y < timeRange[0] || y > timeRange[1]) return false;
    }
    return true;
  });

  // Shortest path BFS between first two pinned nodes
  const pinnedArr = [...pinned];
  const pathEdges = React.useMemo(() => {
    if (pinnedArr.length < 2 || !pathTarget) return new Set();
    const adj = {};
    visibleEdges.forEach(([a, b]) => {
      (adj[a] ||= []).push(b); (adj[b] ||= []).push(a);
    });
    const start = pinnedArr[0], end = pathTarget;
    const prev = { [start]: null };
    const q = [start];
    while (q.length) {
      const cur = q.shift();
      if (cur === end) break;
      (adj[cur] || []).forEach(n => { if (!(n in prev)) { prev[n] = cur; q.push(n); } });
    }
    const edges = new Set();
    let cur = end;
    while (prev[cur] !== undefined && prev[cur] !== null) {
      const key = [cur, prev[cur]].sort().join('|');
      edges.add(key);
      cur = prev[cur];
    }
    return edges;
  }, [pinned, pathTarget, visibleEdges]);

  // Node positions
  const coords = LAYOUTS[layout];

  // Highlight calculations
  const sel = graphNodes.find(n => n.id === selected);
  const activeEdgeKeys = new Set(visibleEdges
    .filter(e => e[0] === selected || e[1] === selected)
    .map(e => [e[0], e[1]].sort().join('|'))
  );
  const neighborIds = new Set(visibleEdges
    .filter(e => e[0] === selected || e[1] === selected)
    .map(e => e[0] === selected ? e[1] : e[0])
  );

  // Search match
  const matchIds = new Set();
  if (searchQuery.trim()) {
    graphNodes.forEach(n => {
      if (n.label.toLowerCase().includes(searchQuery.toLowerCase())) matchIds.add(n.id);
    });
  }

  const togglePin = (id) => {
    setPinned(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const onNodeContextMenu = (e, id) => {
    e.preventDefault();
    const rect = e.currentTarget.closest('.tn-graph-canvas').getBoundingClientRect();
    setContextMenu({ x: e.clientX - rect.left, y: e.clientY - rect.top, nodeId: id });
  };

  return (
    <div className="tn-root" style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--tn-paper)' }}>
      <TopBar currentPath="graph"/>

      {/* ── Top toolbar ──────────────────────────────────────── */}
      <GraphTopToolbar
        depth={depth} setDepth={setDepth}
        layout={layout} setLayout={setLayout}
        relToggles={relToggles} setRelToggles={setRelToggles}
        minAmount={minAmount} setMinAmount={setMinAmount}
        timeRange={timeRange} setTimeRange={setTimeRange}
        searchQuery={searchQuery} setSearchQuery={setSearchQuery}
        matchCount={matchIds.size}
        panelOpen={panelOpen} setPanelOpen={setPanelOpen}
      />

      {/* ── Main: left rail · canvas · right panel ──────────── */}
      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        <GraphLeftRail/>

        {/* Canvas */}
        <div
          className="tn-graph-canvas"
          style={{
            flex: 1, position: 'relative', overflow: 'hidden',
            background: 'var(--tn-paper)',
            backgroundImage:
              'linear-gradient(var(--tn-rule-2) 1px, transparent 1px),' +
              'linear-gradient(90deg, var(--tn-rule-2) 1px, transparent 1px)',
            backgroundSize: '32px 32px',
          }}
          onClick={() => setContextMenu(null)}
        >
          {/* Arrival ribbon */}
          <div style={{
            position: 'absolute', top: 12, left: 12, display: 'flex', gap: 6,
            alignItems: 'center', fontSize: 11, color: 'var(--tn-ink-4)',
            background: 'var(--tn-white)', border: '1px solid var(--tn-rule)',
            padding: '6px 10px', fontFamily: 'var(--tn-font-mono)',
          }}>
            <Icon name="link" size={11}/>
            <span>/mreza/entity/</span>
            <span style={{ color: 'var(--tn-navy-800)', fontWeight: 600 }}>osoba-andrej-plenkovic</span>
            <span style={{ margin: '0 4px', color: 'var(--tn-rule)' }}>·</span>
            <span>dubina {depth} hop</span>
            <span style={{ margin: '0 4px', color: 'var(--tn-rule)' }}>·</span>
            <span>{graphNodes.length} čv. · {visibleEdges.length}/{graphEdges.length} veza</span>
          </div>

          {/* Path-finding banner */}
          {pinnedArr.length >= 2 && (
            <PathFindingBanner
              pinned={pinnedArr}
              nodes={graphNodes}
              pathTarget={pathTarget}
              setPathTarget={setPathTarget}
            />
          )}

          <GraphCanvasSvg
            nodes={graphNodes}
            edges={visibleEdges}
            coords={coords}
            selected={selected}
            hover={hover}
            pinned={pinned}
            matchIds={matchIds}
            pathEdges={pathEdges}
            activeEdgeKeys={activeEdgeKeys}
            neighborIds={neighborIds}
            onSelect={setSelected}
            onHover={setHover}
            onContextMenu={onNodeContextMenu}
          />

          <GraphLegend/>
          <GraphZoomCluster/>

          {contextMenu && (
            <GraphContextMenu
              cm={contextMenu}
              node={graphNodes.find(n => n.id === contextMenu.nodeId)}
              pinned={pinned}
              onClose={() => setContextMenu(null)}
              onPin={() => { togglePin(contextMenu.nodeId); setContextMenu(null); }}
              onSelect={() => { setSelected(contextMenu.nodeId); setContextMenu(null); }}
              onPathTo={() => { setPathTarget(contextMenu.nodeId); setContextMenu(null); }}
            />
          )}
        </div>

        {/* Right panel */}
        {panelOpen && (
          <GraphInspector
            node={sel}
            edges={visibleEdges}
            nodes={graphNodes}
            pinned={pinned}
            onSelect={setSelected}
            onPin={togglePin}
            onClose={() => setPanelOpen(false)}
          />
        )}
      </div>
    </div>
  );
};

window.GraphScreen = GraphScreen;
