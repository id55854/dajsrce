/* Search results screen — v2
   Same sidebar layout. New: type chips, advanced-filter chips,
   results grouped by type (max 5/group), richer entity rows with
   source-badge cluster, 12-month activity spark, amber-dot flag. */

const SearchScreen = () => {
  const [q, setQ] = React.useState('plenković');
  const [typeFilter, setTypeFilter] = React.useState('all');

  // Advanced filter toggles
  const [advPEP, setAdvPEP] = React.useState(true);
  const [advActive, setAdvActive] = React.useState(false);
  const [adv12m, setAdv12m] = React.useState(false);

  // ── Data ──
  // Each row has: type, name, descriptor, sources[], spark[] (12 monthly
  // counts), flag (exceptional state string or null), meta (display only)
  const spark = (arr) => arr;
  const groups = [
    {
      key: 'person', icon: 'person', label: 'Osobe', total: 12,
      rows: [
        { name: 'Andrej Plenković',
          descriptor: 'Ministar — Vlada RH (od 2016) · predsjednik HDZ-a · OIB 73278161820',
          sources: ['Imovinske kartice', 'Sudski registar', 'DIP'],
          spark: spark([2,1,3,2,4,3,5,2,3,6,4,3]),
          flag: null,
        },
        { name: 'Gabrijela Plenković',
          descriptor: 'Član nadzornog odbora — Plenković & Partneri · Zagreb',
          sources: ['Sudski registar'],
          spark: spark([0,0,1,0,0,0,1,0,0,0,0,1]),
          flag: null,
        },
        { name: 'Davor Plenković',
          descriptor: 'Direktor — Vila Plenković d.o.o. (od 2019) · Opatija',
          sources: ['Sudski registar', 'FINA RGFI'],
          spark: spark([1,0,0,1,2,1,0,0,1,0,1,2]),
          flag: null,
        },
        { name: 'Ana Plenković-Horvat',
          descriptor: 'Javni bilježnik · Javnobilježnička komora — Zagreb',
          sources: ['Registar JB', 'Sudski registar'],
          spark: spark([0,0,0,0,0,1,0,0,0,0,0,0]),
          flag: null,
        },
        { name: 'Ivan Plenković',
          descriptor: 'Obrtnik (aktivan) · Obrt za ugostiteljstvo "IVA" · Rijeka',
          sources: ['Obrtni registar', 'Porezna uprava'],
          spark: spark([0,1,0,0,0,0,0,1,0,0,0,0]),
          flag: 'Na popisu poreznih dužnika',
        },
      ],
    },
    {
      key: 'org', icon: 'building', label: 'Subjekti', total: 34,
      rows: [
        { name: 'Plenković & Partneri j.t.d.',
          descriptor: 'j.t.d. aktivno — Zagreb, osnovano 2014 · pravno savjetovanje · 4 zaposlena',
          sources: ['Sudski registar', 'FINA RGFI', 'EOJN'],
          spark: spark([3,2,4,5,3,6,4,5,7,4,3,5]),
          flag: 'Na popisu poreznih dužnika',
        },
        { name: 'Vila Plenković d.o.o.',
          descriptor: 'd.o.o. aktivno — Opatija, osnovano 2019 · ugostiteljstvo · 14 zaposlenih',
          sources: ['Sudski registar', 'FINA RGFI'],
          spark: spark([0,1,2,1,3,2,1,4,3,2,1,2]),
          flag: null,
        },
        { name: 'Plenković Invest d.o.o.',
          descriptor: 'd.o.o. u likvidaciji — Zagreb, osnovano 2008 · trgovina nekretninama',
          sources: ['Sudski registar', 'FINA RGFI'],
          spark: spark([0,0,0,0,0,1,0,0,0,1,0,0]),
          flag: 'Stečajni postupak otvoren',
        },
        { name: 'AP Savjetovanje j.d.o.o.',
          descriptor: 'j.d.o.o. aktivno — Zagreb, osnovano 2022 · poslovno savjetovanje',
          sources: ['Sudski registar'],
          spark: spark([1,0,0,0,1,0,0,0,0,0,0,1]),
          flag: null,
        },
        { name: 'Plenković & Co. j.t.d.',
          descriptor: 'j.t.d. brisano — Split, brisano 2023-08-14',
          sources: ['Sudski registar'],
          spark: spark([0,0,0,0,0,0,0,0,0,0,0,0]),
          flag: null,
        },
      ],
    },
    {
      key: 'asset', icon: 'parcel', label: 'Nekretnine', total: 8,
      rows: [
        { name: 'k.č. 4782/2, k.o. Donji Grad',
          descriptor: 'Stan 112 m² · Zagreb — Ulica kralja Zvonimira · vlasnik: A. Plenković 1/1',
          sources: ['Katastar', 'ZK sud'],
          spark: spark([0,0,0,0,0,0,0,0,0,0,0,0]),
          flag: null,
        },
        { name: 'k.č. 812, k.o. Krapinske Toplice',
          descriptor: 'Kuća 180 m² + okućnica 1.420 m² · vlasnik: A. Plenković 1/1',
          sources: ['Katastar', 'ZK sud'],
          spark: spark([0,0,0,0,0,0,0,0,0,0,1,0]),
          flag: null,
        },
        { name: 'k.č. 2104/7, k.o. Opatija',
          descriptor: 'Poslovni prostor 88 m² · vlasnik: Vila Plenković d.o.o. · upisan 2019',
          sources: ['Katastar', 'ZK sud'],
          spark: spark([0,0,0,0,0,0,0,0,0,0,0,0]),
          flag: null,
        },
      ],
    },
    {
      key: 'body', icon: 'shield', label: 'Javna tijela', total: 3,
      rows: [
        { name: 'Vlada Republike Hrvatske',
          descriptor: 'Središnje tijelo izvršne vlasti · Trg sv. Marka 2, Zagreb',
          sources: ['Registar javnih tijela', 'EOJN', 'Narodne novine'],
          spark: spark([18,22,15,19,24,21,17,20,26,22,19,23]),
          flag: null,
        },
        { name: 'Ured predsjednika Vlade RH',
          descriptor: 'Stručna služba Vlade RH · proračun 2025: 14,2 mil. EUR',
          sources: ['Registar javnih tijela', 'EOJN'],
          spark: spark([2,3,1,2,4,3,2,3,5,2,1,3]),
          flag: null,
        },
      ],
    },
    {
      key: 'event', icon: 'event', label: 'Događaji', total: 193,
      rows: [
        { name: 'Ugovor 2025-EOJN-8842',
          descriptor: 'Nabava savjetodavnih usluga · Vlada RH → Plenković & Partneri · 184.200 EUR',
          sources: ['EOJN', 'Narodne novine'],
          spark: spark([0,0,0,0,0,0,0,0,0,0,0,1]),
          flag: null,
        },
        { name: 'Darovanje — HDZ · 18.03.2023',
          descriptor: 'Financijsko izvješće političke stranke · 12.000,00 EUR',
          sources: ['DIP'],
          spark: spark([0,0,0,0,0,0,0,0,0,0,0,0]),
          flag: null,
        },
        { name: 'Izmjena uprave — Vila Plenković d.o.o.',
          descriptor: 'Upis u Sudski registar · 2025-11-02 · imenovan novi direktor',
          sources: ['Sudski registar', 'Narodne novine'],
          spark: spark([0,0,0,0,0,0,0,0,0,0,1,0]),
          flag: null,
        },
        { name: 'Ovrha TD-2024-1184',
          descriptor: 'Ovršni postupak · protiv: Plenković Invest d.o.o. · 42.800 EUR',
          sources: ['e-Oglasna ploča'],
          spark: spark([0,0,0,0,0,0,0,0,0,0,0,1]),
          flag: 'Ovrha u tijeku',
        },
      ],
    },
  ];

  // Apply filter
  const visibleGroups = typeFilter === 'all' ? groups : groups.filter(g => g.key === typeFilter);
  const totalShown = groups.reduce((a, g) => a + g.total, 0);

  // Chip row of type filters
  const typeChips = [
    ['all', 'Sve', totalShown],
    ['person', 'Osobe', 12],
    ['org', 'Subjekti', 34],
    ['asset', 'Nekretnine', 8],
    ['body', 'Javna tijela', 3],
    ['event', 'Događaji', 193],
  ];

  // Empty state demo
  const noResults = q.trim().toLowerCase() === 'xyzzy';

  return (
    <div className="tn-root" style={{ minHeight: '100%', background: 'var(--tn-paper)' }}>
      <TopBar currentPath="search"/>

      {/* ── Search context bar ─────────────────────────────── */}
      <div style={{ background: 'var(--tn-white)', borderBottom: '1px solid var(--tn-rule)', padding: '20px 28px' }}>
        {/* Universal search, populated */}
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <div style={{
            flex: 1, display: 'flex', alignItems: 'center', gap: 12,
            padding: '12px 16px', background: 'var(--tn-white)',
            border: '1px solid var(--tn-navy-800)', borderRadius: 2,
            boxShadow: '0 1px 0 rgba(11,37,69,.04)',
          }}>
            <Icon name="search" size={18} style={{ color: 'var(--tn-navy-700)' }}/>
            <input value={q} onChange={e => setQ(e.target.value)}
              placeholder="Traži osobu, tvrtku, OIB, adresu, nekretninu…"
              style={{ flex: 1, border: 'none', outline: 'none', background: 'transparent',
                fontSize: 16, fontFamily: 'inherit', color: 'var(--tn-ink)' }}/>
            <button onClick={() => setQ('')} style={{ border: 'none', background: 'transparent', color: 'var(--tn-ink-4)', cursor: 'pointer', padding: 2 }}>
              <Icon name="x" size={13}/>
            </button>
          </div>
          <Button variant="secondary" icon="filter">Napredno</Button>
          <Button variant="secondary" icon="download">Izvoz</Button>
        </div>

        {/* Type chips */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 14, flexWrap: 'wrap' }}>
          {typeChips.map(([k, l, n]) => (
            <button key={k} onClick={() => setTypeFilter(k)} style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '6px 14px', borderRadius: 999,
              border: `1px solid ${typeFilter === k ? 'var(--tn-navy-800)' : 'var(--tn-rule)'}`,
              background: typeFilter === k ? 'var(--tn-navy-800)' : 'var(--tn-white)',
              color: typeFilter === k ? '#fff' : 'var(--tn-ink-2)',
              fontSize: 13, fontFamily: 'inherit', fontWeight: 500, cursor: 'pointer',
            }}>
              {l}
              <span className="tn-mono tn-tnum" style={{
                fontSize: 11, opacity: typeFilter === k ? .7 : .6,
              }}>{n}</span>
            </button>
          ))}
        </div>

        {/* Advanced filter chips (small, muted, toggle-able) */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 12, flexWrap: 'wrap' }}>
          <span className="tn-caps" style={{ color: 'var(--tn-ink-5)', fontSize: 10, marginRight: 2 }}>
            Napredno
          </span>
          {[
            ['Uključuje nositelje javnih dužnosti', advPEP, setAdvPEP],
            ['Samo aktivni subjekti', advActive, setAdvActive],
            ['Posljednjih 12 mjeseci', adv12m, setAdv12m],
          ].map(([l, on, setter]) => (
            <button key={l} onClick={() => setter(!on)} style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '3px 10px 3px 8px', borderRadius: 999,
              border: `1px solid ${on ? 'var(--tn-navy-700)' : 'var(--tn-rule)'}`,
              background: on ? 'var(--tn-navy-50)' : 'transparent',
              color: on ? 'var(--tn-navy-800)' : 'var(--tn-ink-4)',
              fontSize: 12, fontFamily: 'inherit', fontWeight: 500, cursor: 'pointer',
            }}>
              <span style={{
                width: 10, height: 10, borderRadius: 2,
                border: `1px solid ${on ? 'var(--tn-navy-800)' : 'var(--tn-ink-5)'}`,
                background: on ? 'var(--tn-navy-800)' : 'transparent',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                color: '#fff',
              }}>{on && <Icon name="check" size={7} stroke={2.5}/>}</span>
              {l}
            </button>
          ))}
        </div>
      </div>

      {/* ── Body: sidebar + results ────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: 0 }}>
        {/* Filter drawer — UNCHANGED per user request */}
        <aside style={{ padding: '24px 24px', borderRight: '1px solid var(--tn-rule)', background: 'var(--tn-paper)' }}>
          <div style={{ marginBottom: 24 }}>
            <div className="tn-caps" style={{ marginBottom: 10 }}>Izvor registara</div>
            {[['Sudski registar', 87], ['FINA · GFI', 34], ['EOJN', 62], ['Imovinske kartice', 14], ['Katastar', 8], ['Narodne novine', 19], ['DIP', 23]].map(([s, n], i) => (
              <label key={s} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0', fontSize: 13, color: 'var(--tn-ink-2)', cursor: 'pointer' }}>
                <input type="checkbox" defaultChecked={i < 4} style={{ accentColor: 'var(--tn-navy-800)' }}/>
                <span style={{ flex: 1 }}>{s}</span>
                <span className="tn-mono" style={{ fontSize: 11, color: 'var(--tn-ink-5)' }}>{n}</span>
              </label>
            ))}
          </div>
          <div style={{ marginBottom: 24 }}>
            <div className="tn-caps" style={{ marginBottom: 10 }}>Vremenski raspon</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
              <input placeholder="2020-01-01" className="tn-mono" style={{ padding: '6px 8px', border: '1px solid var(--tn-rule)', borderRadius: 2, fontSize: 12, fontFamily: 'var(--tn-font-mono)' }}/>
              <input placeholder="2026-04-23" className="tn-mono" style={{ padding: '6px 8px', border: '1px solid var(--tn-rule)', borderRadius: 2, fontSize: 12, fontFamily: 'var(--tn-font-mono)' }}/>
            </div>
          </div>
          <div style={{ marginBottom: 24 }}>
            <div className="tn-caps" style={{ marginBottom: 10 }}>Lokacija</div>
            <input placeholder="Županija ili grad…" style={{ width: '100%', padding: '6px 8px', border: '1px solid var(--tn-rule)', borderRadius: 2, fontSize: 13, fontFamily: 'inherit' }}/>
            <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 4 }}>
              <Chip tone="outline" icon="x">Zagreb</Chip>
              <Chip tone="outline" icon="x">Primorsko-goranska</Chip>
            </div>
          </div>
          <div style={{ marginBottom: 24 }}>
            <div className="tn-caps" style={{ marginBottom: 10 }}>Oznake</div>
            {[['Javni dužnosnik', true], ['Popis poreznih dužnika', false], ['Stečaj · likvidacija', false], ['Istraga · USKOK', false], ['Politički izloženo (PEP)', false]].map(([s, checked]) => (
              <label key={s} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0', fontSize: 13, color: 'var(--tn-ink-2)', cursor: 'pointer' }}>
                <input type="checkbox" defaultChecked={checked} style={{ accentColor: 'var(--tn-navy-800)' }}/>
                {s}
              </label>
            ))}
          </div>
          <div style={{ paddingTop: 16, borderTop: '1px solid var(--tn-rule)' }}>
            <Button variant="secondary" size="sm" style={{ width: '100%' }}>Poništi filtere</Button>
          </div>
        </aside>

        {/* Results */}
        <main style={{ background: 'var(--tn-white)' }}>
          {/* Result-count header */}
          <div style={{ padding: '18px 28px', borderBottom: '1px solid var(--tn-rule)', display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
            <div>
              <span style={{ fontSize: 13, color: 'var(--tn-ink-3)' }}>
                <strong style={{ color: 'var(--tn-ink-2)', fontWeight: 600 }}>{totalShown}</strong> rezultata za
                <span style={{ fontFamily: 'var(--tn-font-mono)', color: 'var(--tn-navy-800)', margin: '0 6px' }}>„{q}"</span>
                <span className="tn-mono" style={{ color: 'var(--tn-ink-5)' }}>· 0,184 s · 6 izvora</span>
              </span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 12, color: 'var(--tn-ink-4)' }}>
              <span>Poredaj:</span>
              <select style={{ padding: '4px 8px', border: '1px solid var(--tn-rule)', borderRadius: 2, fontSize: 12, fontFamily: 'inherit', background: 'var(--tn-white)' }}>
                <option>Relevantnost</option>
                <option>Najnovije aktivnosti</option>
                <option>Abecedno</option>
                <option>Broj zapisa</option>
              </select>
            </div>
          </div>

          {noResults ? (
            <EmptyState q={q}/>
          ) : (
            visibleGroups.map((g) => (
              <ResultGroup key={g.key} group={g}/>
            ))
          )}
        </main>
      </div>
    </div>
  );
};

// ── Result group ──
const ResultGroup = ({ group }) => {
  const shown = group.rows.slice(0, 5);
  return (
    <section>
      {/* Group header */}
      <div style={{
        display: 'flex', alignItems: 'baseline', gap: 10,
        padding: '20px 28px 10px',
        background: 'var(--tn-paper-2)',
        borderBottom: '1px solid var(--tn-rule-2)',
      }}>
        <span style={{ color: 'var(--tn-navy-700)', display: 'inline-flex', alignItems: 'center', alignSelf: 'center' }}>
          <Icon name={group.icon} size={14} stroke={1.6}/>
        </span>
        <h3 className="tn-caps" style={{ color: 'var(--tn-ink-2)', fontSize: 12, fontWeight: 600 }}>
          {group.label}
        </h3>
        <span className="tn-mono tn-tnum" style={{ fontSize: 12, color: 'var(--tn-ink-5)' }}>
          {group.total}
        </span>
      </div>

      {/* Rows */}
      {shown.map((r, i) => (
        <ResultRow key={i} row={r} icon={group.icon} typeLabel={group.label.slice(0, -1) || group.label}/>
      ))}

      {/* Show-all footer */}
      {group.total > 5 && (
        <div style={{
          padding: '14px 28px', borderBottom: '1px solid var(--tn-rule)',
          background: 'var(--tn-white)',
          display: 'flex', justifyContent: 'flex-end',
        }}>
          <a href="#" style={{
            fontSize: 13, color: 'var(--tn-navy-800)', fontWeight: 600,
            textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 6,
          }}>
            Prikaži sve {group.total} {group.label.toLowerCase()} <Icon name="arrow" size={12}/>
          </a>
        </div>
      )}
    </section>
  );
};

// ── Result row ──
const ResultRow = ({ row, icon }) => {
  const hasFlag = !!row.flag;
  const recent12m = row.spark.reduce((a, b) => a + b, 0);

  return (
    <article style={{
      display: 'grid',
      gridTemplateColumns: '44px 1fr 140px 28px',
      gap: 16,
      padding: '16px 28px',
      borderBottom: '1px solid var(--tn-rule-2)',
      alignItems: 'center',
      cursor: 'pointer',
      background: 'var(--tn-white)',
      position: 'relative',
      transition: 'background .12s',
    }}
    onMouseEnter={(e) => e.currentTarget.style.background = 'var(--tn-paper-2)'}
    onMouseLeave={(e) => e.currentTarget.style.background = 'var(--tn-white)'}>
      {/* Icon tile */}
      <div style={{
        width: 40, height: 40, borderRadius: 2,
        background: 'var(--tn-navy-50)', color: 'var(--tn-navy-700)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', flexShrink: 0,
      }}>
        <Icon name={icon} size={18} stroke={1.5}/>
        {hasFlag && (
          <span title={row.flag} style={{
            position: 'absolute', top: -3, right: -3,
            width: 10, height: 10, borderRadius: '50%',
            background: 'var(--tn-amber)',
            border: '2px solid var(--tn-white)',
          }}/>
        )}
      </div>

      {/* Name + descriptor + sources */}
      <div style={{ minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, flexWrap: 'wrap' }}>
          <h4 className="tn-serif" style={{
            fontSize: 17, fontWeight: 500, color: 'var(--tn-navy-800)',
            letterSpacing: -0.1, lineHeight: 1.2,
          }}>
            {row.name}
          </h4>
          {hasFlag && (
            <span style={{
              fontSize: 10, fontWeight: 600,
              color: 'var(--tn-amber-ink)', background: 'var(--tn-amber-weak)',
              border: '1px solid var(--tn-amber)',
              padding: '1px 6px', borderRadius: 2,
              textTransform: 'uppercase', letterSpacing: 0.3,
            }}>
              {row.flag}
            </span>
          )}
        </div>
        <div style={{ fontSize: 13, color: 'var(--tn-ink-3)', marginTop: 3, lineHeight: 1.4 }}>
          {row.descriptor}
        </div>

        {/* Source cluster */}
        <div style={{
          marginTop: 8, display: 'flex', alignItems: 'center', gap: 6,
          fontSize: 11, fontFamily: 'var(--tn-font-mono)', color: 'var(--tn-ink-4)',
        }}>
          <span style={{ color: 'var(--tn-ink-5)', letterSpacing: 0.3 }}>iz:</span>
          {row.sources.map((s, i) => (
            <React.Fragment key={s}>
              <span style={{
                padding: '1px 7px',
                background: 'var(--tn-paper-2)', border: '1px solid var(--tn-rule-2)',
                borderRadius: 2, color: 'var(--tn-ink-2)',
                display: 'inline-flex', alignItems: 'center', gap: 4,
              }}>
                <span style={{ width: 4, height: 4, borderRadius: '50%', background: 'var(--tn-verify)' }}/>
                {s}
              </span>
            </React.Fragment>
          ))}
          <span style={{ color: 'var(--tn-ink-5)', marginLeft: 4 }}>
            · dohvaćeno 2026-04-23
          </span>
        </div>
      </div>

      {/* 12-month activity spark */}
      <div style={{ textAlign: 'right' }}>
        {recent12m > 0 ? (
          <>
            <Spark data={row.spark}/>
            <div className="tn-mono" style={{ fontSize: 10, color: 'var(--tn-ink-5)', marginTop: 4, letterSpacing: 0.2 }}>
              {recent12m} aktivnosti · 12 mj.
            </div>
          </>
        ) : (
          <div className="tn-mono" style={{ fontSize: 10, color: 'var(--tn-ink-5)', letterSpacing: 0.2 }}>
            bez aktivnosti · 12 mj.
          </div>
        )}
      </div>

      {/* Arrow */}
      <div style={{ color: 'var(--tn-ink-5)', display: 'flex', justifyContent: 'center' }}>
        <Icon name="arrow" size={16}/>
      </div>
    </article>
  );
};

// ── 12-bar sparkline ──
const Spark = ({ data, width = 120, height = 28 }) => {
  const max = Math.max(1, ...data);
  const barW = width / data.length;
  return (
    <svg width={width} height={height} style={{ display: 'inline-block' }}>
      {data.map((v, i) => {
        const h = v === 0 ? 1.5 : Math.max(2, (v / max) * (height - 2));
        return (
          <rect key={i}
            x={i * barW + 1}
            y={height - h}
            width={Math.max(2, barW - 2)}
            height={h}
            fill={v === 0 ? 'var(--tn-rule)' : 'var(--tn-navy-700)'}
          />
        );
      })}
    </svg>
  );
};

// ── Empty state ──
const EmptyState = ({ q }) => (
  <div style={{
    padding: '80px 28px', textAlign: 'center',
    color: 'var(--tn-ink-3)',
  }}>
    <div style={{
      width: 56, height: 56, margin: '0 auto 20px',
      borderRadius: 2,
      background: 'var(--tn-paper-2)', border: '1px solid var(--tn-rule)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: 'var(--tn-ink-4)',
    }}>
      <Icon name="search" size={22} stroke={1.4}/>
    </div>
    <h3 className="tn-serif" style={{ fontSize: 24, fontWeight: 500, color: 'var(--tn-navy-900)', letterSpacing: -0.4 }}>
      Nema rezultata za <span style={{ fontFamily: 'var(--tn-font-mono)', color: 'var(--tn-ink-3)' }}>„{q}"</span>.
    </h3>
    <p style={{ fontSize: 14, color: 'var(--tn-ink-3)', marginTop: 10, maxWidth: 460, marginLeft: 'auto', marginRight: 'auto', lineHeight: 1.55 }}>
      Pokušajte drugačiji upit ili <a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>prijavite nedostajući subjekt</a>.
    </p>
    <div style={{ marginTop: 28, display: 'flex', gap: 8, justifyContent: 'center', flexWrap: 'wrap' }}>
      <span className="tn-caps" style={{ color: 'var(--tn-ink-5)', fontSize: 10, marginRight: 4, alignSelf: 'center' }}>
        Savjeti
      </span>
      {['pokušajte samo prezime', 'koristite OIB', 'pretražite s MBS', 'pretražite k.č. broj'].map((t) => (
        <span key={t} style={{
          fontSize: 12, padding: '4px 10px',
          background: 'var(--tn-paper-2)', border: '1px solid var(--tn-rule)',
          borderRadius: 999, color: 'var(--tn-ink-3)',
        }}>
          {t}
        </span>
      ))}
    </div>
  </div>
);

window.SearchScreen = SearchScreen;
