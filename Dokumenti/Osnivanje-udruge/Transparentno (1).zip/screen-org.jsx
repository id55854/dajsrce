/* Organisation page — canonical three-column layout.
   Full-width header strip · 6 KPIs · 3-col spine (280/fluid/360)
   · tabs: Financije · Ljudi · Ugovori s državom · Nekretnine ·
   Sudski spisi · Promjene · Izvori.                             */

const OrgScreen = () => {
  const [tab, setTab] = React.useState('ugovori');

  const timelineEvents = [
    { date: '2026-04-15', timeAgo: 'prije 9 d.', kind: 'filing',
      title: 'GFI za 2024. zaprimljen u FINA-i', sub: 'Godišnji financijski izvještaj · neto dobit 24,8 mil. EUR',
      source: 'FINA · rgfi.fina.hr', retrieved: '2026-04-15' },
    { date: '2026-03-12', timeAgo: 'prije 6 tj.', kind: 'contract',
      title: 'Dodijeljen ugovor — Transformatori 400 MVA',
      sub: 'Naručitelj: HEP d.d. · postupak: otvoreni',
      amount: '12.840.000 €',
      source: 'EOJN · nabava.gov.hr', retrieved: '2026-03-13' },
    { date: '2026-01-28', timeAgo: 'prije 3 mj.', kind: 'contract',
      title: 'Dodijeljen ugovor — Modernizacija signalizacije Dugo Selo–Križevci',
      sub: 'Naručitelj: HŽ Infrastruktura · postupak: otvoreni',
      amount: '8.412.000 €',
      source: 'EOJN · nabava.gov.hr', retrieved: '2026-01-30' },
    { date: '2025-11-02', timeAgo: 'prije 6 mj.', kind: 'officer',
      title: 'Promjena uprave — imenovana novi član uprave Ana Lukavski',
      sub: 'Dužnost: član uprave za operacije',
      source: 'Sudski registar · sudreg', retrieved: '2025-11-03' },
    { date: '2024-12-03', timeAgo: 'prije 17 mj.', kind: 'contract',
      title: 'Dodijeljen ugovor — Nadogradnja softvera za upravljanje distribucijom',
      sub: 'Naručitelj: HEP d.d. · postupak: otvoreni',
      amount: '2.820.000 €',
      source: 'EOJN · nabava.gov.hr', retrieved: '2024-12-04' },
    { date: '2024-06-28', timeAgo: 'prije 22 mj.', kind: 'capital',
      title: 'Povećanje temeljnog kapitala upisano u SR',
      sub: 'S 74,1 → 77,4 mil. EUR · emisija novih dionica',
      source: 'Sudski registar · sudreg', retrieved: '2024-07-01' },
    { date: '2024-03-18', timeAgo: 'prije 25 mj.', kind: 'courtNotice',
      title: 'Sudska obavijest — parnični postupak arhiviran',
      sub: 'TS-ZG-2023-1204 · tužitelj odustao',
      source: 'e-Oglasna ploča · eoglasna', retrieved: '2024-03-20' },
  ];

  return (
    <div className="tn-root" style={{ minHeight: '100%', background: 'var(--tn-paper)' }}>
      <TopBar currentPath="org"/>

      {/* Breadcrumb */}
      <div style={{ padding: '10px 28px', fontSize: 12, color: 'var(--tn-ink-4)', background: 'var(--tn-white)', borderBottom: '1px solid var(--tn-rule-2)' }}>
        <a href="#" style={{ color: 'var(--tn-ink-4)' }}>Pretraga</a>
        <span style={{ margin: '0 6px' }}>/</span>
        <a href="#" style={{ color: 'var(--tn-ink-4)' }}>Pravne osobe</a>
        <span style={{ margin: '0 6px' }}>/</span>
        <span style={{ color: 'var(--tn-ink-2)' }}>Končar — Elektroindustrija d.d.</span>
      </div>

      {/* ── Full-width header strip ─────────────────────────── */}
      <section style={{ background: 'var(--tn-white)', padding: '24px 28px 22px', borderBottom: '1px solid var(--tn-rule)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '72px 1fr auto', gap: 20, alignItems: 'flex-start' }}>
          {/* Logo placeholder */}
          <div style={{
            width: 72, height: 72, background: 'var(--tn-paper-2)',
            border: '1px solid var(--tn-rule)', borderRadius: 2,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            position: 'relative', overflow: 'hidden',
          }}>
            <svg width="72" height="72" viewBox="0 0 72 72" style={{ position: 'absolute', inset: 0 }}>
              <defs>
                <pattern id="logoDiag" patternUnits="userSpaceOnUse" width="5" height="5" patternTransform="rotate(45)">
                  <line x1="0" y1="0" x2="0" y2="5" stroke="var(--tn-ink-5)" strokeWidth="0.5" strokeOpacity="0.3"/>
                </pattern>
              </defs>
              <rect width="72" height="72" fill="url(#logoDiag)"/>
            </svg>
            <span className="tn-serif" style={{
              fontSize: 26, fontWeight: 500, color: 'var(--tn-navy-800)',
              position: 'relative', zIndex: 1,
            }}>K</span>
          </div>

          {/* Identity */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8, flexWrap: 'wrap' }}>
              <span className="tn-caps" style={{ color: 'var(--tn-navy-800)' }}>
                <Icon name="building" size={11} style={{ display: 'inline', marginRight: 4, verticalAlign: -1 }}/>
                Pravna osoba
              </span>
              <span style={{ height: 12, width: 1, background: 'var(--tn-rule)' }}/>
              <span style={{
                padding: '1px 8px', background: 'var(--tn-navy-50)', color: 'var(--tn-navy-800)',
                fontSize: 11, fontWeight: 600, borderRadius: 2, letterSpacing: 0.3, textTransform: 'uppercase',
              }}>d.d.</span>
              <span style={{
                display: 'inline-flex', alignItems: 'center', gap: 6,
                padding: '1px 10px', background: 'var(--tn-verify-weak)', color: 'var(--tn-verify)',
                border: '1px solid var(--tn-verify)',
                fontSize: 11, fontWeight: 600, borderRadius: 2, letterSpacing: 0.3, textTransform: 'uppercase',
              }}>
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--tn-verify)' }}/>
                aktivno
              </span>
              <span className="tn-mono" style={{ fontSize: 11, color: 'var(--tn-ink-5)' }}>ENT-HR-O-00012043</span>
            </div>
            <h1 className="tn-serif" style={{ fontSize: 34, fontWeight: 500, color: 'var(--tn-navy-900)', letterSpacing: -0.7, lineHeight: 1.1 }}>
              Končar — Elektroindustrija d.d.
            </h1>
            <div style={{ fontSize: 13, color: 'var(--tn-ink-3)', marginTop: 6 }}>
              Fallerovo šetalište 22, 10000 Zagreb · NKD 27.11 · proizvodnja elektromotora, generatora i transformatora
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
              <SourceBadge source="Porezna uprava" retrieved="2026-04-22" url="#">OIB 45050685848</SourceBadge>
              <SourceBadge source="Sudski registar" retrieved="2026-04-22" url="#">MBS 080028646</SourceBadge>
              <SourceBadge source="GLEIF" retrieved="2026-04-10" url="#">LEI 529900W5CZ3H...KONC</SourceBadge>
              <SourceBadge source="FINA · GFI 2024" retrieved="2026-04-15" url="#" tone="verify">GFI predan</SourceBadge>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 8 }}>
            <Button variant="secondary" size="sm" icon="download">Izvoz (PDF / JSON)</Button>
            <Button variant="ghost" size="sm" iconRight="link">Permalink</Button>
          </div>
        </div>
      </section>

      {/* ── Six-tile KPI strip ──────────────────────────────── */}
      <div style={{ background: 'var(--tn-paper-2)', padding: '18px 28px', borderBottom: '1px solid var(--tn-rule)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 10 }}>
          <KPI label="Zaposlenih" value="3.847" delta="prosjek 2024" trend="↑ 2,1%"/>
          <KPI label="Prihod · 2024" value="412" unit="mil. EUR" delta="FINA GFI" trend="↑ 8,1%"/>
          <KPI label="EBITDA · 2024" value="38,4" unit="mil. EUR" delta="marža 9,3%" trend="↑ 0,6 pp"/>
          <KPI label="Ugovori YTD · 2025" value="18,2" unit="mil. EUR" delta="11 ugovora · EOJN"/>
          <KPI label="Porezni dug" value="0" unit="EUR" delta="čisto · PU" trend="↑"/>
          <KPI label="Otvoreni spisi" value="0" delta="0 aktivnih sudskih postupaka"/>
        </div>
      </div>

      {/* ── Three-column spine ──────────────────────────────── */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '280px 1fr 360px',
        gap: 24, padding: '24px 28px',
        alignItems: 'flex-start',
      }}>
        {/* LEFT — legal facts */}
        <aside>
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)' }}>
            <div style={{ padding: '14px 18px 6px' }}>
              <div className="tn-caps" style={{ fontSize: 10, marginBottom: 6 }}>Temeljni podaci</div>
            </div>
            <div style={{ padding: '0 18px 14px' }}>
              <MiniRow k="Pravni oblik" v="dioničko društvo (d.d.)"/>
              <MiniRow k="Datum osnivanja" mono v="1991-09-24"/>
              <MiniRow k="Starost" v="34 godine"/>
              <MiniRow k="Sjedište" v="Zagreb · Trešnjevka-jug"/>
              <MiniRow k="Poslovni račun (IBAN)" mono v="HR41 2360 0001 1012…"/>
            </div>

            <div style={{ borderTop: '1px solid var(--tn-rule-2)', padding: '14px 18px 6px' }}>
              <div className="tn-caps" style={{ fontSize: 10, marginBottom: 6 }}>Temeljni kapital</div>
            </div>
            <div style={{ padding: '0 18px 14px' }}>
              <MiniRow k="Upisani kapital" mono v="77.400.000 EUR"/>
              <MiniRow k="Uplaćen" mono v="77.400.000 EUR"/>
              <MiniRow k="Broj dionica" mono v="2.580.000"/>
              <MiniRow k="Nominalna vr." mono v="30,00 EUR"/>
              <MiniRow k="Burza" v={<a href="#" style={{ color: 'var(--tn-navy-700)' }}>ZSE · KOEI-R-A</a>}/>
            </div>

            <div style={{ borderTop: '1px solid var(--tn-rule-2)', padding: '14px 18px 6px' }}>
              <div className="tn-caps" style={{ fontSize: 10, marginBottom: 6 }}>Djelatnost (NKD 2007)</div>
            </div>
            <div style={{ padding: '0 18px 14px' }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'baseline' }}>
                <span className="tn-mono" style={{ fontSize: 13, color: 'var(--tn-navy-800)', fontWeight: 600 }}>27.11</span>
                <span style={{ fontSize: 12, color: 'var(--tn-ink-2)' }}>Proizvodnja elektromotora, generatora i transformatora</span>
              </div>
              <div style={{ fontSize: 11, color: 'var(--tn-ink-4)', marginTop: 4, fontFamily: 'var(--tn-font-mono)' }}>
                C · Prerađivačka industrija
              </div>
            </div>

            <div style={{ borderTop: '1px solid var(--tn-rule-2)', padding: '14px 18px 6px' }}>
              <div className="tn-caps" style={{ fontSize: 10, marginBottom: 6 }}>Regulatori i nadzor</div>
            </div>
            <div style={{ padding: '0 18px 14px', display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[
                ['HANFA', 'tržište kapitala · ZSE'],
                ['HAKOM', '—'],
                ['Porezna uprava', 'veliki porezni obveznik'],
                ['DZIV (Državna revizija)', 'zbog većinskog RH vlasništva'],
              ].map(([n, note]) => (
                <div key={n}>
                  <div style={{ fontSize: 12, color: 'var(--tn-ink-2)', fontWeight: 500 }}>{n}</div>
                  <div style={{ fontSize: 10.5, color: 'var(--tn-ink-4)', fontStyle: 'italic' }}>{note}</div>
                </div>
              ))}
            </div>

            <a href="#" style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '12px 18px', borderTop: '1px solid var(--tn-rule)',
              background: 'var(--tn-paper-2)',
              fontSize: 12, color: 'var(--tn-ink-3)', textDecoration: 'none',
            }}>
              <Icon name="warn" size={12}/>
              <span>
                <span style={{ fontWeight: 500, color: 'var(--tn-ink-2)' }}>Prijavite grešku / zatražite ispravak</span>
                <br/>
                <span style={{ fontSize: 10, color: 'var(--tn-ink-5)' }}>Odgovor u roku od 7 dana</span>
              </span>
              <Icon name="arrow" size={11} style={{ marginLeft: 'auto', color: 'var(--tn-ink-4)' }}/>
            </a>
          </div>
        </aside>

        {/* CENTRE — filing/officer timeline */}
        <main>
          <div style={{ background: 'var(--tn-paper-2)', border: '1px solid var(--tn-rule)', padding: '18px 22px 22px' }}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 16 }}>
              <h2 style={{ fontSize: 14, textTransform: 'uppercase', letterSpacing: 0.1, color: 'var(--tn-ink-2)', fontWeight: 600 }}>
                Vremenska crta <span style={{ color: 'var(--tn-ink-5)', fontWeight: 500 }}>· {timelineEvents.length} nedavno</span>
              </h2>
              <div style={{ display: 'flex', gap: 4 }}>
                <Chip icon="list">Prikaži sve (412)</Chip>
              </div>
            </div>

            {/* Type filters */}
            <div style={{ display: 'flex', gap: 6, marginBottom: 18, flexWrap: 'wrap' }}>
              {[
                ['all', 'Sve', true],
                ['filing', 'Financijski izvještaji', false],
                ['officer', 'Promjene uprave', false],
                ['capital', 'Kapitalske promjene', false],
                ['contract', 'Ugovori', false],
                ['courtNotice', 'Sudske obavijesti', false],
              ].map(([k, l, on]) => (
                <button key={k} style={{
                  padding: '3px 10px', borderRadius: 999, fontSize: 11,
                  border: `1px solid ${on ? 'var(--tn-navy-700)' : 'var(--tn-rule)'}`,
                  background: on ? 'var(--tn-navy-50)' : 'var(--tn-white)',
                  color: on ? 'var(--tn-navy-800)' : 'var(--tn-ink-3)',
                  cursor: 'pointer', fontFamily: 'inherit', fontWeight: 500,
                }}>{l}</button>
              ))}
            </div>

            {timelineEvents.map((e, i, a) => (
              <OrgTimelineEvent key={i} ev={e} last={i === a.length - 1}/>
            ))}

            <div style={{ marginTop: 16, paddingTop: 14, borderTop: '1px solid var(--tn-rule)', fontSize: 11, color: 'var(--tn-ink-5)', fontFamily: 'var(--tn-font-mono)', lineHeight: 1.5 }}>
              Strukturni zapisi iz službenih registara. Redoslijed najnovije → najstarije.
            </div>
          </div>
        </main>

        {/* RIGHT — officers + shareholders + group + counterparties */}
        <aside>
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: '16px 18px', marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 12 }}>
              <div className="tn-caps" style={{ fontSize: 10 }}>Mreža · 4 kvadranta</div>
              <span style={{ fontSize: 10, fontFamily: 'var(--tn-font-mono)', color: 'var(--tn-ink-5)' }}>1 · dubina</span>
            </div>
            <OrgMiniGraph onOpen={() => {}}/>
          </div>

          {/* Officers (brief) */}
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: '14px 18px', marginBottom: 16 }}>
            <div className="tn-caps" style={{ fontSize: 10, marginBottom: 8 }}>Uprava i NO</div>
            {[
              ['Gordan Kolak',     'Predsjednik uprave',         'od 2018-01-01'],
              ['Jozo Miloloža',    'Član uprave',                'od 2019-04-12'],
              ['Miroslav Poljak',  'Član uprave · financije',    'od 2020-09-01'],
              ['Ana Lukavski',     'Član uprave · operacije',    'od 2025-11-02'],
            ].map(([n, r, t]) => (
              <a key={n} href="#" style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 8, padding: '8px 0', borderBottom: '1px solid var(--tn-rule-2)', textDecoration: 'none' }}>
                <div>
                  <div className="tn-serif" style={{ fontSize: 13, color: 'var(--tn-navy-800)', fontWeight: 500 }}>{n}</div>
                  <div style={{ fontSize: 11, color: 'var(--tn-ink-4)', marginTop: 1 }}>{r}</div>
                </div>
                <div className="tn-mono" style={{ fontSize: 10, color: 'var(--tn-ink-5)', whiteSpace: 'nowrap', alignSelf: 'center' }}>{t}</div>
              </a>
            ))}
          </div>

          {/* Top 5 counterparties (state) */}
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: '14px 18px', marginBottom: 16 }}>
            <div className="tn-caps" style={{ fontSize: 10, marginBottom: 8 }}>Top 5 naručitelja · kumul.</div>
            {[
              ['HEP d.d.',                   '38,4 mil.', 'javno poduzeće'],
              ['HŽ Infrastruktura',         '22,1 mil.', 'javno poduzeće'],
              ['Ministarstvo gospodarstva', '18,6 mil.', 'ministarstvo'],
              ['Plinacro d.o.o.',            '14,8 mil.', 'javno poduzeće'],
              ['HOPS d.d.',                  '12,4 mil.', 'javno poduzeće'],
            ].map(([n, v, t]) => (
              <div key={n} style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 8, padding: '7px 0', borderBottom: '1px solid var(--tn-rule-2)' }}>
                <div>
                  <div style={{ fontSize: 12, color: 'var(--tn-ink-2)', fontWeight: 500 }}>{n}</div>
                  <div style={{ fontSize: 10, color: 'var(--tn-ink-5)', fontStyle: 'italic' }}>{t}</div>
                </div>
                <div className="tn-mono tn-tnum" style={{ fontSize: 12, color: 'var(--tn-ink-2)', fontWeight: 600, alignSelf: 'center' }}>{v} €</div>
              </div>
            ))}
          </div>

          {/* Provenance */}
          <div style={{ background: 'var(--tn-navy-900)', color: '#e8e4d8', padding: '14px 18px' }}>
            <div className="tn-caps" style={{ marginBottom: 8, color: 'rgba(255,255,255,.6)', fontSize: 10 }}>Izvori stranice</div>
            <div style={{ fontSize: 11, fontFamily: 'var(--tn-font-mono)', lineHeight: 1.7, color: 'rgba(255,255,255,.7)' }}>
              {[
                ['sudreg.pravosudje.hr', '4 min',  412],
                ['rgfi.fina.hr',          '9 d.',  18],
                ['eojn.nn.hr',            '14 min', 142],
                ['nn.hr',                 '22 min', 67],
                ['gleif.org',             '8 d.',   1],
                ['zse.hr',                '37 min', 22],
              ].map(([src, t, n]) => (
                <div key={src} style={{ display: 'grid', gridTemplateColumns: '1fr auto 40px', gap: 8 }}>
                  <span>{src}</span>
                  <span style={{ color: 'rgba(255,255,255,.45)' }}>{t}</span>
                  <span style={{ textAlign: 'right', color: 'rgba(255,255,255,.55)' }}>{n}</span>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>

      {/* ── Tabs ─────────────────────────────────────────── */}
      <div style={{ background: 'var(--tn-white)', borderTop: '1px solid var(--tn-rule)', borderBottom: '1px solid var(--tn-rule)', padding: '0 28px' }}>
        <div style={{ display: 'flex', gap: 4, overflowX: 'auto' }}>
          {[
            ['financije',  'Financije',           'list',      '8 god.'],
            ['ljudi',      'Ljudi',                'person',    14],
            ['ugovori',    'Ugovori s državom',   'event',    142],
            ['nekretnine', 'Nekretnine',           'parcel',    11],
            ['spisi',      'Sudski spisi',          'doc',        3],
            ['promjene',   'Promjene',              'clock',    412],
            ['izvori',     'Izvori',                 'link',       6],
          ].map(([k, l, ic, n]) => {
            const active = tab === k;
            const hero = k === 'ugovori';
            return (
              <button key={k} onClick={() => setTab(k)} style={{
                display: 'flex', alignItems: 'center', gap: 6, padding: '13px 16px',
                border: 'none', background: 'transparent',
                fontSize: 13, fontFamily: 'inherit',
                color: active ? 'var(--tn-navy-800)' : 'var(--tn-ink-3)',
                fontWeight: active ? 600 : 500,
                borderBottom: active ? '2px solid var(--tn-navy-800)' : '2px solid transparent',
                marginBottom: -1, cursor: 'pointer', whiteSpace: 'nowrap',
              }}>
                <Icon name={ic} size={13}/>
                {l}
                <span className="tn-mono tn-tnum" style={{ fontSize: 10, color: 'var(--tn-ink-5)' }}>· {n}</span>
                {hero && !active && <span style={{
                  fontSize: 8, fontFamily: 'var(--tn-font-mono)', textTransform: 'uppercase',
                  letterSpacing: 0.4, padding: '1px 5px', background: 'var(--tn-amber-weak)',
                  color: 'var(--tn-amber-ink)', borderRadius: 2, marginLeft: 2,
                }}>hero</span>}
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ padding: '24px 28px 40px' }}>
        {tab === 'ugovori' && <ContractsTab/>}
        {tab === 'financije' && <FinanceTab/>}
        {tab === 'ljudi' && <PeopleTab/>}
        {tab === 'nekretnine' && <PropertyTab/>}
        {tab === 'spisi' && <CourtTab/>}
        {tab === 'promjene' && <ChangesTab/>}
        {tab === 'izvori' && <SourcesTab/>}
      </div>
    </div>
  );
};

// Small label/value row for left rail
const MiniRow = ({ k, v, mono }) => (
  <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 10, padding: '5px 0', fontSize: 12, alignItems: 'baseline' }}>
    <span style={{ color: 'var(--tn-ink-4)', fontSize: 11 }}>{k}</span>
    <span style={{ color: 'var(--tn-ink-2)', fontFamily: mono ? 'var(--tn-font-mono)' : 'inherit', fontVariantNumeric: mono ? 'tabular-nums' : 'normal', textAlign: 'right' }}>{v}</span>
  </div>
);

// ── Other tab panels (brief placeholders apart from the hero) ─
const FinanceTab = () => (
  <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: '20px 24px' }}>
    <h3 style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.1, color: 'var(--tn-ink-2)', marginBottom: 14 }}>Prihod i dobit 2018–2024</h3>
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14, height: 220, borderBottom: '1px solid var(--tn-rule)', paddingBottom: 4 }}>
      {[
        ['2018', 312, 14.2], ['2019', 328, 18.4], ['2020', 298,  9.1], ['2021', 341, 19.7],
        ['2022', 367, 21.8], ['2023', 381, 23.1], ['2024', 412, 24.8],
      ].map(([y, r, p]) => (
        <div key={y} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, height: '100%', justifyContent: 'flex-end' }}>
          <span className="tn-mono tn-tnum" style={{ fontSize: 10, color: 'var(--tn-ink-4)' }}>{r}</span>
          <div style={{ width: '100%', height: `${(r / 450) * 100}%`, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
            <div style={{ background: 'var(--tn-navy-700)', height: '100%' }}/>
          </div>
          <div style={{ width: '60%', height: 3, background: 'var(--tn-verify)', marginTop: -2, zIndex: 1, opacity: p / 30 }}/>
          <span className="tn-mono" style={{ fontSize: 10, color: 'var(--tn-ink-4)' }}>{y}</span>
        </div>
      ))}
    </div>
    <div style={{ fontSize: 11, color: 'var(--tn-ink-5)', marginTop: 10, fontFamily: 'var(--tn-font-mono)' }}>
      prihod (mil. EUR) · FINA GFI · zadnji dohvat 2026-04-15
    </div>
  </div>
);

const PeopleTab = () => (
  <TabTable
    columns={[
      { label: 'Osoba' },
      { label: 'Uloga', width: 220 },
      { label: 'Od', align: 'right', mono: true, width: 110 },
      { label: 'Do', align: 'right', mono: true, width: 110 },
      { label: 'Akt', width: 170 },
      { label: 'Izvor', width: 140 },
    ]}
    rows={[
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>Gordan Kolak</a>,    'Predsjednik uprave',          '2018-01-01', '—',          'Upis u SR',
        <SourceBadge source="Sudski registar" retrieved="2026-04-22" tone="muted">sudreg</SourceBadge>],
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>Jozo Miloloža</a>,   'Član uprave',                  '2019-04-12', '—',          'Upis u SR',
        <SourceBadge source="Sudski registar" retrieved="2026-04-22" tone="muted">sudreg</SourceBadge>],
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>Miroslav Poljak</a>, 'Član uprave · financije',      '2020-09-01', '—',          'Upis u SR',
        <SourceBadge source="Sudski registar" retrieved="2026-04-22" tone="muted">sudreg</SourceBadge>],
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>Ana Lukavski</a>,    'Član uprave · operacije',      '2025-11-02', '—',          'Upis u SR',
        <SourceBadge source="Sudski registar" retrieved="2025-11-03" tone="muted">sudreg</SourceBadge>],
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>Darinko Bago</a>,    'Predsjednik uprave',           '2010-03-01', '2017-12-31', 'Upis u SR',
        <SourceBadge source="Sudski registar" retrieved="2026-04-22" tone="muted">sudreg</SourceBadge>],
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>Republika Hrvatska · CERP</a>, 'Vlasnik (33,42%)',        '—',          '—',          '—',
        <SourceBadge source="SKDD · Središnji depozitarij" retrieved="2026-04-18" tone="muted">skdd</SourceBadge>],
    ]}
    footer="Uključuje članove uprave, nadzornog odbora i glavne dioničare. Za mandate prije 2014. izvor: FINA arhiva."
  />
);

const PropertyTab = () => (
  <TabTable
    columns={[
      { label: 'K.č.' },
      { label: 'Tip', width: 160 },
      { label: 'Lokacija', width: 240 },
      { label: 'Površina', align: 'right', mono: true, width: 110 },
      { label: 'Udio', align: 'right', mono: true, width: 70 },
      { label: 'Izvor', width: 140 },
    ]}
    rows={[
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>k.č. 2104 k.o. Trešnjevka-j.</a>, 'Poslovna zgrada', 'Fallerovo šetalište 22, Zagreb', '18.420 m²', '1/1',
        <SourceBadge source="Katastar · ZK sud" retrieved="2026-04-15" tone="muted">katastar</SourceBadge>],
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>k.č. 4128 k.o. Žitnjak</a>, 'Proizvodni pogon', 'Zagreb · Industrijska zona', '42.700 m²', '1/1',
        <SourceBadge source="Katastar · ZK sud" retrieved="2026-04-15" tone="muted">katastar</SourceBadge>],
    ]}
    footer="Prikazane su samo cjelovite čestice u 100% vlasništvu. Za podatke o udjelima u suvlasništvu s drugim društvima vidi grupu."
  />
);

const CourtTab = () => (
  <TabTable
    columns={[
      { label: 'Oznaka', mono: true, width: 180 },
      { label: 'Sud' },
      { label: 'Tip', width: 220 },
      { label: 'Datum', align: 'right', mono: true, width: 120 },
      { label: 'Status', width: 140 },
      { label: 'Izvor', width: 140 },
    ]}
    rows={[
      ['TS-ZG-2023-1204', 'Trgovački sud u Zagrebu', 'Parnica · arhivirana', '2024-03-18',
        <span style={{ color: 'var(--tn-ink-4)' }}>arhivirana</span>,
        <SourceBadge source="e-Oglasna ploča" retrieved="2024-03-20" tone="muted">eoglasna</SourceBadge>],
      ['TS-ZG-2021-0822', 'Trgovački sud u Zagrebu', 'Ovršni postupak · okončan', '2022-09-11',
        <span style={{ color: 'var(--tn-ink-4)' }}>okončan</span>,
        <SourceBadge source="e-Oglasna ploča" retrieved="2022-09-12" tone="muted">eoglasna</SourceBadge>],
      ['US-RH-2019-0044', 'Ustavni sud RH', 'Ustavna tužba · odbijena', '2020-02-28',
        <span style={{ color: 'var(--tn-ink-4)' }}>odbijena</span>,
        <SourceBadge source="Narodne novine" retrieved="2020-03-01" tone="muted">nn.hr</SourceBadge>],
    ]}
    footer="Nijedan aktivan sudski postupak trenutno. Posljednji zapisi iz e-Oglasne ploče i Narodnih novina."
  />
);

const ChangesTab = () => (
  <TabTable
    columns={[
      { label: 'Datum', mono: true, width: 120 },
      { label: 'Vrsta', width: 180 },
      { label: 'Detalji' },
      { label: 'Akt', width: 160 },
      { label: 'Izvor', width: 140 },
    ]}
    rows={[
      ['2025-11-02', 'Promjena uprave', 'Imenovana Ana Lukavski, član uprave za operacije',           'Odluka NO-a br. 224/2025',
        <SourceBadge source="Sudski registar" retrieved="2025-11-03" tone="muted">sudreg</SourceBadge>],
      ['2024-06-28', 'Povećanje kapitala', 'S 74,1 → 77,4 mil. EUR · emisija 110.000 novih dionica',   'Odluka GS-a 2024',
        <SourceBadge source="Sudski registar" retrieved="2024-07-01" tone="muted">sudreg</SourceBadge>],
      ['2022-04-12', 'Izmjena statuta',    'Usklađenje s ZTD-om · dopuna djelatnosti',                 'NN 42/2022',
        <SourceBadge source="Narodne novine" retrieved="2022-04-13" tone="muted">nn.hr</SourceBadge>],
      ['2021-10-09', 'Sjedište',            'Nepromijenjeno · ažurirana kontakt adresa',                 '—',
        <SourceBadge source="Sudski registar" retrieved="2021-10-10" tone="muted">sudreg</SourceBadge>],
      ['2019-05-22', 'Pripajanje',          'Pripojeno društvo Končar — Inženjering za en. d.o.o.',     'Ugovor o pripajanju',
        <SourceBadge source="Sudski registar" retrieved="2019-05-25" tone="muted">sudreg</SourceBadge>],
    ]}
    footer="Prikazano je 5 od 412 ukupnih promjena u Sudskom registru od 1991. godine."
  />
);

const SourcesTab = () => (
  <TabTable
    columns={[
      { label: 'Registar' },
      { label: 'Domena', mono: true, width: 220 },
      { label: 'Zapisa', align: 'right', mono: true, width: 90 },
      { label: 'Zadnji sync', align: 'right', mono: true, width: 170 },
      { label: 'Status', width: 140 },
    ]}
    rows={[
      ['Sudski registar',               'sudreg.pravosudje.hr',  412, '2026-04-23 14:12', <span style={{ color: 'var(--tn-verify)' }}>✓ svjež</span>],
      ['FINA · RGFI',                    'rgfi.fina.hr',           18, '2026-04-15 09:18', <span style={{ color: 'var(--tn-verify)' }}>✓ svjež</span>],
      ['EOJN — javna nabava',            'eojn.nn.hr',            142, '2026-04-23 14:01', <span style={{ color: 'var(--tn-verify)' }}>✓ svjež</span>],
      ['Narodne novine',                 'nn.hr',                   67, '2026-04-23 14:00', <span style={{ color: 'var(--tn-verify)' }}>✓ svjež</span>],
      ['GLEIF · LEI',                    'gleif.org',                1, '2026-04-15 00:04', <span style={{ color: 'var(--tn-verify)' }}>✓ svjež</span>],
      ['ZSE · dionice',                  'zse.hr',                  22, '2026-04-23 13:27', <span style={{ color: 'var(--tn-verify)' }}>✓ svjež</span>],
      ['Katastar · ZK sud',              'uredjenazemlja.hr',        2, '2026-04-15 09:30', <span style={{ color: 'var(--tn-verify)' }}>✓ svjež</span>],
      ['e-Oglasna ploča',                'e-oglasna.pravosudje.hr',  3, '2024-03-20 11:14', <span style={{ color: 'var(--tn-ink-4)' }}>arhiv</span>],
    ]}
    footer={<>Stranica je sastavljena strojno spajanjem 667 zapisa iz 8 javnih registara. <a href="#" style={{ color: 'var(--tn-navy-700)' }}>Metodologija ↗</a></>}
  />
);

window.OrgScreen = OrgScreen;
