/* Person page — canonical three-column layout per spec.
   Left rail: identity card with portrait, role, role history, sensitive DOB.
   Centre: range scrubber + vertical timeline (newest first) with typed icons.
   Right rail: 320×320 mini-graph + "Otvori u mreži".
   Below: tabs Subjekti · Nekretnine · Javne funkcije · Imovinska kartica ·
   Sudski spisi · Izvori — each a filtered view of the graph. */

const PersonScreen = () => {
  const [tab, setTab] = React.useState('imovina'); // default to showcase comparison
  const [rangeStart, setRangeStart] = React.useState(2016);
  const [rangeEnd, setRangeEnd] = React.useState(2026);
  const [roleHistOpen, setRoleHistOpen] = React.useState(false);
  const [graphSel, setGraphSel] = React.useState(null);

  // ── Timeline events — newest first, 2005–2026 (22 yrs) ─────
  // kinds: appointment · directorship · acquired · sold · donation
  // · courtNotice · decl
  const events = [
    { year: 2026, date: '2026-03-12', timeAgo: 'prije 42 dana', kind: 'decl',
      title: 'Imovinska kartica podnesena za 2025. godinu',
      entities: [{ type: 'org', name: 'Povjerenstvo za sukob interesa' }],
      amount: null,
      source: 'Povjerenstvo · sukobinteresa.hr', retrieved: '2026-04-18' },
    { year: 2025, date: '2025-11-02', timeAgo: 'prije 5 mj.', kind: 'directorship',
      title: 'Prestanak funkcije direktora — Plenković & Partneri j.t.d.',
      entities: [{ type: 'org', name: 'Plenković & Partneri j.t.d.' }],
      amount: null,
      source: 'Sudski registar · sudreg', retrieved: '2026-04-22' },
    { year: 2025, date: '2025-09-24', timeAgo: 'prije 7 mj.', kind: 'appointment',
      title: 'Mandat predsjednika Vlade produžen — 15. saziv Sabora',
      entities: [{ type: 'org', name: 'Vlada RH' }, { type: 'org', name: 'Hrvatski sabor' }],
      amount: null,
      source: 'Narodne novine · nn.hr', retrieved: '2025-09-25' },
    { year: 2024, date: '2024-06-18', timeAgo: 'prije 22 mj.', kind: 'courtNotice',
      title: 'Sudska obavijest — zahtjev za uvid u spis, trgovački sud (arhiviran)',
      entities: [{ type: 'event', name: 'TS-ZG-2024-822' }],
      amount: null,
      source: 'e-Oglasna ploča · eoglasna', retrieved: '2024-06-19' },
    { year: 2023, date: '2023-03-18', timeAgo: 'prije 3 g.', kind: 'donation',
      title: 'Donacija političkoj stranci HDZ prijavljena',
      entities: [{ type: 'org', name: 'Hrvatska demokratska zajednica' }],
      amount: '12.000 EUR',
      source: 'DIP · Izvješće o donacijama', retrieved: '2023-04-02' },
    { year: 2022, date: '2022-11-09', timeAgo: 'prije 3 g.', kind: 'decl',
      title: 'Imovinska kartica podnesena za 2022. godinu',
      entities: [],
      amount: null,
      source: 'Povjerenstvo · sukobinteresa.hr', retrieved: '2022-11-10' },
    { year: 2019, date: '2019-04-02', timeAgo: 'prije 7 g.', kind: 'directorship',
      title: 'Imenovan član nadzornog odbora — Vila Plenković d.o.o.',
      entities: [{ type: 'org', name: 'Vila Plenković d.o.o.' }],
      amount: null,
      source: 'Sudski registar · sudreg', retrieved: '2019-04-15' },
    { year: 2016, date: '2016-10-19', timeAgo: 'prije 9 g.', kind: 'appointment',
      title: 'Imenovan predsjednik Vlade Republike Hrvatske',
      entities: [{ type: 'org', name: 'Vlada RH' }, { type: 'org', name: 'Hrvatski sabor' }],
      amount: null,
      source: 'Narodne novine · NN 97/2016', retrieved: '2016-10-20' },
    { year: 2014, date: '2014-09-11', timeAgo: 'prije 11 g.', kind: 'directorship',
      title: 'Osnovano društvo Plenković & Partneri j.t.d. — partner (33%)',
      entities: [{ type: 'org', name: 'Plenković & Partneri j.t.d.' }],
      amount: null,
      source: 'Sudski registar · sudreg', retrieved: '2014-09-20' },
    { year: 2011, date: '2011-06-14', timeAgo: 'prije 15 g.', kind: 'acquired',
      title: 'Stjecanje nekretnine — stan 112 m², Zagreb · Ulica kralja Zvonimira',
      entities: [{ type: 'asset', name: 'k.č. 4782/2, k.o. Donji Grad' }],
      amount: '342.000 EUR',
      source: 'Katastar · ZK sud', retrieved: '2011-07-01' },
  ];

  // Density per year for the scrubber (2005..2026)
  const minYear = 2005, maxYear = 2026;
  const density = React.useMemo(() => {
    const arr = Array(maxYear - minYear + 1).fill(0);
    events.forEach(e => { arr[e.year - minYear]++; });
    return arr;
  }, [events]);

  const visibleEvents = events.filter(e => e.year >= rangeStart && e.year <= rangeEnd);

  // ── MiniGraph nodes (pre-placed) ────────────────────────────
  const graphNodes = [
    { id: 'ap',    type: 'person', label: 'Andrej Plenković', x: 160, y: 160 },
    // Orgs — public functions
    { id: 'vlada',  type: 'org',    label: 'Vlada RH',             sub: 'javno tijelo', x:  50, y:  48 },
    { id: 'hdz',    type: 'org',    label: 'HDZ',                   sub: 'stranka',     x: 160, y:  34 },
    { id: 'sabor',  type: 'org',    label: 'Hrvatski sabor',        sub: 'zakonodavno', x: 272, y:  50 },
    // Orgs — business
    { id: 'pp',     type: 'org',    label: 'P&P j.t.d.',            sub: 'partner 33%', x: 292, y: 160, flag: true },
    { id: 'vila',   type: 'org',    label: 'Vila Plenković',        sub: 'član NO',     x: 272, y: 260 },
    // People
    { id: 'gp',     type: 'person', label: 'Gabrijela P.',          sub: 'član NO',     x: 160, y: 282 },
    { id: 'km',     type: 'person', label: 'K. Matić',              sub: 'su-partner',  x:  60, y: 262 },
    // Assets
    { id: 'zvon',   type: 'asset',  label: 'Stan · Zvonimira',      sub: 'Zagreb',      x:  30, y: 160 },
    { id: 'zag',    type: 'asset',  label: 'Kuća · Zagorje',        sub: 'Krap. Topl.', x:  72, y: 108 },
    // Event
    { id: 'ug',     type: 'event',  label: 'Ugovor 8842',           sub: 'EOJN · 2025', x: 248, y: 108 },
  ];
  const graphEdges = [
    { from: 'ap', to: 'vlada',  strong: true },
    { from: 'ap', to: 'hdz',    strong: true },
    { from: 'ap', to: 'sabor',  soft: true },
    { from: 'ap', to: 'pp' },
    { from: 'ap', to: 'vila' },
    { from: 'ap', to: 'zvon',   strong: true },
    { from: 'ap', to: 'zag',    strong: true },
    { from: 'pp', to: 'gp' },
    { from: 'pp', to: 'km' },
    { from: 'pp', to: 'ug',     soft: true },
    { from: 'vlada', to: 'ug' },
  ];

  return (
    <div className="tn-root" style={{ minHeight: '100%', background: 'var(--tn-paper)' }}>
      <TopBar currentPath="person"/>

      {/* Breadcrumb */}
      <div style={{ padding: '10px 28px', fontSize: 12, color: 'var(--tn-ink-4)', background: 'var(--tn-white)', borderBottom: '1px solid var(--tn-rule-2)' }}>
        <a href="#" style={{ color: 'var(--tn-ink-4)' }}>Pretraga</a>
        <span style={{ margin: '0 6px' }}>/</span>
        <a href="#" style={{ color: 'var(--tn-ink-4)' }}>Osobe</a>
        <span style={{ margin: '0 6px' }}>/</span>
        <span style={{ color: 'var(--tn-ink-2)' }}>Andrej Plenković</span>
      </div>

      {/* ── Top masthead: compact — identity, lang-dupe EN, actions ── */}
      <section style={{ background: 'var(--tn-white)', padding: '22px 28px 18px', borderBottom: '1px solid var(--tn-rule)' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 24 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span className="tn-caps" style={{ color: 'var(--tn-navy-800)' }}>
              <Icon name="person" size={11} style={{ display: 'inline', marginRight: 4, verticalAlign: -1 }}/>
              Osoba · Javni dužnosnik
            </span>
            <span style={{ height: 12, width: 1, background: 'var(--tn-rule)' }}/>
            <span className="tn-mono" style={{ fontSize: 12, color: 'var(--tn-ink-4)' }}>ENT-HR-P-00284917</span>
            <span style={{ height: 12, width: 1, background: 'var(--tn-rule)' }}/>
            <span className="tn-mono" style={{ fontSize: 11, color: 'var(--tn-ink-5)' }}>provenance: 6 izvora · posljednji sync 6 min</span>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <Button variant="secondary" size="sm" icon="download">Izvoz (PDF / JSON)</Button>
            <Button variant="ghost" size="sm" iconRight="link">Permalink</Button>
          </div>
        </div>
      </section>

      {/* ── Three-column spine ───────────────────────────────── */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '280px 1fr 360px',
        gap: 24,
        padding: '24px 28px',
        alignItems: 'flex-start',
      }}>
        {/* ╭── LEFT RAIL — Identity card ──────────────────── ╮ */}
        <aside>
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', overflow: 'hidden' }}>
            {/* Portrait slot */}
            <div style={{
              aspectRatio: '1 / 1', width: '100%',
              background: 'var(--tn-paper-2)',
              borderBottom: '1px solid var(--tn-rule)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              position: 'relative',
            }}>
              <PortraitPlaceholder/>
              <div style={{
                position: 'absolute', bottom: 8, right: 8,
                padding: '2px 7px', background: 'rgba(11,37,69,0.85)',
                color: '#fff', fontSize: 10, fontFamily: 'var(--tn-font-mono)',
                letterSpacing: 0.3, borderRadius: 2,
              }}>
                bez službene fotografije
              </div>
            </div>

            {/* Body */}
            <div style={{ padding: '16px 18px' }}>
              <h1 className="tn-serif" style={{
                fontSize: 24, fontWeight: 700, color: 'var(--tn-navy-900)',
                letterSpacing: -0.4, lineHeight: 1.15, marginBottom: 4,
              }}>
                Andrej Plenković
              </h1>
              <div style={{ fontSize: 13, color: 'var(--tn-ink-3)', marginBottom: 10, lineHeight: 1.4 }}>
                <span style={{ fontWeight: 500, color: 'var(--tn-ink-2)' }}>Predsjednik Vlade Republike Hrvatske</span>
                <br/>
                <span style={{ fontFamily: 'var(--tn-font-serif)', fontStyle: 'italic', color: 'var(--tn-ink-4)' }}>
                  Prime Minister of the Republic of Croatia
                </span>
              </div>

              {/* Role tenure */}
              <div style={{ marginBottom: 12, fontSize: 12, color: 'var(--tn-ink-4)' }}>
                <span className="tn-mono tn-tnum">od 19.10.2016.</span>
                <span style={{ margin: '0 4px' }}>·</span>
                <span className="tn-mono">9 g. 6 mj.</span>
              </div>

              <button onClick={() => setRoleHistOpen(o => !o)} style={{
                border: 'none', background: 'transparent', padding: 0,
                fontSize: 12, color: 'var(--tn-navy-700)', cursor: 'pointer',
                display: 'inline-flex', alignItems: 'center', gap: 4, fontFamily: 'inherit',
                textDecoration: 'underline', textDecorationColor: 'var(--tn-navy-100)',
              }}>
                <Icon name={roleHistOpen ? 'chevD' : 'chev'} size={10}/>
                {roleHistOpen ? 'Sakrij prethodne funkcije' : 'Povijest funkcija (5)'}
              </button>
              {roleHistOpen && (
                <ol style={{
                  listStyle: 'none', padding: 0, margin: '10px 0 0',
                  borderLeft: '1px solid var(--tn-rule)', paddingLeft: 12,
                }}>
                  {[
                    ['Zastupnik u Europskom parlamentu',      '2013-07 → 2016-10'],
                    ['Veleposlanik RH u Francuskoj',           '2010-01 → 2011-10'],
                    ['Pomoćnik ministra vanjskih poslova',     '2005-01 → 2010-01'],
                    ['Savjetnik u MVEP-u',                      '1999-08 → 2005-01'],
                    ['Pripravnik · Ministarstvo vanjskih p.',   '1994-09 → 1999-08'],
                  ].map(([r, p]) => (
                    <li key={r} style={{ padding: '6px 0', fontSize: 12, color: 'var(--tn-ink-2)' }}>
                      <div style={{ fontWeight: 500 }}>{r}</div>
                      <div className="tn-mono" style={{ fontSize: 10, color: 'var(--tn-ink-5)', letterSpacing: 0.2 }}>{p}</div>
                    </li>
                  ))}
                </ol>
              )}

              <div style={{ height: 1, background: 'var(--tn-rule-2)', margin: '14px 0' }}/>

              {/* DOB — sensitivity-aware */}
              <div style={{ marginBottom: 12 }}>
                <div className="tn-caps" style={{ fontSize: 10, marginBottom: 4 }}>Rođen</div>
                <div style={{ fontSize: 13, color: 'var(--tn-ink-2)', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <SensitiveDOB
                    iso="1970-04-08"
                    publicFigure={true}
                    yearInOfficialSource={true}
                    source="Hrvatski sabor · biografija"
                    retrieved="2026-04-20"
                  />
                  <span style={{ color: 'var(--tn-ink-4)', fontSize: 12 }}>· Zagreb</span>
                </div>
                <div style={{ fontSize: 10, color: 'var(--tn-ink-5)', marginTop: 4, fontStyle: 'italic', lineHeight: 1.4 }}>
                  Godina prikazana: javna funkcija i službeni izvor.
                </div>
              </div>

              {/* Canonical IDs */}
              <div style={{ marginBottom: 12 }}>
                <div className="tn-caps" style={{ fontSize: 10, marginBottom: 6 }}>Kanonski identifikatori</div>
                <CanonicalIDs rows={[
                  { key: 'OIB',  value: '73278161820', mono: true, source: 'Sudski registar', retrieved: '2026-04-22' },
                  { key: 'MBG',  value: 'nije javno', mono: false, sensitive: true },
                  { key: 'ENT', value: 'ENT-HR-P-00284917', mono: true, source: 'Transparentno.hr' },
                  { key: 'Wiki', value: 'Q313956', mono: true, source: 'Wikidata', retrieved: '2026-04-01' },
                ]}/>
              </div>

              {/* Flags */}
              <div style={{ marginBottom: 12 }}>
                <div className="tn-caps" style={{ fontSize: 10, marginBottom: 6 }}>Status</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 12, color: 'var(--tn-ink-2)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--tn-navy-700)' }}/>
                    Politički izloženo (PEP)
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--tn-verify)' }}/>
                    Nije na sankcijskim popisima
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--tn-verify)' }}/>
                    Nije na popisu poreznih dužnika
                  </div>
                </div>
              </div>
            </div>

            {/* Takedown link */}
            <a href="#" style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '12px 18px', borderTop: '1px solid var(--tn-rule)',
              background: 'var(--tn-paper-2)',
              fontSize: 12, color: 'var(--tn-ink-3)', textDecoration: 'none',
            }}>
              <Icon name="warn" size={12} stroke={1.6}/>
              <span>
                <span style={{ fontWeight: 500, color: 'var(--tn-ink-2)' }}>Prijavite grešku / zatražite ispravak</span>
                <br/>
                <span style={{ fontSize: 10, color: 'var(--tn-ink-5)' }}>Odgovor u roku od 7 dana</span>
              </span>
              <Icon name="arrow" size={11} style={{ marginLeft: 'auto', color: 'var(--tn-ink-4)' }}/>
            </a>
          </div>
        </aside>

        {/* ╭── CENTRE — Range scrubber + Timeline ───────────── ╮ */}
        <main>
          <RangeScrubber
            start={rangeStart} end={rangeEnd}
            minYear={minYear} maxYear={maxYear}
            density={density}
            onChange={(a, b) => { setRangeStart(a); setRangeEnd(b); }}
            labels={[
              ['Cijeli život',              minYear, maxYear],
              ['Prvi mandat (2016–20)',     2016,    2020],
              ['Drugi mandat (2020–24)',    2020,    2024],
              ['Treći mandat (2024–)',      2024,    maxYear],
              ['Posljednje 2 god.',          2024,    maxYear],
            ]}
          />

          {/* Timeline */}
          <div style={{
            background: 'var(--tn-paper-2)', border: '1px solid var(--tn-rule)',
            padding: '20px 24px 24px',
          }}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 18 }}>
              <h2 style={{ fontSize: 14, textTransform: 'uppercase', letterSpacing: 0.1, color: 'var(--tn-ink-2)', fontWeight: 600 }}>
                Vremenska crta <span style={{ color: 'var(--tn-ink-5)', fontWeight: 500 }}>· {visibleEvents.length} / {events.length}</span>
              </h2>
              <div style={{ display: 'flex', gap: 4, alignItems: 'center', fontSize: 11, fontFamily: 'var(--tn-font-mono)', color: 'var(--tn-ink-5)' }}>
                <Icon name="clock" size={10}/>
                najnovije → najstarije
              </div>
            </div>

            {visibleEvents.length === 0 ? (
              <div style={{ padding: '40px 0', textAlign: 'center', color: 'var(--tn-ink-4)', fontSize: 13 }}>
                Nema događaja u odabranom rasponu.
              </div>
            ) : (
              <div>
                {visibleEvents.map((e, i, arr) => (
                  <TimelineEvent key={i} ev={e} last={i === arr.length - 1}/>
                ))}
              </div>
            )}

            <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid var(--tn-rule)', fontSize: 11, color: 'var(--tn-ink-5)', fontFamily: 'var(--tn-font-mono)', lineHeight: 1.5 }}>
              Događaji su strukturni zapisi iz registara. Ne impliciramo prirodu odnosa niti pripisujemo radnje koje nisu dokumentirane.
            </div>
          </div>
        </main>

        {/* ╭── RIGHT RAIL — Mini-graph + related ────────────── ╮ */}
        <aside>
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: '16px 18px', marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 12 }}>
              <div className="tn-caps" style={{ fontSize: 10 }}>Mreža · 10 susjeda</div>
              <span style={{ fontSize: 10, fontFamily: 'var(--tn-font-mono)', color: 'var(--tn-ink-5)' }}>1 · dubina</span>
            </div>
            <MiniGraph
              centre="ap"
              nodes={graphNodes}
              edges={graphEdges}
              selected={graphSel}
              onSelect={setGraphSel}
              onOpen={() => {}}
            />
          </div>

          {/* Ranked neighbours list */}
          <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: '14px 18px 6px', marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 4 }}>
              <div className="tn-caps" style={{ fontSize: 10 }}>Povezani entiteti</div>
              <span style={{ fontSize: 10, fontFamily: 'var(--tn-font-mono)', color: 'var(--tn-ink-5)' }}>n = 10</span>
            </div>
            <div style={{ fontSize: 10, color: 'var(--tn-ink-5)', marginBottom: 10, fontStyle: 'italic', lineHeight: 1.4 }}>
              Strukturne veze iz registara. Ne impliciramo prirodu odnosa.
            </div>
            {[
              ['Vlada RH',                   'pravna osoba · javna',   'funkcija od 2016'],
              ['HDZ',                         'politička stranka',      'predsjednik od 2016'],
              ['Plenković & Partneri j.t.d.', 'pravna osoba',           'partner · 33%',          true],
              ['Vila Plenković d.o.o.',      'pravna osoba',           'član NO · od 2019'],
              ['Gabrijela Plenković',         'osoba',                  'imenovana u imov. kartici'],
              ['k.č. 4782/2 Donji Grad',      'nekretnina · stan',      'vlasnik 1/1 · od 2011'],
              ['k.č. 812 Krap. Toplice',     'nekretnina · kuća',      'vlasnik 1/1'],
            ].map(([name, type, rel, flagged]) => (
              <a key={name} href="#" style={{
                display: 'block', padding: '9px 0', borderBottom: '1px solid var(--tn-rule-2)', textDecoration: 'none',
                position: 'relative',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ fontSize: 12.5, fontWeight: 500, color: 'var(--tn-navy-800)', flex: 1 }}>{name}</div>
                  {flagged && <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--tn-amber)' }}/>}
                </div>
                <div style={{ fontSize: 10, color: 'var(--tn-ink-4)', marginTop: 1 }}>{type}</div>
                <div style={{ fontSize: 10, color: 'var(--tn-ink-3)', marginTop: 2, fontFamily: 'var(--tn-font-mono)' }}>{rel}</div>
              </a>
            ))}
            <div style={{ padding: '10px 0 0', textAlign: 'center' }}>
              <a href="#" style={{ fontSize: 11, color: 'var(--tn-navy-700)', fontWeight: 500, textDecoration: 'none' }}>
                Prikaži svih 23 entiteta →
              </a>
            </div>
          </div>

          {/* Provenance snippet */}
          <div style={{ background: 'var(--tn-navy-900)', color: '#e8e4d8', padding: '14px 18px' }}>
            <div className="tn-caps" style={{ marginBottom: 8, color: 'rgba(255,255,255,.6)', fontSize: 10 }}>Izvori ove stranice</div>
            <div style={{ fontSize: 11, fontFamily: 'var(--tn-font-mono)', lineHeight: 1.7, color: 'rgba(255,255,255,.7)' }}>
              {[
                ['sudreg.pravosudje.hr', '6 min',   187],
                ['sukobinteresa.hr',      '41 min', 32],
                ['fina.hr',               '2 h',    18],
                ['eojn.nn.hr',            '11 min', 14],
                ['dip.hr',                '08:00',  9],
                ['nn.hr',                 '12 min', 22],
              ].map(([src, t, n]) => (
                <div key={src} style={{ display: 'grid', gridTemplateColumns: '1fr auto 34px', gap: 8 }}>
                  <span>{src}</span>
                  <span style={{ color: 'rgba(255,255,255,.45)' }}>{t}</span>
                  <span style={{ textAlign: 'right', color: 'rgba(255,255,255,.55)' }}>{n}</span>
                </div>
              ))}
            </div>
            <a href="#" style={{ display: 'inline-block', marginTop: 12, fontSize: 10, color: '#d9c78a', fontFamily: 'var(--tn-font-mono)', textDecoration: 'underline' }}>
              metodologija spajanja ↗
            </a>
          </div>
        </aside>
      </div>

      {/* ── Tabs bar ──────────────────────────────────────── */}
      <div style={{ background: 'var(--tn-white)', borderTop: '1px solid var(--tn-rule)', borderBottom: '1px solid var(--tn-rule)', padding: '0 28px' }}>
        <div style={{ display: 'flex', gap: 4, overflowX: 'auto' }}>
          {[
            ['subjekti', 'Subjekti',            'building', 3],
            ['nekretnine', 'Nekretnine',        'parcel',    2],
            ['funkcije', 'Javne funkcije',      'shield',    6],
            ['imovina', 'Imovinska kartica',    'list',      '4 god.'],
            ['spisi', 'Sudski spisi',            'doc',       1],
            ['izvori', 'Izvori',                 'link',      187],
          ].map(([k, l, ic, n]) => (
            <button key={k} onClick={() => setTab(k)} style={{
              display: 'flex', alignItems: 'center', gap: 6, padding: '13px 16px',
              border: 'none', background: 'transparent',
              fontSize: 13, fontFamily: 'inherit',
              color: tab === k ? 'var(--tn-navy-800)' : 'var(--tn-ink-3)',
              fontWeight: tab === k ? 600 : 500,
              borderBottom: tab === k ? '2px solid var(--tn-navy-800)' : '2px solid transparent',
              marginBottom: -1, cursor: 'pointer', whiteSpace: 'nowrap',
            }}>
              <Icon name={ic} size={13}/>
              {l}
              <span className="tn-mono tn-tnum" style={{ fontSize: 10, color: 'var(--tn-ink-5)' }}>· {n}</span>
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: '24px 28px 40px' }}>
        {tab === 'subjekti' && <PanelSubjekti/>}
        {tab === 'nekretnine' && <PanelNekretnine/>}
        {tab === 'funkcije' && <PanelFunkcije/>}
        {tab === 'imovina' && <ImovinaCompare/>}
        {tab === 'spisi' && <PanelSpisi/>}
        {tab === 'izvori' && <PanelIzvori/>}
      </div>
    </div>
  );
};

// ── Portrait silhouette (no invented face, no silhouette of a real person) ──
const PortraitPlaceholder = () => (
  <svg width="120" height="120" viewBox="0 0 120 120" style={{ opacity: 0.35 }}>
    <defs>
      <pattern id="diag" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)">
        <line x1="0" y1="0" x2="0" y2="6" stroke="var(--tn-ink-4)" strokeWidth="0.6"/>
      </pattern>
    </defs>
    <rect x="0" y="0" width="120" height="120" fill="url(#diag)"/>
    <circle cx="60" cy="48" r="18" fill="var(--tn-paper-2)" stroke="var(--tn-ink-4)" strokeWidth="1"/>
    <path d="M26 100 Q60 70 94 100" fill="var(--tn-paper-2)" stroke="var(--tn-ink-4)" strokeWidth="1"/>
  </svg>
);

// ── Tab panels — filtered views of the graph ────────────────
const PanelSubjekti = () => (
  <TabTable
    columns={[
      { label: 'Naziv' },
      { label: 'Oblik', width: 110 },
      { label: 'Uloga', width: 160 },
      { label: 'Udio', align: 'right', mono: true, width: 90 },
      { label: 'Od', align: 'right', mono: true, width: 110 },
      { label: 'Status', width: 160 },
      { label: 'Izvor', width: 150 },
    ]}
    rows={[
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>Plenković & Partneri j.t.d.</a>, 'j.t.d.', 'Partner', '33%', '2014-09-11',
        <WarnBadge>Porezni dužnik</WarnBadge>,
        <SourceBadge source="Sudski registar" retrieved="2026-04-22" tone="muted">sudreg</SourceBadge>],
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>Vila Plenković d.o.o.</a>, 'd.o.o.', 'Član nadzornog odbora', '—', '2019-04-02',
        <span style={{ color: 'var(--tn-verify)' }}>aktivno</span>,
        <SourceBadge source="Sudski registar" retrieved="2026-04-22" tone="muted">sudreg</SourceBadge>],
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>HDZ</a>, 'udruga', 'Predsjednik', '—', '2016-07-17',
        <span style={{ color: 'var(--tn-verify)' }}>aktivno</span>,
        <SourceBadge source="Registar stranaka" retrieved="2026-04-10" tone="muted">registar</SourceBadge>],
    ]}
    footer="Samo strukturne veze. Veze ne impliciraju aktualno sudjelovanje u operativnim odlukama."
  />
);

const PanelNekretnine = () => (
  <TabTable
    columns={[
      { label: 'Katastarska čestica' },
      { label: 'Tip', width: 120 },
      { label: 'Lokacija', width: 220 },
      { label: 'Površina', align: 'right', mono: true, width: 100 },
      { label: 'Udio', align: 'right', mono: true, width: 70 },
      { label: 'Upis', align: 'right', mono: true, width: 110 },
      { label: 'Izvor', width: 150 },
    ]}
    rows={[
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>k.č. 4782/2, k.o. Donji Grad</a>, 'Stan', 'Zagreb · Ulica kralja Zvonimira', '112 m²', '1/1', '2011-06-14',
        <SourceBadge source="Katastar · ZK sud" retrieved="2026-04-15" tone="muted">katastar</SourceBadge>],
      [<a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500 }}>k.č. 812, k.o. Krapinske Toplice</a>, 'Kuća + okućnica', 'Krapinske Toplice', '180 + 1.420 m²', '1/1', '—',
        <SourceBadge source="Imov. kartica 2024" retrieved="2026-04-18" tone="muted">imovina</SourceBadge>],
    ]}
  />
);

const PanelFunkcije = () => (
  <TabTable
    columns={[
      { label: 'Funkcija' },
      { label: 'Organizacija', width: 220 },
      { label: 'Od',   align: 'right', mono: true, width: 110 },
      { label: 'Do',   align: 'right', mono: true, width: 110 },
      { label: 'Akt',  width: 170 },
      { label: 'Izvor', width: 150 },
    ]}
    rows={[
      ['Predsjednik Vlade RH',                 'Vlada RH',                     '2016-10-19', '—',          'NN 97/2016',
        <SourceBadge source="Narodne novine" retrieved="2026-04-20" tone="muted">nn.hr</SourceBadge>],
      ['Predsjednik HDZ-a',                    'Hrvatska dem. zajednica',       '2016-07-17', '—',         'Odluka sabora HDZ-a',
        <SourceBadge source="Registar stranaka" retrieved="2026-04-10" tone="muted">registar</SourceBadge>],
      ['Zastupnik · Europski parlament',       'EP · EPP',                      '2013-07-01', '2016-10-19', 'Izborni rezultati DIP',
        <SourceBadge source="DIP" retrieved="2026-04-18" tone="muted">dip.hr</SourceBadge>],
      ['Veleposlanik u Francuskoj',             'MVEP · Pariz',                  '2010-01-15', '2011-10-23', 'Dekret RH',
        <SourceBadge source="MVEP arhiva" retrieved="2025-06-01" tone="muted">mvep</SourceBadge>],
      ['Pomoćnik ministra vanjskih poslova',    'MVEP',                          '2005-01-10', '2010-01-15', '—',
        <SourceBadge source="MVEP arhiva" retrieved="2025-06-01" tone="muted">mvep</SourceBadge>],
      ['Savjetnik · Ministarstvo europskih int.', 'MEI · RH',                   '1999-08-10', '2005-01-10', '—',
        <SourceBadge source="MVEP arhiva" retrieved="2025-06-01" tone="muted">mvep</SourceBadge>],
    ]}
  />
);

const PanelSpisi = () => (
  <TabTable
    columns={[
      { label: 'Oznaka', mono: true, width: 180 },
      { label: 'Sud' },
      { label: 'Tip predmeta', width: 220 },
      { label: 'Datum', align: 'right', mono: true, width: 120 },
      { label: 'Status', width: 140 },
      { label: 'Izvor', width: 150 },
    ]}
    rows={[
      ['TS-ZG-2024-822', 'Trgovački sud u Zagrebu', 'Uvid u spis · arhiviran', '2024-06-18',
        <span style={{ color: 'var(--tn-ink-4)' }}>arhiviran</span>,
        <SourceBadge source="e-Oglasna ploča" retrieved="2024-06-20" tone="muted">eoglasna</SourceBadge>],
    ]}
    footer="Nijedan aktivan sudski postupak protiv ove osobe nije zabilježen u javnim sudskim registrima."
  />
);

const PanelIzvori = () => {
  const sources = [
    ['Sudski registar',               'sudreg.pravosudje.hr',  187, '2026-04-23 14:12', 'verify'],
    ['Imovinske kartice',             'sukobinteresa.hr',       32, '2026-04-23 13:37', 'verify'],
    ['FINA · javna objava GFI',       'fina.hr',                18, '2026-04-23 12:04', 'verify'],
    ['EOJN — Oglasnik javne nabave',  'eojn.nn.hr',             14, '2026-04-23 14:01', 'verify'],
    ['DIP · Izvješća političkih str.','dip.hr',                  9, '2026-04-23 08:00', 'verify'],
    ['Narodne novine',                 'nn.hr',                  22, '2026-04-23 14:00', 'verify'],
    ['Katastar · ZK sud',              'uredjenazemlja.hr',       5, '2026-04-15 09:30', 'verify'],
    ['e-Oglasna ploča',                'e-oglasna.pravosudje.hr', 1, '2024-06-20 11:00', 'muted'],
  ];
  return (
    <div>
      <TabTable
        columns={[
          { label: 'Registar' },
          { label: 'Domena', mono: true, width: 240 },
          { label: 'Zapisa', align: 'right', mono: true, width: 90 },
          { label: 'Zadnji sync', align: 'right', mono: true, width: 180 },
          { label: 'Status', width: 140 },
        ]}
        rows={sources.map(([r, d, n, t, s]) => [
          r, d, n, t,
          s === 'verify' ? <span style={{ color: 'var(--tn-verify)' }}>✓ svjež · ok</span> : <span style={{ color: 'var(--tn-ink-4)' }}>arhiv</span>,
        ])}
        footer={<>
          Ova stranica u cijelosti je sastavljena strojno spajanjem 287 zapisa iz 8 javnih registara. Nijedna rečenica nije ručno napisana ni automatski generirana.
          <a href="#" style={{ marginLeft: 6, color: 'var(--tn-navy-700)' }}>Metodologija spajanja ↗</a>
        </>}
      />
    </div>
  );
};

window.PersonScreen = PersonScreen;
