/* Subcomponents for the Graph view — toolbar, left rail,
   canvas SVG, legend, zoom cluster, context menu, inspector.            */

// ── Top toolbar ───────────────────────────────────────────
const GraphTopToolbar = ({
  depth, setDepth, layout, setLayout,
  relToggles, setRelToggles, minAmount, setMinAmount,
  timeRange, setTimeRange, searchQuery, setSearchQuery, matchCount,
  panelOpen, setPanelOpen,
}) => (
  <div style={{
    background: 'var(--tn-white)', borderBottom: '1px solid var(--tn-rule)',
    padding: '10px 20px', display: 'flex', alignItems: 'center', gap: 14,
    flexWrap: 'nowrap', overflow: 'visible',
  }}>
    {/* Depth */}
    <ToolGroup label="Dubina">
      <SegButton value={depth} options={[1, 2, 3]} onChange={setDepth} suffix="hop"/>
    </ToolGroup>

    <Divider/>

    {/* Time scrubber */}
    <ToolGroup label="Razdoblje">
      <TimeScrubber value={timeRange} onChange={setTimeRange}/>
    </ToolGroup>

    <Divider/>

    {/* Rel toggles */}
    <ToolGroup label="Tipovi veza">
      <div style={{ display: 'flex', gap: 4 }}>
        {Object.entries(REL_TYPES).map(([k, v]) => (
          <button key={k}
            onClick={() => setRelToggles({ ...relToggles, [k]: !relToggles[k] })}
            title={v.label}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 5,
              padding: '3px 8px', fontSize: 11, fontFamily: 'inherit',
              border: `1px solid ${relToggles[k] ? v.color : 'var(--tn-rule)'}`,
              background: relToggles[k] ? `${v.color}14` : 'var(--tn-white)',
              color: relToggles[k] ? v.color : 'var(--tn-ink-4)',
              cursor: 'pointer', fontWeight: 500, borderRadius: 2,
            }}>
            <span style={{
              width: 10, height: 2, background: v.color,
              opacity: relToggles[k] ? 1 : 0.35,
            }}/>
            {v.label}
          </button>
        ))}
      </div>
    </ToolGroup>

    <Divider/>

    {/* Amount */}
    <ToolGroup label="Min. iznos">
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <input type="range" min="0" max="2000" step="50" value={minAmount}
          onChange={e => setMinAmount(+e.target.value)}
          style={{ width: 100, accentColor: 'var(--tn-navy-800)' }}/>
        <span className="tn-mono tn-tnum" style={{ fontSize: 11, color: 'var(--tn-ink-3)', minWidth: 60 }}>
          ≥ {minAmount === 0 ? '0' : `${minAmount}k`} €
        </span>
      </div>
    </ToolGroup>

    <Divider/>

    {/* Layout chooser */}
    <ToolGroup label="Razmještaj">
      <div style={{ display: 'flex', border: '1px solid var(--tn-rule)', borderRadius: 2 }}>
        {[
          ['force', 'Sila', 'scatter'],
          ['hierarchical', 'Hijer.', 'list'],
          ['concentric', 'Kruž.', 'circle'],
        ].map(([k, l, ic], i) => (
          <button key={k} onClick={() => setLayout(k)}
            style={{
              padding: '4px 10px', border: 'none',
              background: layout === k ? 'var(--tn-navy-800)' : 'var(--tn-white)',
              color: layout === k ? '#fff' : 'var(--tn-ink-3)',
              fontFamily: 'inherit', fontSize: 11, fontWeight: 500, cursor: 'pointer',
              borderRight: i < 2 ? '1px solid var(--tn-rule)' : 'none',
              display: 'inline-flex', alignItems: 'center', gap: 5,
            }}>
            <Icon name={ic} size={11}/>
            {l}
          </button>
        ))}
      </div>
    </ToolGroup>

    <div style={{ flex: 1 }}/>

    {/* Search */}
    <div style={{ position: 'relative' }}>
      <Icon name="search" size={12} style={{ position: 'absolute', left: 9, top: 8, color: 'var(--tn-ink-5)' }}/>
      <input
        placeholder="Traži u mreži…"
        value={searchQuery}
        onChange={e => setSearchQuery(e.target.value)}
        style={{
          width: 200, border: '1px solid var(--tn-rule)', padding: '5px 10px 5px 26px',
          fontFamily: 'inherit', fontSize: 12, background: 'var(--tn-white)',
          color: 'var(--tn-ink-2)', borderRadius: 2, outline: 'none',
        }}/>
      {searchQuery && (
        <span className="tn-mono" style={{
          position: 'absolute', right: 8, top: 6, fontSize: 10, color: 'var(--tn-ink-5)',
        }}>{matchCount}</span>
      )}
    </div>

    {/* Export */}
    <div style={{ position: 'relative' }}>
      <Button variant="secondary" size="sm" icon="download" iconRight="chevron">Izvoz</Button>
    </div>

    {/* Panel toggle */}
    <button
      onClick={() => setPanelOpen(!panelOpen)}
      title={panelOpen ? 'Sakrij panel' : 'Prikaži panel'}
      style={{
        width: 28, height: 28, border: '1px solid var(--tn-rule)',
        background: panelOpen ? 'var(--tn-navy-800)' : 'var(--tn-white)',
        color: panelOpen ? '#fff' : 'var(--tn-ink-3)',
        cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      }}>
      <Icon name="panel" size={12}/>
    </button>
  </div>
);

const ToolGroup = ({ label, children }) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
    <span className="tn-caps" style={{ fontSize: 9, color: 'var(--tn-ink-5)' }}>{label}</span>
    {children}
  </div>
);

const Divider = () => <span style={{ height: 30, width: 1, background: 'var(--tn-rule)' }}/>;

const SegButton = ({ value, options, onChange, suffix }) => (
  <div style={{ display: 'flex', border: '1px solid var(--tn-rule)', borderRadius: 2 }}>
    {options.map((o, i) => (
      <button key={o} onClick={() => onChange(o)}
        style={{
          padding: '4px 10px', border: 'none', minWidth: 32,
          background: value === o ? 'var(--tn-navy-800)' : 'var(--tn-white)',
          color: value === o ? '#fff' : 'var(--tn-ink-3)',
          fontFamily: 'var(--tn-font-mono)', fontSize: 11, fontWeight: 600, cursor: 'pointer',
          borderRight: i < options.length - 1 ? '1px solid var(--tn-rule)' : 'none',
        }}>
        {o}{suffix ? ` ${suffix}` : ''}
      </button>
    ))}
  </div>
);

const TimeScrubber = ({ value, onChange }) => {
  const [lo, hi] = value;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <span className="tn-mono tn-tnum" style={{ fontSize: 11, color: 'var(--tn-ink-3)', minWidth: 32 }}>{lo}</span>
      <div style={{ position: 'relative', width: 160, height: 16, display: 'flex', alignItems: 'center' }}>
        <div style={{ position: 'absolute', inset: '6px 0', height: 4, background: 'var(--tn-paper-2)', border: '1px solid var(--tn-rule)' }}/>
        <div style={{
          position: 'absolute', top: 7, height: 2,
          left:   `${((lo - 2000) / 26) * 100}%`,
          right:  `${100 - ((hi - 2000) / 26) * 100}%`,
          background: 'var(--tn-navy-800)',
        }}/>
        {[lo, hi].map((v, i) => (
          <div key={i} style={{
            position: 'absolute', top: 2, left: `calc(${((v - 2000) / 26) * 100}% - 5px)`,
            width: 10, height: 12, background: 'var(--tn-white)',
            border: '1.5px solid var(--tn-navy-800)', cursor: 'ew-resize',
          }}/>
        ))}
        {/* Tick marks for years with events */}
        {[2008, 2012, 2016, 2018, 2020, 2023, 2024, 2025].map(y => (
          <div key={y} style={{
            position: 'absolute', top: 11, left: `${((y - 2000) / 26) * 100}%`,
            width: 1, height: 3, background: 'var(--tn-ink-5)',
          }}/>
        ))}
      </div>
      <span className="tn-mono tn-tnum" style={{ fontSize: 11, color: 'var(--tn-ink-3)', minWidth: 32 }}>{hi}</span>
    </div>
  );
};

// ── Left rail ─────────────────────────────────────────────
const GraphLeftRail = () => {
  const [active, setActive] = React.useState('move');
  const tools = [
    ['move', 'Pomiči',      'move'],
    ['select', 'Odaberi',   'select'],
    ['pin', 'Pribadaj',     'pin'],
    ['expand', 'Proširi',   'plus'],
    ['hide', 'Sakrij',      'eye-off'],
    ['ruler', 'Put',         'ruler'],
    ['label', 'Oznake',      'type'],
  ];
  const bottom = [
    ['help', 'Pomoć', 'help'],
    ['save', 'Spremi prikaz', 'save'],
  ];

  const Item = ([k, title, icon]) => (
    <button key={k} onClick={() => setActive(k)} title={title}
      style={{
        width: 38, height: 38, margin: '0 auto',
        background: active === k ? 'var(--tn-navy-800)' : 'transparent',
        color: active === k ? '#fff' : 'var(--tn-ink-3)',
        border: 'none', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        borderRadius: 2,
      }}>
      <Icon name={icon} size={15}/>
    </button>
  );

  return (
    <div style={{
      width: 56, background: 'var(--tn-white)',
      borderRight: '1px solid var(--tn-rule)',
      display: 'flex', flexDirection: 'column',
      padding: '10px 0',
    }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {tools.map(Item)}
      </div>
      <div style={{ margin: '10px auto', width: 30, height: 1, background: 'var(--tn-rule)' }}/>
      <div style={{ flex: 1 }}/>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {bottom.map(Item)}
      </div>
    </div>
  );
};

// ── Canvas SVG ────────────────────────────────────────────
const GraphCanvasSvg = ({
  nodes, edges, coords,
  selected, hover, pinned, matchIds, pathEdges,
  activeEdgeKeys, neighborIds,
  onSelect, onHover, onContextMenu,
}) => {
  const hasSearch = matchIds.size > 0;

  // Size calc
  const sizeFor = (n) => {
    const base = 14 + Math.min(24, n.score * 0.22);
    return n.id === selected ? base + 2 : base;
  };

  // Path-counted edge weight (stub — paths increment a Map)
  const pathKeyCount = {};
  pathEdges.forEach(k => { pathKeyCount[k] = (pathKeyCount[k] || 0) + 1; });

  return (
    <svg viewBox="0 0 1180 820" preserveAspectRatio="xMidYMid meet"
      style={{ width: '100%', height: '100%', display: 'block' }}>
      <defs>
        <marker id="arrowMuted" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
          <path d="M0,0 L8,4 L0,8 z" fill="var(--tn-ink-4)"/>
        </marker>
        {Object.entries(REL_TYPES).map(([k, v]) => (
          <marker key={k} id={`arr-${k}`} viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M0,0 L8,4 L0,8 z" fill={v.color}/>
          </marker>
        ))}
      </defs>

      {/* Edges */}
      {edges.map(([a, b, rel, label, date, amount], i) => {
        const na = coords[a], nb = coords[b];
        if (!na || !nb) return null;
        const key = [a, b].sort().join('|');
        const active = activeEdgeKeys.has(key);
        const onPath = pathEdges.has(key);
        const relColor = REL_TYPES[rel].color;
        const strokeWidth = onPath ? 2.4 : active ? 1.8 : 1.1;
        const opacity = (selected && !active && !onPath) ? 0.22 : 0.78;
        const mx = (na[0] + nb[0]) / 2, my = (na[1] + nb[1]) / 2;
        return (
          <g key={i} opacity={opacity}>
            <line x1={na[0]} y1={na[1]} x2={nb[0]} y2={nb[1]}
              stroke={relColor}
              strokeWidth={strokeWidth}
              strokeDasharray={rel === 'court' ? '5 3' : rel === 'related' ? '2 3' : 'none'}
              markerEnd={active ? `url(#arr-${rel})` : undefined}/>
            {active && (
              <g transform={`translate(${mx}, ${my})`}>
                <rect x={-(label.length * 3) - 8} y={-10} width={label.length * 6 + 16} height={20}
                  fill="var(--tn-white)" stroke={relColor} strokeWidth="1"/>
                <text x={0} y={4} textAnchor="middle" fontSize="10.5"
                  fontFamily="var(--tn-font-mono)" fill={relColor} fontWeight="500">{label}</text>
                {amount && (
                  <text x={0} y={-14} textAnchor="middle" fontSize="9"
                    fontFamily="var(--tn-font-mono)" fill="var(--tn-ink-4)">
                    {(amount / 1_000_000).toFixed(2).replace('.', ',')} mil. €
                  </text>
                )}
              </g>
            )}
          </g>
        );
      })}

      {/* Nodes */}
      {nodes.map(n => {
        const pos = coords[n.id];
        if (!pos) return null;
        const [x, y] = pos;
        const r = sizeFor(n);
        const t = NODE_TYPES[n.type];
        const isSel = n.id === selected;
        const isNbr = neighborIds.has(n.id);
        const isPinned = pinned.has(n.id);
        const isMatch = matchIds.has(n.id);
        const dimmed = (selected && !isSel && !isNbr) || (hasSearch && !isMatch);

        return (
          <g key={n.id}
            transform={`translate(${x}, ${y})`}
            onClick={(e) => { e.stopPropagation(); onSelect(n.id); }}
            onContextMenu={(e) => onContextMenu(e, n.id)}
            onMouseEnter={() => onHover(n.id)} onMouseLeave={() => onHover(null)}
            style={{ cursor: 'pointer', opacity: dimmed ? 0.3 : 1, transition: 'opacity .15s' }}>
            {isSel && <circle r={r + 10} fill="none" stroke="var(--tn-navy-800)" strokeWidth="1" strokeDasharray="3 3"/>}
            {isMatch && <circle r={r + 7} fill="none" stroke="var(--tn-amber)" strokeWidth="1.5"/>}
            {n.flag === 'amber' && <circle r={r + 4} fill="none" stroke="var(--tn-amber)" strokeWidth="2.5"/>}
            <circle r={r} fill={t.fill} stroke={t.stroke} strokeWidth={1.8}/>
            {/* Type glyph */}
            <GlyphSmall type={n.type} color={t.text} size={r * 0.9}/>
            {/* Pin indicator */}
            {isPinned && (
              <g transform={`translate(${r - 2}, ${-r + 2})`}>
                <circle r="6" fill="var(--tn-navy-900)" stroke="#fff" strokeWidth="1.5"/>
                <path d="M-2,-1 L0,-3 L2,-1 L1,1 L0,3 L-1,1 Z" fill="#fff"/>
              </g>
            )}
            {/* Label below */}
            <g transform={`translate(0, ${r + 14})`}>
              {isSel && (
                <rect x={-(n.label.length * 3.2) - 6} y={-9} width={n.label.length * 6.4 + 12} height={18}
                  fill="var(--tn-white)" stroke="var(--tn-navy-800)" strokeWidth="1"/>
              )}
              <text textAnchor="middle" fontSize="11.5"
                fontFamily="var(--tn-font-sans)"
                fill={isSel ? 'var(--tn-navy-900)' : 'var(--tn-ink-2)'}
                fontWeight={isSel ? 600 : 500} y={4}>{n.label}</text>
              {n.sub && !isSel && (
                <text textAnchor="middle" fontSize="9.5" fontFamily="var(--tn-font-mono)"
                  fill="var(--tn-ink-5)" y={16}>{n.sub}</text>
              )}
            </g>
          </g>
        );
      })}
    </svg>
  );
};

// Inline SVG glyph for node types
const GlyphSmall = ({ type, color, size = 14 }) => {
  const s = size;
  const sw = Math.max(1.1, s / 10);
  const common = { stroke: color, fill: 'none', strokeWidth: sw, strokeLinecap: 'round', strokeLinejoin: 'round' };
  return (
    <g transform={`translate(${-s/2}, ${-s/2}) scale(${s/16})`}>
      {type === 'person' && <g {...common}>
        <circle cx="8" cy="6" r="2.5"/>
        <path d="M3 14c0-2.5 2.2-4.5 5-4.5s5 2 5 4.5"/>
      </g>}
      {(type === 'org' || type === 'state') && <g {...common}>
        <path d="M3 14h10M4 14V4h6v10M7 7h1M7 10h1M10 7h2v7"/>
      </g>}
      {type === 'asset' && <g {...common}>
        <path d="M2 5l6-2 6 2v7l-6 2-6-2V5z"/>
        <path d="M8 3v12M2 5l6 2 6-2"/>
      </g>}
      {type === 'event' && <g {...common}>
        <rect x="2.5" y="3" width="11" height="11"/>
        <path d="M2.5 6h11M5.5 1.5v3M10.5 1.5v3"/>
      </g>}
      {type === 'court' && <g {...common}>
        <path d="M3 3h8l2 2v9H3z"/>
        <path d="M6 7h4M6 10h4"/>
      </g>}
      {type === 'location' && <g {...common}>
        <path d="M8 2c3 0 5 2 5 5c0 3-5 8-5 8s-5-5-5-8c0-3 2-5 5-5z"/>
        <circle cx="8" cy="7" r="1.5"/>
      </g>}
    </g>
  );
};

// ── Legend (bottom-left) ──────────────────────────────────
const GraphLegend = () => (
  <div style={{
    position: 'absolute', bottom: 16, left: 16,
    background: 'var(--tn-white)', border: '1px solid var(--tn-rule)',
    display: 'grid', gridTemplateColumns: 'auto auto', gap: 0,
    fontSize: 11, maxWidth: 440,
  }}>
    <div style={{ padding: '10px 14px', borderRight: '1px solid var(--tn-rule-2)' }}>
      <div className="tn-caps" style={{ marginBottom: 8, fontSize: 9 }}>Čvorovi</div>
      {Object.entries(NODE_TYPES).map(([k, v]) => (
        <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '2px 0' }}>
          <svg width="16" height="16" style={{ flexShrink: 0 }}>
            <circle cx="8" cy="8" r="6" fill={v.fill} stroke={v.stroke} strokeWidth="1.5"/>
          </svg>
          <span style={{ color: 'var(--tn-ink-2)' }}>{v.label}</span>
        </div>
      ))}
    </div>
    <div style={{ padding: '10px 14px' }}>
      <div className="tn-caps" style={{ marginBottom: 8, fontSize: 9 }}>Veze</div>
      {Object.entries(REL_TYPES).map(([k, v]) => (
        <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '2px 0' }}>
          <svg width="18" height="8" style={{ flexShrink: 0 }}>
            <line x1="0" y1="4" x2="18" y2="4" stroke={v.color} strokeWidth="2"
              strokeDasharray={k === 'court' ? '3 2' : k === 'related' ? '2 2' : undefined}/>
          </svg>
          <span style={{ color: 'var(--tn-ink-2)' }}>{v.label}</span>
        </div>
      ))}
      <div style={{ display: 'flex', alignItems: 'center', gap: 7, padding: '4px 0 0', marginTop: 4, borderTop: '1px solid var(--tn-rule-2)' }}>
        <svg width="16" height="16">
          <circle cx="8" cy="8" r="5" fill="#fff" stroke="var(--tn-amber)" strokeWidth="2.5"/>
        </svg>
        <span style={{ color: 'var(--tn-amber-ink)' }}>iznimno stanje</span>
      </div>
    </div>
  </div>
);

// ── Zoom cluster (bottom-right) ───────────────────────────
const GraphZoomCluster = () => (
  <div style={{
    position: 'absolute', bottom: 16, right: 16,
    display: 'flex', flexDirection: 'column',
    background: 'var(--tn-white)', border: '1px solid var(--tn-rule)',
  }}>
    {[
      ['plus', '+'],
      ['minus', '−'],
      ['fit', '⛶'],
      ['lock', '⚲'],
    ].map(([k, g], i, a) => (
      <button key={k} style={{
        width: 32, height: 32, border: 'none',
        borderBottom: i < a.length - 1 ? '1px solid var(--tn-rule-2)' : 'none',
        background: 'transparent', cursor: 'pointer',
        color: 'var(--tn-ink-3)', fontSize: 14,
      }}>{g}</button>
    ))}
  </div>
);

// ── Path-finding banner ───────────────────────────────────
const PathFindingBanner = ({ pinned, nodes, pathTarget, setPathTarget }) => {
  const first = nodes.find(n => n.id === pinned[0]);
  const targetOptions = pinned.slice(1);
  return (
    <div style={{
      position: 'absolute', top: 12, left: '50%', transform: 'translateX(-50%)',
      background: 'var(--tn-navy-900)', color: '#fff',
      padding: '8px 14px', display: 'flex', alignItems: 'center', gap: 12,
      fontSize: 12,
    }}>
      <Icon name="ruler" size={12}/>
      <span className="tn-caps" style={{ color: 'rgba(255,255,255,.6)', fontSize: 10 }}>Put od</span>
      <span style={{ fontWeight: 600 }}>{first.label}</span>
      <span className="tn-caps" style={{ color: 'rgba(255,255,255,.6)', fontSize: 10 }}>do</span>
      <select value={pathTarget || ''} onChange={e => setPathTarget(e.target.value || null)}
        style={{
          background: 'var(--tn-navy-700)', color: '#fff',
          border: '1px solid rgba(255,255,255,.3)', padding: '3px 6px',
          fontFamily: 'inherit', fontSize: 12, borderRadius: 2,
        }}>
        <option value="">— odaberi pribadanog —</option>
        {targetOptions.map(id => {
          const n = nodes.find(x => x.id === id);
          return <option key={id} value={id}>{n.label}</option>;
        })}
      </select>
      {pathTarget && <span className="tn-mono" style={{ fontSize: 10, color: 'rgba(255,255,255,.7)' }}>najkraći · 3 skoka</span>}
    </div>
  );
};

// ── Context menu ──────────────────────────────────────────
const GraphContextMenu = ({ cm, node, pinned, onClose, onPin, onSelect, onPathTo }) => {
  const items = [
    ['person', 'Proširi susjede',       'plus'],
    ['person', 'Sažmi granu',             'minus'],
    ['divider'],
    ['person', pinned.has(cm.nodeId) ? 'Ukloni pribadaču' : 'Pribadaj', 'pin', onPin],
    ['person', 'Sakrij čvor',             'eye-off'],
    ['divider'],
    ['person', 'Pronađi put do ovog',      'ruler', onPathTo],
    ['person', 'Otvori profil entiteta',  'arrow', onSelect],
  ];
  return (
    <div
      onClick={(e) => e.stopPropagation()}
      style={{
        position: 'absolute', top: cm.y, left: cm.x,
        background: 'var(--tn-white)', border: '1px solid var(--tn-rule)',
        boxShadow: '0 8px 28px -10px rgba(11,30,44,.24)',
        minWidth: 220, padding: '4px 0', zIndex: 20,
      }}>
      <div style={{ padding: '6px 14px 8px', borderBottom: '1px solid var(--tn-rule)' }}>
        <div className="tn-caps" style={{ fontSize: 9, color: 'var(--tn-ink-5)' }}>{NODE_TYPES[node.type].label}</div>
        <div className="tn-serif" style={{ fontSize: 13, color: 'var(--tn-navy-900)', fontWeight: 500 }}>{node.label}</div>
      </div>
      {items.map((it, i) => it[0] === 'divider'
        ? <div key={i} style={{ height: 1, background: 'var(--tn-rule-2)', margin: '4px 0' }}/>
        : (
          <button key={i} onClick={it[3] || onClose}
            style={{
              display: 'flex', alignItems: 'center', gap: 10,
              width: '100%', padding: '7px 14px',
              border: 'none', background: 'transparent',
              fontSize: 12, fontFamily: 'inherit', color: 'var(--tn-ink-2)',
              cursor: 'pointer', textAlign: 'left',
            }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--tn-paper-2)'}
            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
            <Icon name={it[2]} size={12} style={{ color: 'var(--tn-ink-4)' }}/>
            {it[1]}
          </button>
        ))}
    </div>
  );
};

// ── Inspector (right panel) ───────────────────────────────
const GraphInspector = ({ node, edges, nodes, pinned, onSelect, onPin, onClose }) => {
  const t = NODE_TYPES[node.type];
  const nodeEdges = edges.filter(e => e[0] === node.id || e[1] === node.id);
  const byRel = {};
  nodeEdges.forEach(e => { (byRel[e[2]] ||= []).push(e); });

  return (
    <aside style={{
      width: 360, borderLeft: '1px solid var(--tn-rule)',
      background: 'var(--tn-white)', overflowY: 'auto',
      display: 'flex', flexDirection: 'column',
    }}>
      {/* Panel header */}
      <div style={{
        padding: '12px 16px', borderBottom: '1px solid var(--tn-rule)',
        background: 'var(--tn-paper-2)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <span className="tn-caps" style={{ fontSize: 10 }}>Sažetak čvora</span>
        <div style={{ display: 'flex', gap: 4 }}>
          <button onClick={() => onPin(node.id)}
            title={pinned.has(node.id) ? 'Ukloni pribadaču' : 'Pribadaj'}
            style={{
              width: 22, height: 22, border: '1px solid var(--tn-rule)',
              background: pinned.has(node.id) ? 'var(--tn-navy-800)' : 'var(--tn-white)',
              color: pinned.has(node.id) ? '#fff' : 'var(--tn-ink-4)',
              cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            }}>
            <Icon name="pin" size={10}/>
          </button>
          <button onClick={onClose} title="Zatvori" style={{
            width: 22, height: 22, border: '1px solid var(--tn-rule)',
            background: 'var(--tn-white)', color: 'var(--tn-ink-4)',
            cursor: 'pointer', fontSize: 14, lineHeight: 1,
          }}>×</button>
        </div>
      </div>

      {/* Identity */}
      <div style={{ padding: '18px 18px 16px', borderBottom: '1px solid var(--tn-rule)' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, marginBottom: 10 }}>
          <div style={{
            width: 44, height: 44, background: t.fill,
            border: `1.5px solid ${t.stroke}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0, borderRadius: 2, color: t.text,
          }}>
            <svg width="24" height="24" viewBox="-12 -12 24 24">
              <GlyphSmall type={node.type} color={t.text} size={20}/>
            </svg>
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="tn-caps" style={{ fontSize: 9, color: 'var(--tn-ink-5)' }}>{t.label}</div>
            <div className="tn-serif" style={{ fontSize: 18, fontWeight: 500, color: 'var(--tn-navy-900)', letterSpacing: -0.2, lineHeight: 1.2, marginTop: 2 }}>
              {node.label}
            </div>
            <div style={{ fontSize: 11, color: 'var(--tn-ink-4)', marginTop: 3 }}>{node.sub}</div>
          </div>
        </div>

        {node.flag === 'amber' && (
          <div style={{
            padding: '8px 10px', background: 'var(--tn-amber-weak)',
            borderLeft: '3px solid var(--tn-amber)', fontSize: 11, color: 'var(--tn-amber-ink)',
            display: 'flex', alignItems: 'flex-start', gap: 8,
          }}>
            <Icon name="warn" size={11} style={{ flexShrink: 0, marginTop: 1 }}/>
            <span>{node.flagNote}</span>
          </div>
        )}

        {/* Mini score bars */}
        <div style={{ marginTop: 14, display: 'grid', gridTemplateColumns: '90px 1fr auto', gap: 8, alignItems: 'center', fontSize: 11 }}>
          <span style={{ color: 'var(--tn-ink-4)' }}>Centralnost</span>
          <div style={{ height: 5, background: 'var(--tn-paper-2)', borderRadius: 1 }}>
            <div style={{ height: '100%', width: `${node.score}%`, background: 'var(--tn-navy-800)' }}/>
          </div>
          <span className="tn-mono tn-tnum" style={{ color: 'var(--tn-ink-3)' }}>{node.score}/100</span>
          <span style={{ color: 'var(--tn-ink-4)' }}>Javni podaci</span>
          <div style={{ height: 5, background: 'var(--tn-paper-2)', borderRadius: 1 }}>
            <div style={{ height: '100%', width: `${node.notability === 'public' ? 92 : 48}%`, background: 'var(--tn-navy-600)' }}/>
          </div>
          <span className="tn-mono tn-tnum" style={{ color: 'var(--tn-ink-3)' }}>{node.notability === 'public' ? 'javna os.' : 'priv.'}</span>
          <span style={{ color: 'var(--tn-ink-4)' }}>Stupanj (vez.)</span>
          <div style={{ height: 5, background: 'var(--tn-paper-2)', borderRadius: 1 }}>
            <div style={{ height: '100%', width: `${Math.min(100, nodeEdges.length * 10)}%`, background: 'var(--tn-navy-500)' }}/>
          </div>
          <span className="tn-mono tn-tnum" style={{ color: 'var(--tn-ink-3)' }}>{nodeEdges.length}</span>
        </div>
      </div>

      {/* Connections grouped by rel type */}
      <div style={{ padding: '14px 18px 4px' }}>
        <div className="tn-caps" style={{ fontSize: 10, marginBottom: 8 }}>
          Veze <span style={{ color: 'var(--tn-ink-5)', fontWeight: 500 }}>· {nodeEdges.length}</span>
        </div>
        {Object.entries(byRel).map(([rel, es]) => (
          <div key={rel} style={{ marginBottom: 10 }}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 6,
              fontSize: 10, color: REL_TYPES[rel].color,
              textTransform: 'uppercase', letterSpacing: 0.3, fontWeight: 600,
              marginBottom: 4,
            }}>
              <span style={{ width: 10, height: 2, background: REL_TYPES[rel].color }}/>
              {REL_TYPES[rel].label} <span style={{ color: 'var(--tn-ink-5)', fontWeight: 500 }}>· {es.length}</span>
            </div>
            {es.map((e, i) => {
              const otherId = e[0] === node.id ? e[1] : e[0];
              const other = nodes.find(n => n.id === otherId);
              const ot = NODE_TYPES[other.type];
              return (
                <div key={i} onClick={() => onSelect(otherId)}
                  style={{
                    display: 'grid', gridTemplateColumns: 'auto 1fr auto', gap: 8,
                    padding: '6px 8px', cursor: 'pointer',
                    borderBottom: '1px solid var(--tn-rule-2)',
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--tn-paper-2)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                  <div style={{
                    width: 22, height: 22, background: ot.fill,
                    border: `1.5px solid ${ot.stroke}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '50%',
                    color: ot.text, flexShrink: 0,
                  }}>
                    <svg width="14" height="14" viewBox="-7 -7 14 14">
                      <GlyphSmall type={other.type} color={ot.text} size={11}/>
                    </svg>
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 12, color: 'var(--tn-navy-800)', fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{other.label}</div>
                    <div className="tn-mono" style={{ fontSize: 10, color: 'var(--tn-ink-4)' }}>→ {e[3]}</div>
                  </div>
                  <span className="tn-mono tn-tnum" style={{ fontSize: 10, color: 'var(--tn-ink-5)', alignSelf: 'center' }}>{e[4]}</span>
                </div>
              );
            })}
          </div>
        ))}
      </div>

      {/* Provenance */}
      <div style={{ padding: '14px 18px', borderTop: '1px solid var(--tn-rule)', background: 'var(--tn-paper-2)' }}>
        <div className="tn-caps" style={{ fontSize: 10, marginBottom: 8 }}>Izvori (4)</div>
        {[
          ['Sudski registar',    '2026-04-22 · 11:03Z'],
          ['Imovinske kartice',  '2026-04-18 · 09:42Z'],
          ['EOJN',               '2026-04-20 · 06:00Z'],
          ['DIP — financije',    '2026-04-15 · 06:00Z'],
        ].map(([src, t]) => (
          <a href="#" key={src} style={{
            display: 'flex', justifyContent: 'space-between', padding: '4px 0',
            textDecoration: 'none', fontSize: 11,
          }}>
            <span style={{ color: 'var(--tn-navy-800)' }}>{src}</span>
            <span className="tn-mono" style={{ color: 'var(--tn-ink-5)' }}>{t}</span>
          </a>
        ))}
      </div>

      <div style={{ padding: '14px 18px', borderTop: '1px solid var(--tn-rule)' }}>
        <Button variant="primary" size="sm" iconRight="arrow" style={{ width: '100%' }}>
          Otvori cijeli profil
        </Button>
        <Button variant="ghost" size="sm" icon="share" style={{ width: '100%', marginTop: 6 }}>
          Dijeli trenutni prikaz
        </Button>
      </div>
    </aside>
  );
};

Object.assign(window, {
  NODE_TYPES, REL_TYPES, LAYOUTS,
  GraphTopToolbar, GraphLeftRail, GraphCanvasSvg,
  GraphLegend, GraphZoomCluster, GraphContextMenu,
  GraphInspector, PathFindingBanner, GlyphSmall,
});
