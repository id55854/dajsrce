/* Transparentno.hr — component primitives */

const { useState, useEffect, useRef, useMemo } = React;

// ── Icons (inline, minimal stroke icons only) ──────────────────
const Icon = ({ name, size = 16, stroke = 1.6, style = {} }) => {
  const paths = {
    search:  <><circle cx="7" cy="7" r="5"/><path d="M11 11l4 4"/></>,
    external:<><path d="M5 5h5v5"/><path d="M10 5L4 11"/></>,
    filter:  <><path d="M2 3h12M4 8h8M6 13h4"/></>,
    download:<><path d="M8 2v9M4 8l4 3 4-3"/><path d="M2 14h12"/></>,
    link:    <><path d="M6 9a2.5 2.5 0 010-3.5L8 3.5a2.5 2.5 0 013.5 3.5L10 8.5"/><path d="M9 6a2.5 2.5 0 010 3.5L7 11.5a2.5 2.5 0 01-3.5-3.5L5 6.5"/></>,
    arrow:   <><path d="M3 8h10M9 4l4 4-4 4"/></>,
    clock:   <><circle cx="8" cy="8" r="6"/><path d="M8 4v4l3 2"/></>,
    warn:    <><path d="M8 2l6 11H2L8 2z"/><path d="M8 7v3M8 11.5v.5"/></>,
    check:   <><path d="M3 8l3 3 7-7"/></>,
    doc:     <><path d="M4 2h6l3 3v9H4V2z"/><path d="M10 2v3h3"/></>,
    chev:    <><path d="M6 4l4 4-4 4"/></>,
    chevD:   <><path d="M4 6l4 4 4-4"/></>,
    x:       <><path d="M3 3l10 10M13 3L3 13"/></>,
    plus:    <><path d="M8 3v10M3 8h10"/></>,
    minus:   <><path d="M3 8h10"/></>,
    eye:     <><path d="M1 8s2.5-4.5 7-4.5S15 8 15 8s-2.5 4.5-7 4.5S1 8 1 8z"/><circle cx="8" cy="8" r="2"/></>,
    building:<><path d="M3 14h10M4 14V4h6v10M7 7h1M7 10h1"/><path d="M10 7h2v7"/></>,
    person:  <><circle cx="8" cy="5.5" r="2.5"/><path d="M3 14c0-2.5 2.2-4.5 5-4.5s5 2 5 4.5"/></>,
    parcel:  <><path d="M2 4l6-2 6 2v8l-6 2-6-2V4z"/><path d="M8 2v12M2 4l6 2 6-2"/></>,
    event:   <><circle cx="8" cy="8" r="1.5"/><path d="M8 1.5v2M8 12.5v2M1.5 8h2M12.5 8h2"/></>,
    graph:   <><circle cx="3" cy="8" r="1.5"/><circle cx="13" cy="4" r="1.5"/><circle cx="13" cy="12" r="1.5"/><path d="M4.3 7.3L11.7 4.7M4.3 8.7l7.4 2.6"/></>,
    shield:  <><path d="M8 2l5 2v4c0 3-2 5-5 6-3-1-5-3-5-6V4l5-2z"/></>,
    list:    <><path d="M5 4h9M5 8h9M5 12h9"/><circle cx="2.5" cy="4" r=".8"/><circle cx="2.5" cy="8" r=".8"/><circle cx="2.5" cy="12" r=".8"/></>,
    chevron: <><path d="M4 6l4 4 4-4"/></>,
    move:    <><path d="M8 2v12M2 8h12M8 2l-2 2M8 2l2 2M8 14l-2-2M8 14l2-2M2 8l2-2M2 8l2 2M14 8l-2-2M14 8l-2 2"/></>,
    select:  <><path d="M3 3l4 10 2-4 4-2z"/></>,
    pin:     <><path d="M8 2l3 3-1 1 2 2-4 1-1 5-2-5-4-1 2-2-1-1 3-3z"/></>,
    'eye-off': <><path d="M2 8s2.5-4.5 6-4.5c1 0 1.9.3 2.7.8M14 8s-1 2-3 3.3M13 3L3 13"/><path d="M6.5 6.5a2 2 0 002.8 2.8"/></>,
    ruler:   <><path d="M2 5l9-3 3 9-9 3z"/><path d="M5 4l.7 2M7 3.5l.7 2M9 3l.7 2M11 2.5l.7 2"/></>,
    type:    <><path d="M3 4h10M8 4v10M5 14h6"/></>,
    help:    <><circle cx="8" cy="8" r="6"/><path d="M6 6.5a2 2 0 113 1.7c-.7.4-1 .7-1 1.3M8 12v.3"/></>,
    save:    <><path d="M2 2h9l3 3v9H2V2z"/><path d="M4 2v4h7V2M5 10h6v4H5z"/></>,
    panel:   <><path d="M2 3h12v10H2z"/><path d="M10 3v10"/></>,
    scatter: <><circle cx="4" cy="11" r="1.2"/><circle cx="8" cy="6" r="1.2"/><circle cx="11" cy="10" r="1.2"/><circle cx="12" cy="4" r="1.2"/><circle cx="5" cy="6" r="1.2"/></>,
    circle:  <><circle cx="8" cy="8" r="5.5"/><circle cx="8" cy="8" r="1.2"/></>,
    share:   <><circle cx="4" cy="8" r="1.8"/><circle cx="12" cy="4" r="1.8"/><circle cx="12" cy="12" r="1.8"/><path d="M5.5 7l5-2.5M5.5 9l5 2.5"/></>,
    map:     <><path d="M2 4l4-2 4 2 4-2v10l-4 2-4-2-4 2V4z"/><path d="M6 2v12M10 4v12"/></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" stroke="currentColor"
      strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, ...style }}>
      {paths[name]}
    </svg>
  );
};

// ── Button ─────────────────────────────────────────────────────
const Button = ({ variant = 'primary', size = 'md', icon, iconRight, children, onClick, style = {} }) => {
  const sizes = {
    sm: { padding: '6px 10px', fontSize: 13, gap: 6 },
    md: { padding: '8px 14px', fontSize: 14, gap: 8 },
    lg: { padding: '12px 20px', fontSize: 15, gap: 10 },
  };
  const variants = {
    primary:   { background: 'var(--tn-navy-800)', color: '#fff', border: '1px solid var(--tn-navy-800)' },
    secondary: { background: 'var(--tn-white)', color: 'var(--tn-navy-800)', border: '1px solid var(--tn-rule)' },
    ghost:     { background: 'transparent', color: 'var(--tn-navy-800)', border: '1px solid transparent' },
    danger:    { background: 'var(--tn-white)', color: 'var(--tn-amber-ink)', border: '1px solid var(--tn-amber)' },
  };
  return (
    <button onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      borderRadius: 'var(--tn-r-1)', fontWeight: 500, fontFamily: 'inherit',
      cursor: 'pointer', transition: 'background .12s, border-color .12s',
      ...sizes[size], ...variants[variant], ...style,
    }}>
      {icon && <Icon name={icon} size={size === 'sm' ? 13 : 14} />}
      {children}
      {iconRight && <Icon name={iconRight} size={size === 'sm' ? 13 : 14} />}
    </button>
  );
};

// ── SourceBadge — the atomic provenance unit ──────────────────
// Every fact chip in the app wraps its value in a SourceBadge.
// Hover reveals source + retrieval timestamp + link-out.
const SourceBadge = ({ source, retrieved, url, children, tone = 'default', inline = false }) => {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const tones = {
    default: { bg: 'var(--tn-white)', border: 'var(--tn-rule)', color: 'var(--tn-ink-2)' },
    amber:   { bg: 'var(--tn-amber-weak)', border: 'var(--tn-amber)', color: 'var(--tn-amber-ink)' },
    verify:  { bg: 'var(--tn-verify-weak)', border: 'var(--tn-verify)', color: 'var(--tn-verify)' },
    muted:   { bg: 'var(--tn-paper-2)', border: 'var(--tn-rule)', color: 'var(--tn-ink-3)' },
  };
  const t = tones[tone];
  return (
    <span ref={ref}
      onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)} onBlur={() => setOpen(false)}
      tabIndex={0}
      style={{
        display: inline ? 'inline-flex' : 'inline-flex', alignItems: 'center', gap: 6,
        padding: '2px 8px 2px 8px',
        background: t.bg, border: `1px solid ${t.border}`, color: t.color,
        borderRadius: 'var(--tn-r-1)', fontSize: 13, lineHeight: 1.4,
        position: 'relative', cursor: 'help', fontFamily: 'inherit',
      }}>
      {children}
      <span aria-hidden style={{
        display: 'inline-block', width: 5, height: 5, borderRadius: '50%',
        background: tone === 'amber' ? 'var(--tn-amber)' : tone === 'verify' ? 'var(--tn-verify)' : 'var(--tn-ink-5)',
      }}/>
      {open && (
        <span role="tooltip" style={{
          position: 'absolute', left: 0, top: 'calc(100% + 6px)', zIndex: 20,
          background: 'var(--tn-ink)', color: '#f4f2ea', fontSize: 12,
          padding: '8px 10px', borderRadius: 'var(--tn-r-1)',
          whiteSpace: 'nowrap', boxShadow: 'var(--tn-shadow-2)',
          fontFamily: 'var(--tn-font-mono)', letterSpacing: 0,
          pointerEvents: 'auto', lineHeight: 1.5,
        }}>
          iz: <span style={{ color: '#fff' }}>{source}</span><br/>
          dohvaćeno: <span style={{ color: '#fff' }}>{retrieved}</span>
          {url && <><br/><a href={url} target="_blank" rel="noopener noreferrer" style={{
            color: '#9fc1ff', textDecoration: 'underline',
          }}>original ↗</a></>}
        </span>
      )}
    </span>
  );
};

// ── Chip — inert fact label ────────────────────────────────────
const Chip = ({ children, tone = 'default', icon, onClick, active }) => {
  const tones = {
    default: { bg: 'var(--tn-paper-2)', color: 'var(--tn-ink-2)', border: 'transparent' },
    outline: { bg: 'transparent', color: 'var(--tn-ink-3)', border: 'var(--tn-rule)' },
    navy:    { bg: 'var(--tn-navy-50)', color: 'var(--tn-navy-800)', border: 'transparent' },
    amber:   { bg: 'var(--tn-amber-weak)', color: 'var(--tn-amber-ink)', border: 'var(--tn-amber)' },
  };
  const t = tones[tone];
  return (
    <span onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      padding: '3px 9px',
      background: active ? 'var(--tn-navy-800)' : t.bg,
      color: active ? '#fff' : t.color,
      border: `1px solid ${active ? 'var(--tn-navy-800)' : t.border}`,
      borderRadius: 'var(--tn-r-pill)', fontSize: 12, fontWeight: 500,
      cursor: onClick ? 'pointer' : 'default',
      letterSpacing: 0.1,
    }}>
      {icon && <Icon name={icon} size={11} />}
      {children}
    </span>
  );
};

// ── Exceptional-state badge (amber, reserved) ──────────────────
const WarnBadge = ({ children, title }) => (
  <span title={title} style={{
    display: 'inline-flex', alignItems: 'center', gap: 6,
    padding: '3px 10px 3px 8px',
    background: 'var(--tn-amber-weak)', color: 'var(--tn-amber-ink)',
    border: '1px solid var(--tn-amber)',
    borderRadius: 'var(--tn-r-1)', fontSize: 12, fontWeight: 600, letterSpacing: 0.2,
    textTransform: 'uppercase',
  }}>
    <Icon name="warn" size={11} stroke={2}/>
    {children}
  </span>
);

// ── MetricStat ─────────────────────────────────────────────────
const MetricStat = ({ label, value, unit, delta, mono = true, sourceBadge }) => (
  <div style={{ padding: '14px 16px', background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', borderRadius: 'var(--tn-r-1)' }}>
    <div className="tn-caps" style={{ marginBottom: 6 }}>{label}</div>
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
      <span style={{ fontSize: 24, fontWeight: 600, color: 'var(--tn-ink-2)', fontFamily: mono ? 'var(--tn-font-mono)' : 'inherit', fontVariantNumeric: 'tabular-nums', letterSpacing: -0.5 }}>{value}</span>
      {unit && <span style={{ fontSize: 13, color: 'var(--tn-ink-4)' }}>{unit}</span>}
    </div>
    {delta && <div style={{ fontSize: 12, color: 'var(--tn-ink-4)', marginTop: 4 }}>{delta}</div>}
    {sourceBadge && <div style={{ marginTop: 8 }}>{sourceBadge}</div>}
  </div>
);

// ── EntityCard — search result row ─────────────────────────────
const EntityCard = ({ type, name, subtitle, meta, flags = [], onClick }) => {
  const typeMap = {
    person:   { label: 'Osoba',        icon: 'person',   color: 'var(--tn-navy-700)' },
    org:      { label: 'Pravna osoba', icon: 'building', color: 'var(--tn-navy-700)' },
    asset:    { label: 'Nekretnina',   icon: 'parcel',   color: 'var(--tn-navy-700)' },
    event:    { label: 'Događaj',      icon: 'event',    color: 'var(--tn-navy-700)' },
  };
  const T = typeMap[type];
  return (
    <article onClick={onClick} style={{
      display: 'grid', gridTemplateColumns: '40px 1fr auto', gap: 16,
      padding: '16px 20px', background: 'var(--tn-white)',
      borderBottom: '1px solid var(--tn-rule-2)', cursor: 'pointer',
      transition: 'background .12s',
    }}
    onMouseEnter={(e) => e.currentTarget.style.background = 'var(--tn-paper-2)'}
    onMouseLeave={(e) => e.currentTarget.style.background = 'var(--tn-white)'}>
      <div style={{
        width: 36, height: 36, borderRadius: 'var(--tn-r-1)',
        background: 'var(--tn-navy-50)', color: T.color,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <Icon name={T.icon} size={18} stroke={1.5}/>
      </div>
      <div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, flexWrap: 'wrap' }}>
          <span className="tn-caps" style={{ fontSize: 10 }}>{T.label}</span>
          <h3 className="tn-serif" style={{ fontSize: 18, fontWeight: 500, color: 'var(--tn-navy-800)' }}>{name}</h3>
          {flags.map((f, i) => <WarnBadge key={i}>{f}</WarnBadge>)}
        </div>
        {subtitle && <div style={{ marginTop: 4, color: 'var(--tn-ink-3)', fontSize: 13 }}>{subtitle}</div>}
        {meta && <div style={{ marginTop: 8, display: 'flex', gap: 16, flexWrap: 'wrap', fontSize: 12, color: 'var(--tn-ink-4)', fontFamily: 'var(--tn-font-mono)' }}>{meta}</div>}
      </div>
      <div style={{ color: 'var(--tn-ink-5)', display: 'flex', alignItems: 'center' }}>
        <Icon name="arrow" size={16}/>
      </div>
    </article>
  );
};

// ── TimelineItem ───────────────────────────────────────────────
const TimelineItem = ({ date, dateRaw, kind, title, children, source, retrieved, url, tone = 'default', last }) => {
  const dotColor = tone === 'amber' ? 'var(--tn-amber)' : tone === 'verify' ? 'var(--tn-verify)' : 'var(--tn-navy-700)';
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '120px 24px 1fr', gap: 16, position: 'relative', paddingBottom: last ? 0 : 20 }}>
      <div style={{ textAlign: 'right', paddingTop: 2 }}>
        <div className="tn-mono tn-tnum" style={{ fontSize: 13, color: 'var(--tn-ink-2)' }}>{date}</div>
        {dateRaw && <div className="tn-mono" style={{ fontSize: 11, color: 'var(--tn-ink-5)' }}>{dateRaw}</div>}
      </div>
      <div style={{ position: 'relative', display: 'flex', justifyContent: 'center' }}>
        <div style={{ width: 9, height: 9, borderRadius: '50%', background: dotColor, marginTop: 7, border: '2px solid var(--tn-white)', boxShadow: `0 0 0 1px ${dotColor}` }}/>
        {!last && <div style={{ position: 'absolute', top: 18, bottom: -20, width: 1, background: 'var(--tn-rule)' }}/>}
      </div>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span className="tn-caps" style={{ color: dotColor, fontSize: 10 }}>{kind}</span>
          {source && <SourceBadge source={source} retrieved={retrieved} url={url} tone={tone === 'amber' ? 'amber' : 'muted'}>
            <span style={{ fontSize: 11 }}>{source.split(' ')[0]}</span>
          </SourceBadge>}
        </div>
        <div style={{ marginTop: 3, color: 'var(--tn-ink-2)', fontSize: 14, fontWeight: 500 }}>{title}</div>
        {children && <div style={{ marginTop: 4, color: 'var(--tn-ink-3)', fontSize: 13 }}>{children}</div>}
      </div>
    </div>
  );
};

// ── Data row — key/value (for entity pages) ────────────────────
const DataRow = ({ label, children, mono = false }) => (
  <div style={{
    display: 'grid', gridTemplateColumns: '180px 1fr', gap: 24,
    padding: '10px 0', borderBottom: '1px solid var(--tn-rule-2)',
  }}>
    <div style={{ color: 'var(--tn-ink-4)', fontSize: 13 }}>{label}</div>
    <div style={{ color: 'var(--tn-ink-2)', fontSize: 14, fontFamily: mono ? 'var(--tn-font-mono)' : 'inherit' }}>{children}</div>
  </div>
);

// ── Section header ─────────────────────────────────────────────
const SectionH = ({ children, right, subtitle }) => (
  <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 16, marginBottom: 14, paddingBottom: 10, borderBottom: '1px solid var(--tn-rule)' }}>
    <div>
      <h2 style={{ fontSize: 14, textTransform: 'uppercase', letterSpacing: 0.1, color: 'var(--tn-ink-2)', fontWeight: 600 }}>{children}</h2>
      {subtitle && <div style={{ fontSize: 12, color: 'var(--tn-ink-4)', marginTop: 2 }}>{subtitle}</div>}
    </div>
    {right}
  </div>
);

// ── TopBar ─────────────────────────────────────────────────────
const TopBar = ({ lang = 'HR', onLang, showSearch = true, currentPath }) => (
  <header style={{
    position: 'sticky', top: 0, zIndex: 10,
    background: 'var(--tn-white)',
    borderBottom: '1px solid var(--tn-rule)',
    padding: '0 28px',
    display: 'flex', alignItems: 'center', gap: 24,
    height: 56,
  }}>
    {/* Wordmark — original */}
    <a href="#" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 10 }}>
      <span style={{
        width: 26, height: 26, borderRadius: 'var(--tn-r-1)',
        background: 'var(--tn-navy-800)', color: '#fff',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'var(--tn-font-serif)', fontWeight: 600, fontSize: 15,
      }}>T</span>
      <span style={{ fontFamily: 'var(--tn-font-serif)', fontSize: 18, fontWeight: 500, color: 'var(--tn-navy-800)', letterSpacing: -0.2 }}>
        Transparentno<span style={{ color: 'var(--tn-ink-5)' }}>.hr</span>
      </span>
    </a>
    <nav style={{ display: 'flex', gap: 4, marginLeft: 16 }}>
      {['Pretraga', 'Graf', 'Registri', 'Metodologija'].map((n, i) => (
        <a key={n} href="#" style={{
          fontSize: 13, padding: '6px 10px', textDecoration: 'none',
          color: i === 0 && currentPath === 'search' ? 'var(--tn-navy-800)' : 'var(--tn-ink-3)',
          fontWeight: i === 0 && currentPath === 'search' ? 600 : 400,
          borderRadius: 'var(--tn-r-1)',
        }}>{n}</a>
      ))}
    </nav>
    <div style={{ flex: 1 }}/>
    {showSearch && (
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '6px 10px', background: 'var(--tn-paper-2)',
        border: '1px solid var(--tn-rule)', borderRadius: 'var(--tn-r-1)',
        width: 280, color: 'var(--tn-ink-4)',
      }}>
        <Icon name="search" size={14}/>
        <span style={{ fontSize: 13 }}>Pretraži osobu, OIB, MBS, parcelu…</span>
        <span style={{ marginLeft: 'auto', fontFamily: 'var(--tn-font-mono)', fontSize: 11, color: 'var(--tn-ink-5)', padding: '1px 5px', border: '1px solid var(--tn-rule)', borderRadius: 2 }}>⌘K</span>
      </div>
    )}
    <div style={{ display: 'flex', border: '1px solid var(--tn-rule)', borderRadius: 'var(--tn-r-1)', overflow: 'hidden' }}>
      {['HR', 'EN'].map((l) => (
        <button key={l} onClick={() => onLang && onLang(l)} style={{
          padding: '5px 10px', border: 'none', fontSize: 12, fontWeight: 600,
          background: l === lang ? 'var(--tn-navy-800)' : 'var(--tn-white)',
          color: l === lang ? '#fff' : 'var(--tn-ink-3)',
          fontFamily: 'inherit', letterSpacing: 0.3,
        }}>{l}</button>
      ))}
    </div>
  </header>
);

Object.assign(window, {
  Icon, Button, SourceBadge, Chip, WarnBadge,
  MetricStat, EntityCard, TimelineItem, DataRow, SectionH, TopBar,
});
