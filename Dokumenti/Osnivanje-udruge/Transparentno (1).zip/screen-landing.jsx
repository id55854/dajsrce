/* Landing screen — v2, per detailed spec */

const LandingScreen = () => {
  const [q, setQ] = React.useState('');

  const examples = [
    'Andrej Plenković',
    'HEP d.d.',
    'ZK-224 Grad Zagreb',
    'Ministarstvo zdravstva ugovori 2025',
  ];

  return (
    <div className="tn-root" style={{ minHeight: '100%', background: 'var(--tn-paper)' }}>
      <TopBar lang="HR" showSearch={false}/>

      {/* ─── Hero ───────────────────────────────────────────── */}
      <section style={{
        background: 'var(--tn-paper)',
        padding: '88px 80px 96px',
        borderBottom: '1px solid var(--tn-rule)',
        position: 'relative',
      }}>
        {/* thin top rule — document masthead feel */}
        <div style={{ maxWidth: 1080, margin: '0 auto' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 28 }}>
            <div style={{ height: 2, width: 40, background: 'var(--tn-navy-800)' }}/>
            <span className="tn-caps" style={{ color: 'var(--tn-navy-800)', fontSize: 11 }}>
              Javna baza znanja · Republika Hrvatska
            </span>
          </div>

          {/* One-line value prop */}
          <h1 className="tn-serif" style={{
            fontSize: 56, fontWeight: 400, letterSpacing: -1.6, lineHeight: 1.1,
            color: 'var(--tn-navy-900)', maxWidth: 980, textWrap: 'pretty',
          }}>
            Sve što je javno o javnom novcu, osobama i tvrtkama
            u Hrvatskoj — <em style={{ color: 'var(--tn-navy-700)' }}>na jednom mjestu</em>.
          </h1>

          {/* Universal search */}
          <div style={{
            marginTop: 40,
            display: 'flex',
            background: 'var(--tn-white)',
            border: '1px solid var(--tn-navy-800)',
            boxShadow: '0 1px 0 rgba(11,37,69,.04), 0 8px 32px rgba(11,37,69,.08)',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', padding: '0 18px', color: 'var(--tn-navy-700)' }}>
              <Icon name="search" size={22} stroke={1.6}/>
            </div>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Traži osobu, tvrtku, OIB, adresu, nekretninu…"
              style={{
                flex: 1, border: 'none', outline: 'none',
                padding: '22px 4px',
                fontSize: 18, fontFamily: 'inherit', color: 'var(--tn-ink)',
                background: 'transparent',
              }}
            />
            <Button size="lg" style={{
              margin: 6, padding: '12px 28px', fontSize: 15,
              background: 'var(--tn-navy-800)', color: '#fff',
            }}>
              Pretraži
            </Button>
          </div>

          {/* Example chips */}
          <div style={{ marginTop: 20, display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
            <span className="tn-caps" style={{ color: 'var(--tn-ink-4)', fontSize: 11, marginRight: 4 }}>
              Primjeri
            </span>
            {examples.map((ex) => (
              <button key={ex} onClick={() => setQ(ex)} style={{
                padding: '7px 14px',
                background: 'var(--tn-white)',
                border: '1px solid var(--tn-rule)',
                borderRadius: 'var(--tn-r-pill)',
                fontSize: 13, color: 'var(--tn-navy-800)',
                fontFamily: 'inherit', fontWeight: 500,
                cursor: 'pointer',
                transition: 'border-color .12s, background .12s',
              }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = 'var(--tn-navy-800)'; e.currentTarget.style.background = 'var(--tn-paper-2)'; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = 'var(--tn-rule)'; e.currentTarget.style.background = 'var(--tn-white)'; }}>
                „{ex}"
              </button>
            ))}
          </div>

          {/* Operational ticker — light */}
          <div style={{
            marginTop: 56, paddingTop: 28, borderTop: '1px solid var(--tn-rule)',
            display: 'flex', gap: 56, flexWrap: 'wrap',
          }}>
            {[
              ['2,84 mil.', 'pravnih osoba'],
              ['7,12 mil.', 'ugovora · EOJN'],
              ['183.441', 'imovinskih kartica'],
              ['9', 'federiranih izvora'],
              ['14 min', 'median svježine'],
            ].map(([v, l]) => (
              <div key={l}>
                <div className="tn-mono tn-tnum" style={{ fontSize: 22, color: 'var(--tn-navy-900)', fontWeight: 500, letterSpacing: -0.3 }}>{v}</div>
                <div style={{ fontSize: 12, color: 'var(--tn-ink-4)', marginTop: 2 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Permanent lists ────────────────────────────────── */}
      <section style={{ padding: '72px 80px 64px', background: 'var(--tn-paper)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 32 }}>
            <div>
              <div className="tn-caps" style={{ color: 'var(--tn-navy-800)', marginBottom: 6 }}>Stalne liste</div>
              <h2 className="tn-serif" style={{ fontSize: 32, fontWeight: 500, color: 'var(--tn-navy-900)', letterSpacing: -0.6 }}>
                Što trenutno vrijedi pratiti
              </h2>
            </div>
            <span className="tn-mono" style={{ fontSize: 12, color: 'var(--tn-ink-4)' }}>
              automatski se obnavlja · zadnje: 24. trav 2026, 06:00
            </span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 16 }}>
            {[
              {
                num: '1', kind: '01',
                label: 'Najveći dobavljači države',
                period: '2025',
                headVal: '8,42',
                headUnit: 'mlrd. EUR',
                headLabel: 'ukupno isplaćeno',
                rows: [
                  ['Končar d.d.',       '184,2 mil.'],
                  ['Ingra d.d.',        '122,8 mil.'],
                  ['Strabag AG · HR',   '98,4 mil.'],
                ],
                source: 'EOJN',
              },
              {
                num: '2', kind: '02',
                label: 'Najveći rast deklarirane imovine dužnosnika',
                period: '2024 → 2025',
                headVal: '+38',
                headUnit: 'dužnosnika',
                headLabel: 'rast > 20%',
                rows: [
                  ['Z. M., saborski zastupnik', '+218%'],
                  ['M. P., gradonačelnik',      '+174%'],
                  ['I. B., član uprave HEP',    '+92%'],
                ],
                source: 'Imov. kartice',
              },
              {
                num: '3', kind: '03',
                label: 'Tjedne promjene u Sudskom registru',
                period: 'tjedan 17',
                headVal: '4.218',
                headUnit: 'zapisa',
                headLabel: 'promjena ovog tjedna',
                rows: [
                  ['Novoosnovano',      '1.842'],
                  ['Promjena uprave',   '627'],
                  ['Prestanak',         '184'],
                ],
                source: 'Sudski registar',
              },
              {
                num: '4', kind: '04',
                label: 'Rastući porezni dužnici',
                period: 'travanj 2026',
                headVal: '2.184',
                headUnit: 'subjekta',
                headLabel: 'na popisu',
                rows: [
                  ['Pravne osobe',      '1.412'],
                  ['Fizičke osobe',     '624'],
                  ['Obrti',             '148'],
                ],
                source: 'Porezna uprava',
                warn: true,
              },
              {
                num: '5', kind: '05',
                label: 'Dražbe tjedna',
                period: 'tjedan 17',
                headVal: '312',
                headUnit: 'nekretnina',
                headLabel: 'zakazano · nadolazeći tjedan',
                rows: [
                  ['Grad Zagreb',       '84'],
                  ['Split-Dalmatinska', '42'],
                  ['Istarska',          '31'],
                ],
                source: 'e-Oglasna ploča',
              },
            ].map((c) => (
              <article key={c.num} style={{
                background: 'var(--tn-white)',
                border: '1px solid var(--tn-rule)',
                padding: '20px 20px 16px',
                display: 'flex', flexDirection: 'column', minHeight: 340,
                position: 'relative',
              }}>
                {/* top row: number · period */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 18 }}>
                  <span className="tn-mono" style={{ fontSize: 11, color: 'var(--tn-ink-5)', letterSpacing: 0.5 }}>№ {c.kind}</span>
                  <span className="tn-mono" style={{ fontSize: 11, color: 'var(--tn-ink-4)' }}>{c.period}</span>
                </div>

                {/* Headline number */}
                <div style={{ marginBottom: 6 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
                    <span className="tn-tnum" style={{
                      fontSize: 40, fontWeight: 500, lineHeight: 1,
                      color: c.warn ? 'var(--tn-amber-ink)' : 'var(--tn-navy-900)',
                      fontFamily: 'var(--tn-font-serif)',
                      letterSpacing: -1.2,
                    }}>{c.headVal}</span>
                    <span style={{ fontSize: 13, color: 'var(--tn-ink-4)' }}>{c.headUnit}</span>
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--tn-ink-4)', marginTop: 2 }}>{c.headLabel}</div>
                </div>

                {/* Short label */}
                <div style={{
                  fontSize: 14, color: 'var(--tn-ink-2)', fontWeight: 600,
                  marginTop: 14, marginBottom: 12, lineHeight: 1.35,
                  minHeight: 40,
                }}>
                  {c.label}
                </div>

                {/* Mini rows */}
                <div style={{ borderTop: '1px solid var(--tn-rule-2)', paddingTop: 10, flex: 1 }}>
                  {c.rows.map(([k, v], i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', fontSize: 12 }}>
                      <span style={{ color: 'var(--tn-ink-3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginRight: 8 }}>{k}</span>
                      <span className="tn-mono tn-tnum" style={{ color: 'var(--tn-ink-2)', fontWeight: 500, flexShrink: 0 }}>{v}</span>
                    </div>
                  ))}
                </div>

                {/* Footer: source + link */}
                <div style={{
                  marginTop: 12, paddingTop: 12,
                  borderTop: '1px solid var(--tn-rule-2)',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                }}>
                  <span className="tn-mono" style={{ fontSize: 10, color: 'var(--tn-ink-5)', textTransform: 'uppercase', letterSpacing: 0.3 }}>
                    iz: {c.source}
                  </span>
                  <a href="#" style={{
                    fontSize: 12, color: 'var(--tn-navy-800)',
                    fontWeight: 600, textDecoration: 'none',
                    display: 'inline-flex', alignItems: 'center', gap: 4,
                  }}>
                    pogledaj sve <Icon name="arrow" size={12}/>
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Kako radi ─────────────────────────────────────── */}
      <section style={{
        padding: '80px 80px',
        background: 'var(--tn-paper-2)',
        borderTop: '1px solid var(--tn-rule)',
        borderBottom: '1px solid var(--tn-rule)',
      }}>
        <div style={{ maxWidth: 1080, margin: '0 auto' }}>
          <div style={{ maxWidth: 640, marginBottom: 40 }}>
            <div className="tn-caps" style={{ color: 'var(--tn-navy-800)', marginBottom: 6 }}>Kako radi</div>
            <h2 className="tn-serif" style={{ fontSize: 32, fontWeight: 500, color: 'var(--tn-navy-900)', letterSpacing: -0.6 }}>
              Tri koraka od pitanja do citat-spremnog izvora.
            </h2>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 40px 1fr 40px 1fr', alignItems: 'flex-start', gap: 0 }}>
            {[
              {
                step: '01',
                title: 'Pretraži',
                body: 'Jedno polje za osobe, tvrtke, OIB, adrese, parcele. Pretraga federira 9 izvora istovremeno i vraća jedinstvene entitete.',
                icon: 'search',
              },
              {
                step: '02',
                title: 'Otvori profil',
                body: 'Identitet, funkcije, imovina, ugovori, sudski predmeti — strukturirano i s provenijencijom za svaku činjenicu.',
                icon: 'doc',
              },
              {
                step: '03',
                title: 'Istraži mrežu',
                body: 'Pogled grafa pokazuje strukturne veze iz registara. Bez imputacije — samo ono što piše u izvoru.',
                icon: 'graph',
              },
            ].flatMap((s, i, a) => [
              <div key={s.step}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
                  <span className="tn-mono tn-tnum" style={{ fontSize: 32, color: 'var(--tn-navy-700)', fontWeight: 500, letterSpacing: -0.5 }}>
                    {s.step}
                  </span>
                  <div style={{
                    width: 40, height: 40, border: '1px solid var(--tn-navy-800)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: 'var(--tn-navy-800)',
                  }}>
                    <Icon name={s.icon} size={18} stroke={1.5}/>
                  </div>
                </div>
                <h3 className="tn-serif" style={{ fontSize: 22, fontWeight: 500, color: 'var(--tn-navy-900)', marginBottom: 8 }}>
                  {s.title}
                </h3>
                <p style={{ fontSize: 14, color: 'var(--tn-ink-3)', lineHeight: 1.6 }}>
                  {s.body}
                </p>
              </div>,
              i < a.length - 1 && (
                <div key={`sep${i}`} style={{ paddingTop: 28, color: 'var(--tn-ink-5)', display: 'flex', justifyContent: 'center' }}>
                  <Icon name="arrow" size={22}/>
                </div>
              ),
            ]).filter(Boolean)}
          </div>
        </div>
      </section>

      {/* ─── Za novinare i istraživače CTA ─────────────────── */}
      <section style={{
        padding: '64px 80px',
        background: 'var(--tn-navy-900)', color: '#f2efe7',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', inset: 0, opacity: 0.06, pointerEvents: 'none',
          backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
          backgroundSize: '48px 48px',
        }}/>
        <div style={{ position: 'relative', maxWidth: 1080, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr auto', gap: 48, alignItems: 'center' }}>
          <div>
            <div className="tn-caps" style={{ color: '#d9c78a', marginBottom: 10 }}>Za novinare i istraživače</div>
            <h2 className="tn-serif" style={{ fontSize: 32, fontWeight: 400, letterSpacing: -0.6, lineHeight: 1.15, marginBottom: 12 }}>
              Pristup spremljenim upitima, obavijestima o promjenama i bulk preuzimanjima.
            </h2>
            <p style={{ fontSize: 15, color: 'rgba(242,239,231,.7)', lineHeight: 1.55, maxWidth: 640 }}>
              Besplatno za akreditirane medije i NGO-ove. Registracija zahtijeva verifikaciju redakcije ili institucije;
              odobravamo u roku od 48 sati.
            </p>
            <div style={{ marginTop: 18, display: 'flex', gap: 24, fontSize: 12, color: 'rgba(242,239,231,.55)', fontFamily: 'var(--tn-font-mono)' }}>
              <span>✓ neograničeni upiti</span>
              <span>✓ e-mail obavijesti o promjenama</span>
              <span>✓ bulk CSV / Parquet izvoz</span>
              <span>✓ API ključ</span>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, flexShrink: 0 }}>
            <Button size="lg" style={{ background: '#d9c78a', color: 'var(--tn-navy-900)', border: '1px solid #d9c78a', fontWeight: 600, padding: '14px 24px' }}>
              Zatraži pristup
            </Button>
            <a href="#" style={{ fontSize: 12, color: 'rgba(242,239,231,.7)', textAlign: 'center', textDecoration: 'underline', textDecorationColor: 'rgba(255,255,255,.2)' }}>
              uvjeti korištenja za medije ↗
            </a>
          </div>
        </div>
      </section>

      {/* ─── Footer ────────────────────────────────────────── */}
      <footer style={{ background: 'var(--tn-navy-900)', color: 'rgba(242,239,231,.75)', padding: '56px 80px 32px' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr', gap: 40, marginBottom: 40 }}>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
                <span style={{
                  width: 28, height: 28, background: '#fff', color: 'var(--tn-navy-900)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: 'var(--tn-font-serif)', fontWeight: 600, fontSize: 16,
                }}>T</span>
                <span className="tn-serif" style={{ fontSize: 18, color: '#fff', fontWeight: 500 }}>
                  Transparentno<span style={{ color: 'rgba(255,255,255,.5)' }}>.hr</span>
                </span>
              </div>
              <p style={{ fontSize: 13, color: 'rgba(242,239,231,.6)', lineHeight: 1.6, maxWidth: 340 }}>
                Neprofitni projekt. Federiramo javne registre Republike Hrvatske
                u jedinstvenu pretragu. Ne interpretiramo, ne sumiramo.
              </p>
              <div style={{ marginTop: 16, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <span style={{ fontSize: 11, fontFamily: 'var(--tn-font-mono)', padding: '3px 8px', border: '1px solid rgba(255,255,255,.2)', color: 'rgba(255,255,255,.7)' }}>CC-BY 4.0</span>
                <span style={{ fontSize: 11, fontFamily: 'var(--tn-font-mono)', padding: '3px 8px', border: '1px solid rgba(255,255,255,.2)', color: 'rgba(255,255,255,.7)' }}>WCAG 2.2 AA</span>
                <span style={{ fontSize: 11, fontFamily: 'var(--tn-font-mono)', padding: '3px 8px', border: '1px solid rgba(255,255,255,.2)', color: 'rgba(255,255,255,.7)' }}>GDPR</span>
              </div>
            </div>

            {[
              ['Projekt', [['O projektu', '#'], ['Metodologija', '#'], ['Tim', '#'], ['Financijska izvješća', '#']]],
              ['Podaci', [['Izvori podataka', '#'], ['Open data · bulk', '#'], ['API', '#'], ['Status sinkronizacije', '#']]],
              ['Pravno', [['Pravila privatnosti', '#'], ['Uvjeti korištenja', '#'], ['Zahtjev za brisanje', '#'], ['Kolačići', '#']]],
              ['Sudjeluj', [['Kontakt', '#'], ['GitHub', '#'], ['Prijavi grešku', '#'], ['Donacije', '#']]],
            ].map(([h, links]) => (
              <div key={h}>
                <div className="tn-caps" style={{ color: 'rgba(255,255,255,.5)', marginBottom: 14, fontSize: 11 }}>{h}</div>
                {links.map(([l, href]) => (
                  <a key={l} href={href} style={{
                    display: 'block', fontSize: 13, padding: '5px 0',
                    color: 'rgba(242,239,231,.8)', textDecoration: 'none',
                  }}>{l}</a>
                ))}
              </div>
            ))}
          </div>

          <div style={{
            paddingTop: 24, borderTop: '1px solid rgba(255,255,255,.12)',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16,
            fontSize: 12, color: 'rgba(242,239,231,.5)',
          }}>
            <div className="tn-mono">© 2024–2026 Udruga Transparentno · OIB 11223344556</div>
            <div className="tn-mono">v0.9.2 · zadnji deploy 2026-04-23 08:14 UTC</div>
          </div>
        </div>
      </footer>
    </div>
  );
};
window.LandingScreen = LandingScreen;
