/* Org page — sub-components
   Mini-graph, timeline, Ugovori-s-državom hero tab.            */

const { useState: uOS, useMemo: umOS } = React;

// ── Org mini-graph — officers / shareholders / group / counterparties ──
const OrgMiniGraph = ({ onOpen }) => {
  const W = 340, H = 340;
  const nodes = [
    // Centre
    { id: 'k',   t: 'org-self', lbl: 'Končar d.d.',                 x: 170, y: 170 },
    // Officers (top)
    { id: 'gk',  t: 'person',   lbl: 'G. Kolak',      sub: 'pred. uprave', x:  80, y:  40 },
    { id: 'jm',  t: 'person',   lbl: 'J. Miloloža',   sub: 'član',         x: 170, y:  30 },
    { id: 'mp',  t: 'person',   lbl: 'M. Poljak',     sub: 'CFO',          x: 260, y:  40 },
    // Shareholders (left)
    { id: 'rh',  t: 'org-pub',  lbl: 'RH · CERP',    sub: '33,4%',         x:  30, y: 140 },
    { id: 'hep', t: 'org-pub',  lbl: 'HEP d.d.',     sub: '18,2%',         x:  30, y: 210 },
    // Group (bottom)
    { id: 'kdt', t: 'org-sub',  lbl: 'K. — Distr. tr.',sub: '100%',         x: 105, y: 298 },
    { id: 'ket', t: 'org-sub',  lbl: 'K. — Energ. tr.',sub: '51%',          x: 200, y: 302 },
    { id: 'kev', t: 'org-sub',  lbl: 'K. — Elektr. v.',sub: '70%',         x: 280, y: 292 },
    // Counterparties — state (right)
    { id: 'hep2',t: 'counter',  lbl: 'HEP',           sub: '38,4 mil.',     x: 308, y: 150 },
    { id: 'hz',  t: 'counter',  lbl: 'HŽ Infra.',    sub: '22,1 mil.',     x: 312, y: 220 },
  ];
  const edges = [
    // ownership up (share → us)
    { a: 'rh',  b: 'k', kind: 'own',  strong: true  },
    { a: 'hep', b: 'k', kind: 'own' },
    // officer
    { a: 'gk', b: 'k', kind: 'off' },
    { a: 'jm', b: 'k', kind: 'off' },
    { a: 'mp', b: 'k', kind: 'off' },
    // subs (us → group)
    { a: 'k',  b: 'kdt', kind: 'sub' },
    { a: 'k',  b: 'ket', kind: 'sub' },
    { a: 'k',  b: 'kev', kind: 'sub' },
    // money (state → us)
    { a: 'hep2', b: 'k', kind: 'money', strong: true },
    { a: 'hz',   b: 'k', kind: 'money' },
  ];
  const colorFor = (t) => ({
    'org-self':   'var(--tn-navy-800)',
    'person':     'var(--tn-navy-600)',
    'org-pub':    '#6b82a8',
    'org-sub':    '#8899b4',
    'counter':    '#a67f3f',
  })[t] || 'var(--tn-ink-4)';
  const nb = umOS(() => Object.fromEntries(nodes.map(n => [n.id, n])), []);

  return (
    <div>
      {/* Quadrant labels */}
      <div style={{ position: 'relative' }}>
        <svg width={W} height={H} style={{ display: 'block', background: 'var(--tn-paper-2)', border: '1px solid var(--tn-rule)' }}>
          {/* Quadrant separators — very faint */}
          <line x1={0} y1={H/2} x2={W} y2={H/2} stroke="var(--tn-rule)" strokeDasharray="2 4" strokeOpacity={0.6}/>
          <line x1={W/2} y1={0} x2={W/2} y2={H} stroke="var(--tn-rule)" strokeDasharray="2 4" strokeOpacity={0.6}/>

          {/* Quadrant captions */}
          {[
            ['uprava',       W/2,  14, 'middle'],
            ['vlasnici',     8,    H/2-6, 'start'],
            ['grupa',        W/2,  H-6,  'middle'],
            ['protustr.',    W-8,  H/2-6, 'end'],
          ].map(([l, x, y, a], i) => (
            <text key={i} x={x} y={y} textAnchor={a}
              fontSize={9} fontFamily="var(--tn-font-mono)"
              fill="var(--tn-ink-5)" letterSpacing={0.5}>
              {l.toUpperCase()}
            </text>
          ))}

          {/* Edges */}
          {edges.map((e, i) => {
            const a = nb[e.a], b = nb[e.b];
            const dash = e.kind === 'money' ? '3 3' : e.kind === 'off' ? '' : '';
            return (
              <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y}
                stroke={e.kind === 'money' ? '#a67f3f' : 'var(--tn-navy-700)'}
                strokeOpacity={e.strong ? 0.6 : 0.3}
                strokeWidth={e.strong ? 1.4 : 0.9}
                strokeDasharray={dash}/>
            );
          })}

          {/* Nodes */}
          {nodes.map(n => {
            const r = n.id === 'k' ? 13 : 7;
            return (
              <g key={n.id}>
                <circle cx={n.x} cy={n.y} r={r+2} fill="var(--tn-paper-2)"/>
                <circle cx={n.x} cy={n.y} r={r} fill={colorFor(n.t)} stroke="#fff" strokeWidth={1.5}/>
                <text x={n.x} y={n.y + r + 11} textAnchor="middle"
                  fontSize={n.id === 'k' ? 11 : 9.5} fontFamily="var(--tn-font-sans)"
                  fontWeight={n.id === 'k' ? 600 : 500}
                  fill={n.id === 'k' ? 'var(--tn-navy-900)' : 'var(--tn-ink-2)'}>{n.lbl}</text>
                {n.sub && <text x={n.x} y={n.y + r + 22} textAnchor="middle"
                  fontSize={8.5} fontFamily="var(--tn-font-mono)" fill="var(--tn-ink-5)">{n.sub}</text>}
              </g>
            );
          })}
        </svg>
      </div>

      {/* Legend */}
      <div style={{ display: 'flex', gap: 10, marginTop: 10, flexWrap: 'wrap', fontSize: 10, color: 'var(--tn-ink-4)', fontFamily: 'var(--tn-font-mono)' }}>
        {[
          ['subjekt',       'var(--tn-navy-800)'],
          ['vlasnik',       '#6b82a8'],
          ['uprava',        'var(--tn-navy-600)'],
          ['ovisno',        '#8899b4'],
          ['protustr.',     '#a67f3f'],
        ].map(([l, c]) => (
          <span key={l} style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: c }}/>{l}
          </span>
        ))}
      </div>
      <div style={{ marginTop: 12, display: 'flex', gap: 8 }}>
        <Button variant="primary" size="sm" iconRight="arrow" onClick={onOpen} style={{ flex: 1 }}>Otvori u mreži</Button>
        <Button variant="secondary" size="sm" icon="download">SVG</Button>
      </div>
    </div>
  );
};

// ── Org timeline ───────────────────────────────────────────────
const ORG_EVENT_KINDS = {
  filing:       { lbl: 'GFI predan',     icon: 'doc',      c: 'var(--tn-navy-700)' },
  officer:      { lbl: 'Promjena upr.',  icon: 'person',   c: 'var(--tn-navy-700)' },
  capital:      { lbl: 'Kapital',        icon: 'list',     c: 'var(--tn-navy-700)' },
  contract:     { lbl: 'Ugovor',          icon: 'event',    c: 'var(--tn-verify)' },
  courtNotice:  { lbl: 'Sudska obavijest', icon: 'warn',    c: 'var(--tn-amber)' },
  change:       { lbl: 'Upis promjene',  icon: 'doc',      c: 'var(--tn-navy-700)' },
};

const OrgTimelineEvent = ({ ev, last }) => {
  const K = ORG_EVENT_KINDS[ev.kind];
  const amber = ev.kind === 'courtNotice';
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '92px 32px 1fr', gap: 14, paddingBottom: last ? 0 : 16, position: 'relative' }}>
      <div style={{ textAlign: 'right', paddingTop: 2 }}>
        <div className="tn-mono tn-tnum" style={{ fontSize: 12, color: 'var(--tn-ink-2)' }}>{ev.date}</div>
        {ev.timeAgo && <div style={{ fontSize: 10, color: 'var(--tn-ink-5)', marginTop: 2 }}>{ev.timeAgo}</div>}
      </div>
      <div style={{ position: 'relative', display: 'flex', justifyContent: 'center', paddingTop: 2 }}>
        <div style={{
          width: 26, height: 26, borderRadius: 2,
          background: amber ? 'var(--tn-amber-weak)' : 'var(--tn-white)',
          border: `1px solid ${amber ? 'var(--tn-amber)' : 'var(--tn-rule)'}`,
          color: K.c,
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1,
        }}>
          <Icon name={K.icon} size={13} stroke={1.6}/>
        </div>
        {!last && <div style={{ position: 'absolute', top: 28, bottom: -16, left: '50%', width: 1, background: 'var(--tn-rule)' }}/>}
      </div>
      <div style={{
        background: 'var(--tn-white)',
        border: `1px solid ${amber ? 'var(--tn-amber)' : 'var(--tn-rule)'}`,
        padding: '10px 14px', borderRadius: 2,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4, flexWrap: 'wrap' }}>
          <span className="tn-caps" style={{ color: K.c, fontSize: 10 }}>{K.lbl}</span>
          {ev.amount && (
            <span className="tn-mono tn-tnum" style={{
              fontSize: 12, color: 'var(--tn-ink-2)', fontWeight: 600,
              background: 'var(--tn-paper-2)', padding: '1px 6px', borderRadius: 2,
            }}>{ev.amount}</span>
          )}
        </div>
        <div style={{ fontSize: 13.5, color: 'var(--tn-ink-2)', fontWeight: 500, lineHeight: 1.4 }}>{ev.title}</div>
        {ev.sub && <div style={{ fontSize: 12, color: 'var(--tn-ink-3)', marginTop: 3 }}>{ev.sub}</div>}
        <div style={{ marginTop: 6, display: 'flex', gap: 6 }}>
          <SourceBadge source={ev.source} retrieved={ev.retrieved} url="#" tone={amber ? 'amber' : 'muted'}>
            <span style={{ fontSize: 11 }}>{ev.source.split(' · ')[0]}</span>
          </SourceBadge>
        </div>
      </div>
    </div>
  );
};

// ── THE hero tab: Ugovori s državom ───────────────────────────
const ContractsTab = () => {
  // ── Data ──
  // Annual breakdown by procedure type. Value in mil. EUR.
  // Procedure: open · restricted · direct · negotiated
  const years = [2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025];
  // [open, restricted, negotiated, direct]
  const byYear = [
    [ 8.4,  3.1,  1.2,  0.8],   // 2018
    [11.2,  4.8,  1.9,  1.4],   // 2019
    [ 6.9,  2.2,  0.8,  0.3],   // 2020 — covid dip
    [15.4,  5.1,  2.7,  2.1],   // 2021
    [22.3,  7.8,  3.2,  4.1],   // 2022
    [24.1,  9.4,  4.8,  3.6],   // 2023
    [28.9, 12.1,  5.4,  6.2],   // 2024
    [18.2,  7.0,  2.1,  2.8],   // 2025 YTD
  ];
  const procColors = ['var(--tn-navy-700)', '#6b82a8', '#a3a89c', 'var(--tn-amber)'];
  const procLabels = ['Otvoreni postupak', 'Ograničeni', 'Pregovarački', 'Izravna pogodba'];

  // Ministry share (by cumulative value)
  const byBody = [
    { lbl: 'HEP d.d.',                  mil: 38.4, pct: 20.8, kind: 'public-co' },
    { lbl: 'HŽ Infrastruktura',         mil: 22.1, pct: 12.0, kind: 'public-co' },
    { lbl: 'Ministarstvo gospodarstva', mil: 18.6, pct: 10.1, kind: 'ministry' },
    { lbl: 'Plinacro d.o.o.',           mil: 14.8, pct:  8.0, kind: 'public-co' },
    { lbl: 'HOPS d.d.',                 mil: 12.4, pct:  6.7, kind: 'public-co' },
    { lbl: 'Ministarstvo obrane',       mil:  9.9, pct:  5.4, kind: 'ministry' },
    { lbl: 'Grad Zagreb',                mil:  8.2, pct:  4.5, kind: 'city' },
    { lbl: 'Ministarstvo pravosuđa',   mil:  5.1, pct:  2.8, kind: 'ministry' },
    { lbl: 'Ostali naručitelji (137)',  mil: 54.7, pct: 29.7, kind: 'other' },
  ];

  // Filter state
  const [yearFrom, setYearFrom] = uOS(2018);
  const [yearTo, setYearTo] = uOS(2025);
  const [procFilter, setProcFilter] = uOS(new Set([0, 1, 2, 3]));
  const toggleProc = (i) => {
    const s = new Set(procFilter);
    s.has(i) ? s.delete(i) : s.add(i);
    setProcFilter(s);
  };

  // Aggregate totals (for KPI row)
  const totalMil = byYear
    .map((v, i) => ({ year: years[i], v }))
    .filter(r => r.year >= yearFrom && r.year <= yearTo)
    .reduce((acc, { v }) => acc + v.reduce((a, x, i) => procFilter.has(i) ? a + x : a, 0), 0);
  const count = 142;
  const bodies = 146;
  const directShare = 20.1; // % direct across range

  // Max column height
  const maxYear = Math.max(...byYear.map(v => v.reduce((a, b) => a + b, 0)));

  // Contract rows
  const rows = [
    ['2026-03-12', 'HEP d.d.',                    'Transformatori 400 MVA · 3 kom',                     'CPV 31170000',  0, '12.840.000', 'ugovoren'],
    ['2026-01-28', 'HŽ Infrastruktura',           'Modernizacija signalizacije Dugo Selo — Križevci',    'CPV 45234100',  0, '8.412.000',  'ugovoren'],
    ['2025-11-04', 'Grad Split',                   'Rekonstrukcija TS 35/10 kV Kopilica',                 'CPV 31174000',  1, '2.184.500',  'ugovoren'],
    ['2025-09-17', 'Plinacro d.o.o.',              'Elektromotorni pogoni kompresorske stanice',           'CPV 42123000',  0, '1.920.000',  'ugovoren'],
    ['2025-07-02', 'HEP — Proizvodnja',            'Generator HE Dubrovnik 3 · remont',                    'CPV 31120000',  2, '4.680.000',  'ugovoren'],
    ['2025-04-14', 'Ministarstvo gospodarstva',    'Savjetodavne studije · obnovljivi izvori',             'CPV 71314000',  3, '184.200',    'ugovoren'],
    ['2025-02-19', 'HOPS d.d.',                    'Rezervni dijelovi · 2 god.',                           'CPV 31120000',  1, '3.460.000',  'u izvršenju'],
    ['2024-12-03', 'HEP d.d.',                     'Upravljanje distribucijom — nadogradnja softvera',     'CPV 48000000',  0, '2.820.000',  'dovršen'],
  ];

  const fmt = (s) => s.replace(/\./g, '.');

  return (
    <div>
      {/* KPI row specific to contracts */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12, marginBottom: 20 }}>
        <KPI label="Ukupno ugovoreno" value={totalMil.toFixed(1).replace('.', ',')} unit="mil. EUR" delta={`${yearFrom}–${yearTo}`}/>
        <KPI label="Ugovora" value={count} delta="142 EOJN zapisa"/>
        <KPI label="Naručitelja" value={bodies} delta="od ministarstava do gradova"/>
        <KPI label="Prosj. vrijednost" value="1,30" unit="mil. EUR" delta="medijan 0,84 mil."/>
        <KPI label="Izravna pogodba" value={directShare.toFixed(1).replace('.', ',')} unit="% vrijednosti" delta="prosjek sektora 14,2%" warn={directShare > 14.2}/>
      </div>

      {/* Filter bar */}
      <div style={{
        background: 'var(--tn-white)', border: '1px solid var(--tn-rule)',
        padding: '14px 18px', marginBottom: 16,
        display: 'flex', gap: 18, alignItems: 'center', flexWrap: 'wrap',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span className="tn-caps" style={{ fontSize: 10 }}>Godina</span>
          <select value={yearFrom} onChange={e => setYearFrom(+e.target.value)} style={selStyle}>
            {years.map(y => <option key={y} value={y}>{y}</option>)}
          </select>
          <span style={{ color: 'var(--tn-ink-5)' }}>→</span>
          <select value={yearTo} onChange={e => setYearTo(+e.target.value)} style={selStyle}>
            {years.map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </div>

        <div style={{ width: 1, height: 24, background: 'var(--tn-rule)' }}/>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span className="tn-caps" style={{ fontSize: 10 }}>Postupak</span>
          {procLabels.map((p, i) => {
            const on = procFilter.has(i);
            return (
              <button key={p} onClick={() => toggleProc(i)} style={{
                display: 'inline-flex', alignItems: 'center', gap: 6,
                padding: '3px 10px', borderRadius: 999, fontSize: 11,
                border: `1px solid ${on ? procColors[i] : 'var(--tn-rule)'}`,
                background: on ? 'rgba(11,37,69,0.04)' : 'transparent',
                color: on ? 'var(--tn-ink-2)' : 'var(--tn-ink-5)',
                cursor: 'pointer', fontFamily: 'inherit', fontWeight: 500,
              }}>
                <span style={{ width: 8, height: 8, borderRadius: 1, background: procColors[i], opacity: on ? 1 : 0.4 }}/>
                {p}
              </button>
            );
          })}
        </div>

        <div style={{ flex: 1 }}/>
        <Button variant="secondary" size="sm" icon="download">Izvoz (CSV)</Button>
        <Button variant="ghost" size="sm" iconRight="external">EOJN</Button>
      </div>

      {/* Chart + ministry breakdown */}
      <div style={{
        display: 'grid', gridTemplateColumns: '1fr 400px', gap: 16, marginBottom: 20,
      }}>
        {/* Stacked bars */}
        <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: '18px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 14 }}>
            <h3 style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.1, color: 'var(--tn-ink-2)' }}>
              Vrijednost ugovora po godini i postupku
            </h3>
            <span style={{ fontSize: 11, fontFamily: 'var(--tn-font-mono)', color: 'var(--tn-ink-5)' }}>mil. EUR</span>
          </div>

          {/* Bars */}
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14, height: 220, borderBottom: '1px solid var(--tn-rule)', paddingBottom: 4 }}>
            {byYear.map((v, yi) => {
              const year = years[yi];
              const inRange = year >= yearFrom && year <= yearTo;
              const total = v.reduce((a, b, i) => a + (procFilter.has(i) ? b : 0), 0);
              const h = (total / maxYear) * 200;
              return (
                <div key={year} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, height: '100%', justifyContent: 'flex-end', opacity: inRange ? 1 : 0.35 }}>
                  <span className="tn-mono tn-tnum" style={{ fontSize: 10, color: 'var(--tn-ink-3)', fontWeight: 500 }}>{total.toFixed(1).replace('.', ',')}</span>
                  <div style={{ width: '100%', height: h, display: 'flex', flexDirection: 'column-reverse' }}>
                    {v.map((seg, si) => {
                      if (!procFilter.has(si)) return null;
                      return (
                        <div key={si} style={{
                          height: `${(seg / total) * 100}%`,
                          background: procColors[si],
                          borderTop: si > 0 ? '1px solid rgba(255,255,255,0.5)' : 'none',
                        }} title={`${procLabels[si]}: ${seg.toFixed(1)} mil. EUR`}/>
                      );
                    })}
                  </div>
                  <span className="tn-mono" style={{ fontSize: 10, color: 'var(--tn-ink-4)' }}>{year}{year === 2025 ? ' YTD' : ''}</span>
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div style={{ display: 'flex', gap: 16, marginTop: 12, flexWrap: 'wrap', fontSize: 11, color: 'var(--tn-ink-3)' }}>
            {procLabels.map((l, i) => (
              <span key={l} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, opacity: procFilter.has(i) ? 1 : 0.35 }}>
                <span style={{ width: 10, height: 10, borderRadius: 1, background: procColors[i] }}/>
                {l}
              </span>
            ))}
          </div>
        </div>

        {/* By body */}
        <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)', padding: '18px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 14 }}>
            <h3 style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.1, color: 'var(--tn-ink-2)' }}>
              Po naručitelju
            </h3>
            <span style={{ fontSize: 11, fontFamily: 'var(--tn-font-mono)', color: 'var(--tn-ink-5)' }}>kumul. mil. EUR</span>
          </div>

          {byBody.map((b, i) => {
            const kindColor = {
              'ministry':   'var(--tn-navy-800)',
              'public-co':  'var(--tn-navy-600)',
              'city':       '#6b82a8',
              'other':      'var(--tn-ink-5)',
            }[b.kind];
            return (
              <div key={b.lbl} style={{
                display: 'grid', gridTemplateColumns: '1fr 70px 62px',
                gap: 10, alignItems: 'center', padding: '7px 0',
                borderBottom: i === byBody.length - 1 ? 'none' : '1px solid var(--tn-rule-2)',
              }}>
                <div>
                  <div style={{ fontSize: 12, color: 'var(--tn-ink-2)', fontWeight: 500 }}>{b.lbl}</div>
                  <div style={{ fontSize: 10, color: 'var(--tn-ink-5)', fontFamily: 'var(--tn-font-mono)', textTransform: 'uppercase', letterSpacing: 0.3 }}>
                    {b.kind === 'ministry' ? 'ministarstvo' : b.kind === 'public-co' ? 'javno poduzeće' : b.kind === 'city' ? 'grad' : 'agregirano'}
                  </div>
                </div>
                <div style={{ background: 'var(--tn-paper-2)', height: 6, borderRadius: 1, overflow: 'hidden' }}>
                  <div style={{ width: `${(b.pct / 22) * 100}%`, height: '100%', background: kindColor }}/>
                </div>
                <div className="tn-mono tn-tnum" style={{ textAlign: 'right', fontSize: 12, color: 'var(--tn-ink-2)', fontWeight: 500 }}>
                  {b.mil.toFixed(1).replace('.', ',')}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Contracts table */}
      <div style={{ background: 'var(--tn-white)', border: '1px solid var(--tn-rule)' }}>
        <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--tn-rule)', display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <h3 style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.1, color: 'var(--tn-ink-2)' }}>
            Ugovori <span style={{ color: 'var(--tn-ink-5)', fontWeight: 500 }}>· 8 od 142</span>
          </h3>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 11, color: 'var(--tn-ink-5)' }}>
            <span>Sort:</span>
            <select style={{ ...selStyle, fontSize: 11 }}>
              <option>Najnoviji prvi</option>
              <option>Najveći iznos</option>
              <option>Po naručitelju</option>
            </select>
          </div>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12.5, minWidth: 1000 }}>
            <thead>
              <tr style={{ background: 'var(--tn-paper-2)', textAlign: 'left' }}>
                {[
                  ['Datum', 'left', 110],
                  ['Naručitelj', 'left', 220],
                  ['Predmet', 'left'],
                  ['CPV', 'left', 110],
                  ['Postupak', 'left', 150],
                  ['Vrijednost', 'right', 130],
                  ['Status', 'left', 110],
                  ['Izvor', 'left', 80],
                ].map(([h, a, w]) => (
                  <th key={h} style={{
                    padding: '10px 14px', fontSize: 10, fontWeight: 500,
                    letterSpacing: 0.08, textTransform: 'uppercase',
                    color: 'var(--tn-ink-4)', borderBottom: '1px solid var(--tn-rule)',
                    textAlign: a, width: w,
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => {
                const [date, body, predmet, cpv, procIdx, val, status] = r;
                return (
                  <tr key={i} style={{ borderBottom: '1px solid var(--tn-rule-2)' }}>
                    <td style={{ padding: '11px 14px', fontFamily: 'var(--tn-font-mono)', color: 'var(--tn-ink-3)' }}>{date}</td>
                    <td style={{ padding: '11px 14px' }}>
                      <a href="#" style={{ color: 'var(--tn-navy-800)', fontWeight: 500, textDecoration: 'none' }}>{body}</a>
                    </td>
                    <td style={{ padding: '11px 14px', color: 'var(--tn-ink-2)' }}>{predmet}</td>
                    <td style={{ padding: '11px 14px', fontFamily: 'var(--tn-font-mono)', color: 'var(--tn-ink-4)', fontSize: 11 }}>{cpv}</td>
                    <td style={{ padding: '11px 14px' }}>
                      <span style={{
                        display: 'inline-flex', alignItems: 'center', gap: 6,
                        fontSize: 11, color: 'var(--tn-ink-2)',
                      }}>
                        <span style={{ width: 8, height: 8, borderRadius: 1, background: procColors[procIdx] }}/>
                        {procLabels[procIdx]}
                      </span>
                    </td>
                    <td className="tn-mono tn-tnum" style={{ padding: '11px 14px', textAlign: 'right', color: 'var(--tn-ink-2)', fontWeight: 600 }}>
                      {fmt(val)} €
                    </td>
                    <td style={{ padding: '11px 14px' }}>
                      <span style={{
                        fontSize: 11, color:
                          status === 'ugovoren' ? 'var(--tn-verify)' :
                          status === 'u izvršenju' ? 'var(--tn-navy-700)' : 'var(--tn-ink-4)',
                        fontFamily: 'var(--tn-font-mono)', letterSpacing: 0.2,
                      }}>{status}</span>
                    </td>
                    <td style={{ padding: '11px 14px' }}>
                      <SourceBadge source="EOJN · nabava.gov.hr" retrieved="2026-04-23" tone="muted">eojn</SourceBadge>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div style={{ padding: '14px 18px', textAlign: 'center', borderTop: '1px solid var(--tn-rule-2)' }}>
          <Button variant="ghost" size="sm" iconRight="chev">Prikaži preostalih 134 ugovora</Button>
        </div>
      </div>

      <div style={{ marginTop: 12, fontSize: 11, color: 'var(--tn-ink-5)', fontFamily: 'var(--tn-font-mono)', lineHeight: 1.55 }}>
        Sve vrijednosti su ugovorene (bez eventualnih aneksa). Normalizacija valuta: HRK iznosi prije 01.01.2023. preračunati po fiksnom tečaju 7,53450.
        Podatci: EOJN · Narodne novine. Metodologija: <a href="#" style={{ color: 'var(--tn-navy-700)' }}>Transparentno.hr/metodologija/ugovori</a>.
      </div>
    </div>
  );
};

const selStyle = {
  padding: '4px 8px', border: '1px solid var(--tn-rule)', borderRadius: 2,
  fontSize: 12, fontFamily: 'inherit', background: 'var(--tn-white)',
  color: 'var(--tn-ink-2)',
};

// ── KPI tile ─────────────────────────────────────────────────
const KPI = ({ label, value, unit, delta, trend, warn }) => (
  <div style={{
    padding: '14px 16px',
    background: 'var(--tn-white)',
    border: `1px solid ${warn ? 'var(--tn-amber)' : 'var(--tn-rule)'}`,
    borderRadius: 2, position: 'relative',
  }}>
    <div className="tn-caps" style={{ fontSize: 10, marginBottom: 6, color: warn ? 'var(--tn-amber-ink)' : 'var(--tn-ink-4)' }}>{label}</div>
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 5 }}>
      <span style={{
        fontSize: 22, fontWeight: 600, color: warn ? 'var(--tn-amber-ink)' : 'var(--tn-ink-2)',
        fontFamily: 'var(--tn-font-mono)', fontVariantNumeric: 'tabular-nums', letterSpacing: -0.3,
      }}>{value}</span>
      {unit && <span style={{ fontSize: 11, color: 'var(--tn-ink-4)' }}>{unit}</span>}
    </div>
    {(delta || trend) && (
      <div style={{ fontSize: 11, color: 'var(--tn-ink-4)', marginTop: 4, display: 'flex', gap: 4, alignItems: 'center' }}>
        {trend && (
          <span style={{ color: trend.startsWith('↑') ? 'var(--tn-verify)' : trend.startsWith('↓') ? 'var(--tn-amber-ink)' : 'var(--tn-ink-4)', fontWeight: 600 }}>
            {trend}
          </span>
        )}
        {delta}
      </div>
    )}
  </div>
);

Object.assign(window, { OrgMiniGraph, OrgTimelineEvent, ORG_EVENT_KINDS, ContractsTab, KPI });
